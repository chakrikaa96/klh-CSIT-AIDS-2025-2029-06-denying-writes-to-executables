"""
dialogs.py - Modal dialogs: confirmation, start-worker and settings.
All dialogs share the dashboard theme.
"""
import tkinter as tk
from tkinter import ttk

from theme import PALETTE


class _Dialog(tk.Toplevel):
    def __init__(self, master, title, width=None):
        super().__init__(master)
        self.withdraw()
        self.title(title)
        self.configure(bg=PALETTE["panel"], highlightthickness=1,
                       highlightbackground=PALETTE["border"])
        self.transient(master)
        self.resizable(False, False)
        self.result = None
        self.body = ttk.Frame(self, style="Panel.TFrame", padding=(22, 18, 22, 16))
        self.body.pack(fill="both", expand=True)
        if width:
            self.body.configure(width=width)
        self.protocol("WM_DELETE_WINDOW", self.cancel)
        self.bind("<Escape>", lambda e: self.cancel())

    def show(self):
        self.update_idletasks()
        m = self.master
        x = m.winfo_rootx() + (m.winfo_width() - self.winfo_reqwidth()) // 2
        y = m.winfo_rooty() + (m.winfo_height() - self.winfo_reqheight()) // 3
        self.geometry(f"+{max(x, 0)}+{max(y, 0)}")
        self.deiconify()
        self.grab_set()
        self.focus_set()
        self.wait_window()
        return self.result

    def cancel(self):
        self.result = None
        self.destroy()

    def button_row(self, ok_text, ok_style="Accent.TButton"):
        row = ttk.Frame(self.body, style="Panel.TFrame")
        row.pack(fill="x", pady=(18, 0))
        ok = ttk.Button(row, text=ok_text, style=ok_style, command=self.accept)
        ok.pack(side="right")
        ttk.Button(row, text="Cancel", command=self.cancel).pack(side="right", padx=(0, 8))
        self.bind("<Return>", lambda e: self.accept())
        return ok

    def accept(self):
        self.destroy()


class ConfirmDialog(_Dialog):
    """Yes/no confirmation for destructive actions."""

    def __init__(self, master, fonts, title, message, detail="", ok_text="Confirm", danger=True):
        super().__init__(master, title)
        ttk.Label(self.body, text=title, style="Section.TLabel", font=fonts.heading).pack(anchor="w")
        ttk.Label(self.body, text=message, style="Panel.TLabel", wraplength=380,
                  justify="left").pack(anchor="w", pady=(8, 0))
        if detail:
            ttk.Label(self.body, text=detail, style="Muted.TLabel", wraplength=380,
                      justify="left").pack(anchor="w", pady=(6, 0))
        self.button_row(ok_text, "Danger.TButton" if danger else "Accent.TButton")

    def accept(self):
        self.result = True
        self.destroy()


class SpawnDialog(_Dialog):
    """Choose a worker profile, an optional name and how many to start."""

    def __init__(self, master, fonts, profiles):
        super().__init__(master, "Start worker")
        self.profiles = profiles
        ttk.Label(self.body, text="Start worker", style="Section.TLabel", font=fonts.heading).pack(anchor="w")
        ttk.Label(self.body, text="The controller creates each worker with fork() and execv().",
                  style="Muted.TLabel").pack(anchor="w", pady=(2, 12))

        self.choice = tk.StringVar(value=profiles[0]["name"] if profiles else "")
        box = tk.Frame(self.body, bg=PALETTE["field"], highlightthickness=1,
                       highlightbackground=PALETTE["border"])
        box.pack(fill="x")
        for p in profiles:
            row = tk.Frame(box, bg=PALETTE["field"])
            row.pack(fill="x", padx=10, pady=4)
            rb = tk.Radiobutton(row, variable=self.choice, value=p["name"], text=p["name"],
                                bg=PALETTE["field"], fg=PALETTE["text"],
                                activebackground=PALETTE["field"], activeforeground=PALETTE["text"],
                                selectcolor=PALETTE["panel_hi"], highlightthickness=0,
                                font=(fonts.sans, 10, "bold"), anchor="w", width=8)
            rb.pack(side="left")
            if p.get("test_worker"):
                tk.Label(row, text="TEST", bg="#3a2c14", fg=PALETTE["warn"],
                         font=(fonts.sans, 7, "bold"), padx=5).pack(side="left", padx=(0, 8))
            tk.Label(row, text=p["description"], bg=PALETTE["field"], fg=PALETTE["muted"],
                     font=fonts.small, anchor="w").pack(side="left", fill="x")

        form = ttk.Frame(self.body, style="Panel.TFrame")
        form.pack(fill="x", pady=(14, 0))
        ttk.Label(form, text="Name (optional)", style="Muted.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(form, text="Count", style="Muted.TLabel").grid(row=0, column=1, sticky="w", padx=(12, 0))
        self.name = tk.StringVar()
        self.count = tk.StringVar(value="1")
        ttk.Entry(form, textvariable=self.name, width=28).grid(row=1, column=0, sticky="we", pady=(4, 0))
        ttk.Spinbox(form, from_=1, to=8, textvariable=self.count, width=5).grid(
            row=1, column=1, sticky="w", padx=(12, 0), pady=(4, 0))
        self.error = ttk.Label(self.body, text="", style="Muted.TLabel", foreground=PALETTE["error"])
        self.error.pack(anchor="w", pady=(8, 0))
        self.button_row("Start")

    def accept(self):
        name = self.name.get().strip()
        try:
            count = int(self.count.get())
        except ValueError:
            count = 0
        if not 1 <= count <= 8:
            self.error.configure(text="Count must be between 1 and 8.")
            return
        if name and count > 1:
            self.error.configure(text="Leave the name empty when starting several workers.")
            return
        if name and not all(ch.isalnum() or ch in "-_." for ch in name):
            self.error.configure(text="Use only letters, digits, '-', '_' and '.'.")
            return
        self.result = (self.choice.get(), name, count)
        self.destroy()


SETTINGS_FIELDS = [
    ("max_restarts",          "Maximum restart attempts",   "consecutive failures before recovery stops"),
    ("backoff_base_ms",       "Restart backoff (ms)",       "first delay; doubles on each attempt"),
    ("backoff_max_ms",        "Maximum backoff (ms)",       "upper bound for the delay"),
    ("stable_reset_s",        "Stable reset (s)",           "uptime after which failures are forgotten"),
    ("monitor_interval_ms",   "Monitoring interval (ms)",   "health checks and dashboard refresh"),
    ("heartbeat_interval_ms", "Heartbeat interval (ms)",    "applies to newly started workers"),
    ("status_timeout_ms",     "Status reply timeout (ms)",  "after this a worker is 'unresponsive'"),
    ("stop_grace_ms",         "Stop grace period (ms)",     "SIGTERM wait before SIGKILL"),
]


class SettingsDialog(_Dialog):
    """Edit runtime settings; the controller validates every value."""

    def __init__(self, master, fonts, config):
        super().__init__(master, "Settings")
        self.config_values = config
        ttk.Label(self.body, text="Controller settings", style="Section.TLabel",
                  font=fonts.heading).pack(anchor="w")
        ttk.Label(self.body, text=f"Config file: {config.get('config_file') or '(none)'}",
                  style="Muted.TLabel").pack(anchor="w", pady=(2, 12))

        form = ttk.Frame(self.body, style="Panel.TFrame")
        form.pack(fill="x")
        self.vars = {}
        for row, (key, label, hint) in enumerate(SETTINGS_FIELDS):
            ttk.Label(form, text=label, style="Panel.TLabel").grid(row=row, column=0, sticky="w", pady=3)
            var = tk.StringVar(value=str(config.get(key, "")))
            ttk.Entry(form, textvariable=var, width=10, justify="right").grid(
                row=row, column=1, sticky="e", padx=(16, 10), pady=3)
            ttk.Label(form, text=hint, style="Muted.TLabel").grid(row=row, column=2, sticky="w")
            self.vars[key] = var

        r = len(SETTINGS_FIELDS)
        ttk.Label(form, text="Log file", style="Panel.TLabel").grid(row=r, column=0, sticky="w", pady=(10, 3))
        self.log_var = tk.StringVar(value=config.get("log_file", ""))
        ttk.Entry(form, textvariable=self.log_var, width=52).grid(
            row=r, column=1, columnspan=2, sticky="we", padx=(16, 0), pady=(10, 3))

        self.watchdog = tk.BooleanVar(value=bool(config.get("watchdog")))
        self.save = tk.BooleanVar(value=True)
        checks = ttk.Frame(self.body, style="Panel.TFrame")
        checks.pack(fill="x", pady=(10, 0))
        ttk.Checkbutton(checks, text="Watchdog automatic recovery enabled",
                        variable=self.watchdog).pack(anchor="w")
        ttk.Checkbutton(checks, text="Also save to the configuration file",
                        variable=self.save).pack(anchor="w", pady=(4, 0))
        self.error = ttk.Label(self.body, text="", style="Muted.TLabel", foreground=PALETTE["error"],
                               wraplength=520)
        self.error.pack(anchor="w", pady=(8, 0))
        self.button_row("Apply")

    def accept(self):
        changes = []
        for key, var in self.vars.items():
            value = var.get().strip()
            if not value.isdigit():
                self.error.configure(text=f"'{key}' must be a whole number.")
                return
            if value != str(self.config_values.get(key)):
                changes.append((key, value))
        log = self.log_var.get().strip()
        if log and log != self.config_values.get("log_file"):
            if " " in log:
                self.error.configure(text="The log file path must not contain spaces.")
                return
            changes.append(("log_file", log))
        wd = "on" if self.watchdog.get() else "off"
        if self.watchdog.get() != bool(self.config_values.get("watchdog")):
            changes.append(("watchdog", wd))
        self.result = (changes, self.save.get())
        self.destroy()
