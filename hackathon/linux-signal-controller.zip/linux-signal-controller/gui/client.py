"""
client.py - Talks to the sigctld controller over its Unix domain socket.

Protocol: connect, send one request line, read one JSON reply, close.
The GUI never touches PIDs or signals directly; it only sends commands
that the controller validates against its own registry.
"""
import json
import os
import socket


class ControllerError(Exception):
    """The controller could not be reached or sent an invalid reply."""


def read_config(path):
    """Parse the key = value config file (same format the controller uses)."""
    values = {}
    try:
        with open(path) as f:
            for line in f:
                line = line.split("#", 1)[0].strip()
                if "=" in line:
                    key, value = line.split("=", 1)
                    values[key.strip()] = value.strip()
    except OSError:
        pass
    return values


class ControllerClient:
    def __init__(self, socket_path, timeout=12.0):
        self.socket_path = socket_path
        self.timeout = timeout

    def request(self, line, timeout=None):
        """Send one command; return the decoded JSON reply (a dict)."""
        if "\n" in line or len(line) > 900:
            raise ValueError("invalid request")
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(timeout or self.timeout)
        try:
            s.connect(self.socket_path)
            s.sendall((line + "\n").encode())
            chunks = []
            while True:
                data = s.recv(65536)
                if not data:
                    break
                chunks.append(data)
        except FileNotFoundError:
            raise ControllerError("controller is not running (no socket)")
        except ConnectionRefusedError:
            raise ControllerError("controller is not running (connection refused)")
        except socket.timeout:
            raise ControllerError("controller did not answer in time")
        except OSError as e:
            raise ControllerError(f"cannot reach controller: {e.strerror or e}")
        finally:
            s.close()
        raw = b"".join(chunks).decode(errors="replace").strip()
        if not raw:
            raise ControllerError("empty reply from controller")
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            raise ControllerError("malformed reply from controller")

    def available(self):
        return os.path.exists(self.socket_path)
