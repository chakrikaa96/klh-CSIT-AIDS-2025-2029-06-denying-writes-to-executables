"""
theme.py - Dark, restrained visual theme for the Tkinter dashboard.
"""
import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk

PALETTE = {
    "bg":        "#0e1014",
    "panel":     "#15181e",
    "panel_hi":  "#1b1f27",
    "field":     "#11141a",
    "border":    "#262b35",
    "text":      "#e4e7ec",
    "muted":     "#8a929e",
    "faint":     "#5c6370",
    "accent":    "#5b9cff",
    "accent_hi": "#78afff",
    "ok":        "#3ecf8e",
    "warn":      "#f0b429",
    "error":     "#f2555a",
    "paused":    "#d6a54a",
    "backoff":   "#e0873c",
    "select":    "#24324a",
}

STATE_COLORS = {
    "running":   PALETTE["ok"],
    "starting":  PALETTE["accent"],
    "paused":    PALETTE["paused"],
    "stopping":  PALETTE["muted"],
    "stopped":   PALETTE["faint"],
    "completed": PALETTE["muted"],
    "backoff":   PALETTE["backoff"],
    "failed":    PALETTE["error"],
}

SEVERITY_COLORS = {
    "info":  PALETTE["muted"],
    "ok":    PALETTE["ok"],
    "warn":  PALETTE["warn"],
    "error": PALETTE["error"],
}


def pick_family(root, candidates, fallback):
    available = set(tkfont.families(root))
    for name in candidates:
        if name in available:
            return name
    return fallback


class Fonts:
    def __init__(self, root):
        sans = pick_family(root, ["Inter", "Cantarell", "Noto Sans", "DejaVu Sans",
                                  "Helvetica Neue", "Helvetica"], "TkDefaultFont")
        mono = pick_family(root, ["JetBrains Mono", "Fira Code", "DejaVu Sans Mono",
                                  "Liberation Mono", "Menlo", "Courier"], "TkFixedFont")
        self.sans, self.mono = sans, mono
        self.body = (sans, 10)
        self.small = (sans, 9)
        self.label = (sans, 8, "bold")
        self.title = (sans, 13, "bold")
        self.heading = (sans, 11, "bold")
        self.metric = (sans, 22, "bold")
        self.mono_body = (mono, 9)
        self.mono_small = (mono, 9)


def apply_theme(root):
    p = PALETTE
    fonts = Fonts(root)
    root.configure(bg=p["bg"])
    root.option_add("*Font", fonts.body)
    root.option_add("*TCombobox*Listbox.background", p["panel_hi"])
    root.option_add("*TCombobox*Listbox.foreground", p["text"])
    root.option_add("*TCombobox*Listbox.selectBackground", p["select"])
    root.option_add("*Menu.background", p["panel_hi"])
    root.option_add("*Menu.foreground", p["text"])
    root.option_add("*Menu.activeBackground", p["select"])
    root.option_add("*Menu.activeForeground", p["text"])
    root.option_add("*Menu.borderWidth", 0)

    s = ttk.Style(root)
    s.theme_use("clam")
    s.configure(".", background=p["bg"], foreground=p["text"], fieldbackground=p["field"],
                bordercolor=p["border"], lightcolor=p["border"], darkcolor=p["border"],
                troughcolor=p["panel"], focuscolor=p["accent"], font=fonts.body)
    s.configure("TFrame", background=p["bg"])
    s.configure("Panel.TFrame", background=p["panel"])
    s.configure("TLabel", background=p["bg"], foreground=p["text"])
    s.configure("Panel.TLabel", background=p["panel"], foreground=p["text"])
    s.configure("Muted.TLabel", background=p["panel"], foreground=p["muted"], font=fonts.small)
    s.configure("Section.TLabel", background=p["panel"], foreground=p["text"], font=fonts.heading)

    # Buttons
    s.configure("TButton", background=p["panel_hi"], foreground=p["text"], borderwidth=1,
                bordercolor=p["border"], focusthickness=0, padding=(10, 5), relief="flat")
    s.map("TButton",
          background=[("disabled", p["panel"]), ("pressed", p["select"]), ("active", "#232834")],
          foreground=[("disabled", p["faint"])],
          bordercolor=[("active", "#353c49")])
    s.configure("Accent.TButton", background=p["accent"], foreground="#0b1220",
                bordercolor=p["accent"], font=(fonts.sans, 10, "bold"))
    s.map("Accent.TButton",
          background=[("disabled", p["panel"]), ("pressed", "#4a86e0"), ("active", p["accent_hi"])],
          foreground=[("disabled", p["faint"])],
          bordercolor=[("disabled", p["border"]), ("active", p["accent_hi"])])
    s.configure("Danger.TButton", background=p["panel_hi"], foreground=p["error"],
                bordercolor="#4a2a2e")
    s.map("Danger.TButton",
          background=[("disabled", p["panel"]), ("pressed", "#3a1f23"), ("active", "#2c1c20")],
          foreground=[("disabled", p["faint"])],
          bordercolor=[("disabled", p["border"]), ("active", p["error"])])
    s.configure("Toggle.TButton", padding=(10, 5))
    s.configure("Tool.TButton", padding=(10, 4), font=fonts.small, width=0)

    # Treeview
    s.configure("Treeview", background=p["panel"], fieldbackground=p["panel"],
                foreground=p["text"], rowheight=26, borderwidth=0, font=fonts.body)
    s.map("Treeview", background=[("selected", p["select"])],
          foreground=[("selected", p["text"])])
    s.configure("Treeview.Heading", background=p["panel_hi"], foreground=p["muted"],
                borderwidth=0, relief="flat", font=fonts.label, padding=(6, 6))
    s.map("Treeview.Heading", background=[("active", p["panel_hi"])])
    s.layout("Treeview", [("Treeview.treearea", {"sticky": "nswe"})])
    s.configure("Events.Treeview", rowheight=22, font=fonts.mono_small)

    # Notebook
    s.configure("TNotebook", background=p["panel"], borderwidth=0, tabmargins=(0, 4, 0, 0))
    s.configure("TNotebook.Tab", background=p["panel"], foreground=p["muted"],
                padding=(12, 6), borderwidth=0, font=fonts.small)
    s.map("TNotebook.Tab", background=[("selected", p["panel_hi"])],
          foreground=[("selected", p["text"])])

    # Inputs
    for widget in ("TEntry", "TSpinbox", "TCombobox"):
        s.configure(widget, fieldbackground=p["field"], foreground=p["text"],
                    insertcolor=p["text"], bordercolor=p["border"], arrowcolor=p["muted"],
                    background=p["panel_hi"], padding=4)
        s.map(widget, bordercolor=[("focus", p["accent"])],
              fieldbackground=[("readonly", p["field"])],
              foreground=[("disabled", p["faint"])])
    s.configure("TCheckbutton", background=p["panel"], foreground=p["text"],
                indicatorbackground=p["field"], indicatorforeground=p["accent"])
    s.map("TCheckbutton", background=[("active", p["panel"])],
          indicatorbackground=[("selected", p["field"])])
    s.configure("TRadiobutton", background=p["panel"], foreground=p["text"],
                indicatorbackground=p["field"], indicatorforeground=p["accent"])
    s.map("TRadiobutton", background=[("active", p["panel"])])

    # Scrollbars and panes
    s.configure("Vertical.TScrollbar", background=p["panel_hi"], troughcolor=p["panel"],
                bordercolor=p["panel"], arrowcolor=p["muted"], gripcount=0)
    s.map("Vertical.TScrollbar", background=[("active", "#2a303b")])
    s.configure("TPanedwindow", background=p["bg"])
    s.configure("Sash", sashthickness=6, background=p["bg"], gripcount=0)
    return fonts
