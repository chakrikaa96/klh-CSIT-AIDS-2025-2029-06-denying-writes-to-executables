#!/usr/bin/env python3
"""
dashboard.py - Desktop dashboard for the Linux Signal-Based Process Controller.

The dashboard is only a client. All process management and every signal
is performed by the C controller (sigctld); the GUI sends commands over the
controller's Unix domain socket and displays the verified state it returns.

Threads: a background poller fetches LIST / EVENTS / INFO and user actions
run in short-lived threads, so the window never freezes while the
controller waits for a confirmation (for example a graceful stop). Results
are passed to the Tk main thread through a queue.

Usage: python3 gui/dashboard.py [-c config/sigctl.conf]
"""
import argparse
import json
import os
import queue
import subprocess
import sys
import threading
import time
import tkinter as tk
from tkinter import ttk

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from client import ControllerClient, ControllerError, read_config  # noqa: E402
from dialogs import ConfirmDialog, SettingsDialog, SpawnDialog  # noqa: E402
from theme import PALETTE, SEVERITY_COLORS, STATE_COLORS, apply_theme  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MAX_EVENTS = 800


def fmt_duration(ms):
    s = max(int(ms) // 1000, 0)
    if s >= 3600:
        return f"{s // 3600}h {s % 3600 // 60:02d}m"
    if s >= 60:
        return f"{s // 60}m {s % 60:02d}s"
    return f"{s}s"


def fmt_mem(kb):
    if not kb:
        return "-"
    return f"{kb / 1024:.1f} MB" if kb >= 1024 else f"{kb} kB"


class FlowFrame(tk.Frame):
    """Lays its children out left to right, wrapping onto new rows."""

    def __init__(self, master, gap=6, **kw):
        super().__init__(master, **kw)
        self.gap = gap
        self._width = 0
        self.bind("<Configure>", self._on_configure)

    def _on_configure(self, event):
        if event.width != self._width:
            self._width = event.width
            self.reflow()

    def reflow(self):
        width = max(self.winfo_width(), 1)
        x = y = row_h = 0
        for child in self.winfo_children():
            w, h = child.winfo_reqwidth(), child.winfo_reqheight()
            if x > 0 and x + w > width:
                x, y, row_h = 0, y + row_h + self.gap, 0
            child.place(x=x, y=y)
            x += w + self.gap
            row_h = max(row_h, h)
        self.configure(height=y + row_h)


class MetricCard(tk.Frame):
    def __init__(self, master, fonts, label, color):
        super().__init__(master, bg=PALETTE["panel"], highlightthickness=1,
                         highlightbackground=PALETTE["border"])
        tk.Frame(self, bg=color, width=3).pack(side="left", fill="y")
        inner = tk.Frame(self, bg=PALETTE["panel"])
        inner.pack(side="left", fill="both", expand=True, padx=14, pady=10)
        tk.Label(inner, text=label.upper(), bg=PALETTE["panel"], fg=PALETTE["muted"],
                 font=fonts.label, anchor="w").pack(fill="x")
        self.value = tk.Label(inner, text="-", bg=PALETTE["panel"], fg=PALETTE["text"],
                              font=fonts.metric, anchor="w")
        self.value.pack(fill="x")
        self.sub = tk.Label(inner, text="", bg=PALETTE["panel"], fg=PALETTE["faint"],
                            font=fonts.small, anchor="w")
        self.sub.pack(fill="x")

    def set(self, value, sub=""):
        self.value.configure(text=value)
        self.sub.configure(text=sub)


class Dashboard(tk.Tk):
    WORKER_COLUMNS = [
        ("id", "ID", 36, "center"), ("name", "WORKER", 110, "w"), ("pid", "PID", 62, "center"),
        ("state", "STATE", 84, "w"), ("health", "HEALTH", 112, "w"),
        ("uptime", "UPTIME", 66, "e"), ("restarts", "RESTARTS", 72, "center"),
        ("cpu", "CPU", 50, "e"), ("mem", "MEMORY", 70, "e"),
        ("last_exit", "LAST EXIT", 150, "w"), ("task", "CURRENT TASK", 220, "w"),
    ]
    EVENT_COLUMNS = [
        ("time", "TIME", 96, "w"), ("sev", "SEVERITY", 74, "w"), ("type", "EVENT", 150, "w"),
        ("worker", "WORKER", 110, "w"), ("pid", "PID", 64, "e"), ("action", "SIGNAL / ACTION", 120, "w"),
        ("message", "RESULT", 600, "w"),
    ]

    def __init__(self, config_path):
        super().__init__()
        self.title("Linux Signal-Based Process Controller")
        self.geometry("1440x900")
        self.minsize(1180, 720)
        self.fonts = apply_theme(self)

        self.config_path = os.path.abspath(config_path)
        cfg = read_config(self.config_path)
        sock = cfg.get("socket_path", "run/sigctl.sock")
        if not os.path.isabs(sock):
            sock = os.path.join(ROOT, sock)
        self.client = ControllerClient(sock)
        self.poll_ms = int(cfg.get("monitor_interval_ms", "500") or 500)

        self.queue = queue.Queue()
        self.connected = False
        self.data = {}
        self.workers = {}
        self.selected_id = None
        self.events = []
        self.last_seq = 0
        self.boot_id = None
        self.profiles = []
        self.config_values = {}
        self.busy = set()
        self.status_clear_job = None
        self.stop_event = threading.Event()

        self._build()
        self._update_controls()
        threading.Thread(target=self._poll_loop, daemon=True).start()
        self.after(60, self._drain_queue)
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.bind("<Control-n>", lambda e: self.on_spawn())
        self.bind("<F5>", lambda e: self._request_refresh())

    # ------------------------------------------------------------- layout
    def _build(self):
        p = PALETTE
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)

        # Header
        header = tk.Frame(self, bg=p["panel"], highlightthickness=0)
        header.grid(row=0, column=0, sticky="ew")
        brand = tk.Frame(header, bg=p["panel"])
        brand.pack(side="left", padx=18, pady=12)
        logo = tk.Canvas(brand, width=30, height=30, bg=p["panel"], highlightthickness=0)
        logo.create_rectangle(2, 2, 28, 28, outline=p["accent"], width=2)
        logo.create_line(8, 20, 13, 12, 17, 17, 22, 8, fill=p["accent"], width=2)
        logo.pack(side="left")
        titles = tk.Frame(brand, bg=p["panel"])
        titles.pack(side="left", padx=(10, 0))
        tk.Label(titles, text="SIGCTL", bg=p["panel"], fg=p["text"],
                 font=(self.fonts.sans, 14, "bold")).pack(anchor="w")
        tk.Label(titles, text="Signal-based process controller  ·  intelligent watchdog",
                 bg=p["panel"], fg=p["muted"], font=self.fonts.small).pack(anchor="w")

        right = tk.Frame(header, bg=p["panel"])
        right.pack(side="right", padx=18)
        self.btn_shutdown = ttk.Button(right, text="Shut down controller", style="Danger.TButton",
                                       command=self.on_shutdown)
        self.btn_shutdown.pack(side="right")
        self.btn_settings = ttk.Button(right, text="Settings", command=self.on_settings)
        self.btn_settings.pack(side="right", padx=(0, 8))
        self.btn_watchdog = ttk.Button(right, text="Watchdog: -", style="Toggle.TButton",
                                       command=self.on_toggle_watchdog)
        self.btn_watchdog.pack(side="right", padx=(0, 8))
        self.conn_pill = tk.Label(right, text="  OFFLINE  ", bg="#3a1f23", fg=p["error"],
                                  font=(self.fonts.sans, 9, "bold"), padx=8, pady=4)
        self.conn_pill.pack(side="right", padx=(0, 14))
        tk.Frame(self, bg=p["border"], height=1).grid(row=0, column=0, sticky="sew")

        # Metric cards
        cards = tk.Frame(self, bg=p["bg"])
        cards.grid(row=1, column=0, sticky="ew", padx=16, pady=(14, 10))
        spec = [("total", "Workers", p["accent"]), ("running", "Running", p["ok"]),
                ("paused", "Paused", p["paused"]), ("failed", "Failed / stopped", p["error"]),
                ("restarts", "Restarts", p["backoff"]), ("uptime", "Controller uptime", p["muted"])]
        self.cards = {}
        for i, (key, label, color) in enumerate(spec):
            cards.columnconfigure(i, weight=1, uniform="card")
            card = MetricCard(cards, self.fonts, label, color)
            card.grid(row=0, column=i, sticky="ew", padx=(0 if i == 0 else 10, 0))
            self.cards[key] = card

        # Vertical split: workers+details on top, events below
        vsplit = ttk.PanedWindow(self, orient="vertical")
        vsplit.grid(row=2, column=0, sticky="nsew", padx=16)
        hsplit = ttk.PanedWindow(vsplit, orient="horizontal")
        vsplit.add(hsplit, weight=3)
        hsplit.add(self._build_workers(hsplit), weight=3)
        hsplit.add(self._build_details(hsplit), weight=1)
        vsplit.add(self._build_events(vsplit), weight=2)
        self.after(150, lambda: self._init_sashes(vsplit, hsplit))

        # Status bar
        bar = tk.Frame(self, bg=p["panel"])
        bar.grid(row=3, column=0, sticky="ew", pady=(10, 0))
        self.status = tk.Label(bar, text="Connecting to controller...", bg=p["panel"],
                               fg=p["muted"], font=self.fonts.small, anchor="w")
        self.status.pack(side="left", padx=16, pady=6)
        self.status_right = tk.Label(bar, text=self.client.socket_path, bg=p["panel"],
                                     fg=p["faint"], font=self.fonts.small)
        self.status_right.pack(side="right", padx=16)

    def _init_sashes(self, vsplit, hsplit):
        try:
            hsplit.sashpos(0, int(hsplit.winfo_width() * 0.70))
            vsplit.sashpos(0, int(vsplit.winfo_height() * 0.60))
        except tk.TclError:
            pass

    def _panel(self, master):
        return tk.Frame(master, bg=PALETTE["panel"], highlightthickness=1,
                        highlightbackground=PALETTE["border"])

    def _build_workers(self, master):
        p = PALETTE
        frame = self._panel(master)
        top = tk.Frame(frame, bg=p["panel"])
        top.pack(fill="x", padx=12, pady=(10, 8))
        tk.Label(top, text="Workers", bg=p["panel"], fg=p["text"],
                 font=self.fonts.heading).pack(side="left")
        self.btn_stopall = ttk.Button(top, text="Stop all", style="Danger.TButton",
                                      command=self.on_stop_all)
        self.btn_stopall.pack(side="right")
        self.btn_spawn = ttk.Button(top, text="+  Start worker", style="Accent.TButton",
                                    command=self.on_spawn)
        self.btn_spawn.pack(side="right", padx=(0, 8))

        tools = FlowFrame(frame, bg=p["panel"], height=32)
        tools.pack(fill="x", padx=12, pady=(0, 8))
        self.tool_buttons = {}
        for key, text, cmd in [
            ("pause", "Pause  SIGSTOP", lambda: self.worker_action("PAUSE", "Pause")),
            ("resume", "Resume  SIGCONT", lambda: self.worker_action("RESUME", "Resume")),
            ("status", "Status  SIGUSR1", lambda: self.worker_action("STATUS", "Status request")),
            ("snapshot", "Snapshot  SIGUSR2", lambda: self.worker_action("SNAPSHOT", "Snapshot")),
            ("restart", "Restart", self.on_restart),
            ("stop", "Stop  SIGTERM", self.on_stop),
            ("fault", "Inject fault", self.on_fault_menu),
            ("remove", "Remove", self.on_remove),
        ]:
            b = ttk.Button(tools, text=text, command=cmd, style="Tool.TButton")
            self.tool_buttons[key] = b
        self.after_idle(tools.reflow)

        self.fault_menu = tk.Menu(self, tearoff=0)
        self.fault_menu.add_command(label="Crash (abort -> SIGABRT)",
                                    command=lambda: self.on_fault("crash"))
        self.fault_menu.add_command(label="Segmentation fault (SIGSEGV)",
                                    command=lambda: self.on_fault("segv"))
        self.fault_menu.add_command(label="Exit with code 3",
                                    command=lambda: self.on_fault("exit 3"))
        self.fault_menu.add_command(label="Hang (stop consuming signals)",
                                    command=lambda: self.on_fault("hang"))

        holder = tk.Frame(frame, bg=p["panel"])
        holder.pack(fill="both", expand=True, padx=1, pady=(0, 1))
        cols = [c[0] for c in self.WORKER_COLUMNS]
        self.tree = ttk.Treeview(holder, columns=cols, show="headings", selectmode="browse")
        for key, title, width, anchor in self.WORKER_COLUMNS:
            self.tree.heading(key, text=title, anchor=anchor if anchor != "e" else "e")
            self.tree.column(key, width=width, minwidth=36, anchor=anchor,
                             stretch=key in ("task", "last_exit"))
        for state, color in STATE_COLORS.items():
            self.tree.tag_configure(state, foreground=color)
        self.tree.tag_configure("odd", background="#171b22")
        sb = ttk.Scrollbar(holder, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

        # Empty / offline overlay
        self.empty = tk.Frame(holder, bg=p["panel"])
        self.empty_title = tk.Label(self.empty, text="", bg=p["panel"], fg=p["text"],
                                    font=self.fonts.heading)
        self.empty_title.pack()
        self.empty_text = tk.Label(self.empty, text="", bg=p["panel"], fg=p["muted"],
                                   font=self.fonts.small, justify="center")
        self.empty_text.pack(pady=(4, 12))
        self.empty_btn = ttk.Button(self.empty, text="", style="Accent.TButton")
        self.empty_btn.pack()
        return frame

    def _build_details(self, master):
        p = PALETTE
        frame = self._panel(master)
        head = tk.Frame(frame, bg=p["panel"])
        head.pack(fill="x", padx=14, pady=(12, 6))
        self.d_title = tk.Label(head, text="No worker selected", bg=p["panel"], fg=p["text"],
                                font=self.fonts.heading, anchor="w")
        self.d_title.pack(side="left")
        self.d_badge = tk.Label(head, text="", bg=p["panel"], fg=p["muted"],
                                font=(self.fonts.sans, 8, "bold"), padx=7, pady=2)
        self.d_badge.pack(side="right")

        nb = ttk.Notebook(frame)
        nb.pack(fill="both", expand=True, padx=8, pady=(0, 8))

        overview = tk.Frame(nb, bg=p["panel_hi"])
        nb.add(overview, text="Overview")
        self.kv = {}
        rows = [("profile", "Profile"), ("pid", "PID"), ("ownership", "Parent / group"),
                ("proc", "Kernel state"), ("health", "Health"), ("uptime", "Uptime"),
                ("restarts", "Restarts"), ("failures", "Consecutive fails"),
                ("exit", "Last exit"), ("reason", "Recovery note"),
                ("cpu", "CPU time"), ("rss", "Memory (RSS)"), ("ctx", "Context switches"),
                ("heartbeat", "Last heartbeat")]
        for i, (key, label) in enumerate(rows):
            tk.Label(overview, text=label, bg=p["panel_hi"], fg=p["muted"], font=self.fonts.small,
                     anchor="w").grid(row=i, column=0, sticky="nw", padx=(12, 8), pady=1)
            val = tk.Label(overview, text="-", bg=p["panel_hi"], fg=p["text"],
                           font=self.fonts.mono_body, anchor="w", justify="left", wraplength=300)
            val.grid(row=i, column=1, sticky="w", pady=1)
            self.kv[key] = val
        overview.columnconfigure(1, weight=1)

        self.reports = self._text_tab(nb, "Reports")
        self.health_list = self._list_tab(nb, "Health")
        self.restart_list = self._list_tab(nb, "Restarts")
        self.wevents = self._list_tab(nb, "Events")
        return frame

    def _text_tab(self, nb, title):
        t = tk.Text(nb, bg=PALETTE["panel_hi"], fg=PALETTE["text"], font=self.fonts.mono_small,
                    relief="flat", wrap="word", padx=10, pady=8, insertbackground=PALETTE["text"],
                    highlightthickness=0)
        nb.add(t, text=title)
        t.configure(state="disabled")
        return t

    def _list_tab(self, nb, title):
        tree = ttk.Treeview(nb, columns=("ts", "text"), show="headings", style="Events.Treeview")
        tree.heading("ts", text="TIME", anchor="w")
        tree.heading("text", text="DETAIL", anchor="w")
        tree.column("ts", width=86, stretch=False)
        tree.column("text", width=260)
        for sev, color in SEVERITY_COLORS.items():
            tree.tag_configure(sev, foreground=color)
        nb.add(tree, text=title)
        return tree

    def _build_events(self, master):
        p = PALETTE
        frame = self._panel(master)
        top = tk.Frame(frame, bg=p["panel"])
        top.pack(fill="x", padx=12, pady=(10, 8))
        tk.Label(top, text="Live event monitor", bg=p["panel"], fg=p["text"],
                 font=self.fonts.heading).pack(side="left")
        self.ev_count = tk.Label(top, text="", bg=p["panel"], fg=p["faint"], font=self.fonts.small)
        self.ev_count.pack(side="left", padx=10)
        self.filter = tk.StringVar(value="All events")
        cb = ttk.Combobox(top, textvariable=self.filter, state="readonly", width=20,
                          values=["All events", "Warnings and errors", "Errors only",
                                  "Selected worker"])
        cb.pack(side="right")
        cb.bind("<<ComboboxSelected>>", lambda e: self._render_events(full=True))
        self.log_label = tk.Label(top, text="", bg=p["panel"], fg=p["faint"], font=self.fonts.small)
        self.log_label.pack(side="right", padx=12)

        holder = tk.Frame(frame, bg=p["panel"])
        holder.pack(fill="both", expand=True, padx=1, pady=(0, 1))
        cols = [c[0] for c in self.EVENT_COLUMNS]
        self.ev_tree = ttk.Treeview(holder, columns=cols, show="headings", style="Events.Treeview")
        for key, title, width, anchor in self.EVENT_COLUMNS:
            self.ev_tree.heading(key, text=title, anchor="w" if anchor != "e" else "e")
            self.ev_tree.column(key, width=width, minwidth=40, anchor=anchor,
                                stretch=key == "message")
        for sev, color in SEVERITY_COLORS.items():
            self.ev_tree.tag_configure(sev, foreground=color)
        self.ev_tree.tag_configure("info", foreground=PALETTE["text"])
        sb = ttk.Scrollbar(holder, orient="vertical", command=self.ev_tree.yview)
        self.ev_tree.configure(yscrollcommand=sb.set)
        self.ev_tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        return frame

    # ------------------------------------------------------------ polling
    def _poll_loop(self):
        while not self.stop_event.is_set():
            started = time.time()
            try:
                listing = self.client.request("LIST", timeout=3)
                events = self.client.request(f"EVENTS {self.last_seq} 400", timeout=3)
                info = None
                sel = self.selected_id
                if sel is not None:
                    try:
                        info = self.client.request(f"INFO {sel}", timeout=3)
                    except ControllerError:
                        info = None
                extra = {}
                if not self.profiles:
                    extra["profiles"] = self.client.request("PROFILES", timeout=3).get("profiles", [])
                if not self.config_values:
                    extra["config"] = self.client.request("CONFIG", timeout=3).get("config", {})
                self.queue.put(("snapshot", listing, events, info, sel, extra))
            except ControllerError as e:
                self.queue.put(("offline", str(e)))
            interval = max(self.poll_ms, 250) / 1000.0
            self.stop_event.wait(max(0.05, interval - (time.time() - started)))

    def _request_refresh(self):
        self.config_values = {}

    def _drain_queue(self):
        try:
            while True:
                item = self.queue.get_nowait()
                kind = item[0]
                if kind == "snapshot":
                    self._apply_snapshot(*item[1:])
                elif kind == "offline":
                    self._apply_offline(item[1])
                elif kind == "action":
                    self._apply_action_result(*item[1:])
        except queue.Empty:
            pass
        if not self.stop_event.is_set():
            self.after(80, self._drain_queue)

    # ----------------------------------------------------------- applying
    def _apply_offline(self, reason):
        if self.connected:
            self.flash(f"Lost connection to controller: {reason}", "error")
        self.connected = False
        self.data = {}
        self.conn_pill.configure(text="  OFFLINE  ", bg="#3a1f23", fg=PALETTE["error"])
        self.btn_watchdog.configure(text="Watchdog: -")
        for card in self.cards.values():
            card.set("-")
        for iid in self.tree.get_children():
            self.tree.delete(iid)
        self.workers = {}
        self._show_empty("Controller is not running",
                         "Start the controller to manage worker processes.\n"
                         "The dashboard will connect automatically.",
                         "Start controller", self.on_start_controller)
        self._update_controls()
        self._render_details(None)
        if self.status.cget("fg") == PALETTE["muted"]:
            self.status.configure(text=f"Offline: {reason}")

    def _apply_snapshot(self, listing, events, info, sel, extra):
        if not listing.get("ok"):
            return
        if not self.connected:
            self.flash("Connected to controller", "ok")
        self.connected = True
        ctl = listing["controller"]
        self.data = ctl
        if "profiles" in extra:
            self.profiles = extra["profiles"]
        if "config" in extra:
            self.config_values = extra["config"]
            self.poll_ms = int(self.config_values.get("monitor_interval_ms", self.poll_ms))

        pill = ("  SHUTTING DOWN  ", "#3a2c14", PALETTE["warn"]) if ctl["shutting_down"] else \
               (f"  CONNECTED  ·  PID {ctl['pid']}  ", "#12291f", PALETTE["ok"])
        self.conn_pill.configure(text=pill[0], bg=pill[1], fg=pill[2])
        self.btn_watchdog.configure(text=f"Watchdog: {'ON' if ctl['watchdog'] else 'OFF'}")

        self.cards["total"].set(str(ctl["total"]), f"of {ctl['max_workers']} slots")
        self.cards["running"].set(str(ctl["running"]),
                                  f"{ctl['starting']} starting" if ctl["starting"] else "verified by handshake")
        self.cards["paused"].set(str(ctl["paused"]), "SIGSTOP confirmed")
        self.cards["failed"].set(f"{ctl['failed']} / {ctl['stopped']}",
                                 f"{ctl['backoff']} awaiting restart" if ctl["backoff"] else "failed / stopped")
        self.cards["restarts"].set(str(ctl["restarts"]),
                                   "watchdog on" if ctl["watchdog"] else "watchdog off")
        self.cards["uptime"].set(fmt_duration(ctl["uptime_ms"]), f"since {ctl['started'][11:19]}")
        log_note = ctl["log_file"] if ctl["log_ok"] else f"LOG UNAVAILABLE: {ctl['log_error']}"
        self.log_label.configure(text=log_note, fg=PALETTE["faint"] if ctl["log_ok"] else PALETTE["error"])

        self._render_workers(listing["workers"])

        if events.get("ok"):
            if events["boot_id"] != self.boot_id:
                if self.boot_id is not None:
                    self.flash("Controller restarted; event feed reset", "warn")
                self.boot_id = events["boot_id"]
                self.events = []
                self.last_seq = 0
                self._render_events(full=True)
            new = [e for e in events["events"] if e["seq"] > self.last_seq]
            if new:
                self.events.extend(new)
                self.events = self.events[-MAX_EVENTS:]
                self.last_seq = new[-1]["seq"]
                self._render_events(new=new)

        if sel == self.selected_id:
            self._render_details(info if info and info.get("ok") else None)
        self.status_right.configure(text=f"Updated {time.strftime('%H:%M:%S')}  ·  {self.client.socket_path}")
        self._update_controls()

    def _render_workers(self, workers):
        self.workers = {w["id"]: w for w in workers}
        existing = set(self.tree.get_children())
        for index, w in enumerate(workers):
            iid = str(w["id"])
            health = w["health"]
            if w["state"] == "backoff":
                health = f"restart in {w['restart_in_ms'] / 1000:.1f}s"
            elif health == "none":
                health = "-"
            if w["pending"]:
                health = f"{w['pending']}..."
            values = (
                w["id"], w["name"], w["pid"] or "-", w["state"], health,
                fmt_duration(w["uptime_ms"]) if w["pid"] else "-", w["restarts"],
                f"{w['cpu_pct']:.0f}%" if w["pid"] else "-", fmt_mem(w["rss_kb"]),
                w["last_exit"] or "-", w["task"] if w["pid"] else (w["fail_reason"] or w["task"]),
            )
            tags = (w["state"], "odd" if index % 2 else "even")
            if iid in existing:
                self.tree.item(iid, values=values, tags=tags)
                existing.discard(iid)
            else:
                self.tree.insert("", "end", iid=iid, values=values, tags=tags)
        for iid in existing:
            self.tree.delete(iid)
        if self.selected_id is not None and str(self.selected_id) not in self.tree.get_children():
            self.selected_id = None
            self._render_details(None)
        if not workers:
            self._show_empty("No workers yet",
                             "Start a worker to see live process control.\n"
                             "Test profiles (crashy, flaky, sleepy) demonstrate recovery.",
                             "+  Start worker", self.on_spawn)
        else:
            self.empty.place_forget()

    def _show_empty(self, title, text, button, command):
        self.empty_title.configure(text=title)
        self.empty_text.configure(text=text)
        self.empty_btn.configure(text=button, command=command)
        self.empty.place(relx=0.5, rely=0.5, anchor="center")

    def _event_visible(self, e):
        f = self.filter.get()
        if f == "Warnings and errors":
            return e["severity"] in ("warn", "error")
        if f == "Errors only":
            return e["severity"] == "error"
        if f == "Selected worker":
            return self.selected_id is not None and e["worker_id"] == self.selected_id
        return True

    def _event_values(self, e):
        return (e["ts"][11:23], e["severity"].upper(), e["type"], e["worker"] or "controller",
                e["pid"] or "", e["action"], e["message"])

    def _render_events(self, new=None, full=False):
        if full:
            self.ev_tree.delete(*self.ev_tree.get_children())
            source = self.events
        else:
            source = new or []
        for e in source:
            if self._event_visible(e):
                self.ev_tree.insert("", 0, values=self._event_values(e), tags=(e["severity"],))
        children = self.ev_tree.get_children()
        if len(children) > 500:
            self.ev_tree.delete(*children[500:])
        warn = sum(1 for e in self.events if e["severity"] in ("warn", "error"))
        self.ev_count.configure(text=f"{len(self.events)} events  ·  {warn} warnings/errors")

    def _set_text(self, widget, text):
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", text)
        widget.configure(state="disabled")

    def _fill_list(self, tree, rows):
        tree.delete(*tree.get_children())
        for ts, text, sev in rows:
            tree.insert("", "end", values=(ts, text), tags=(sev,))

    def _render_details(self, info):
        p = PALETTE
        if not info:
            self.d_title.configure(text="No worker selected" if self.selected_id is None else "Loading...")
            self.d_badge.configure(text="", bg=p["panel"])
            for v in self.kv.values():
                v.configure(text="-", fg=p["text"])
            self._set_text(self.reports, "Select a worker to see its latest SIGUSR1 status report "
                                         "and SIGUSR2 diagnostic snapshot.")
            for tree in (self.health_list, self.restart_list, self.wevents):
                tree.delete(*tree.get_children())
            return
        w, pr = info["worker"], info.get("proc")
        color = STATE_COLORS.get(w["state"], p["muted"])
        self.d_title.configure(text=f"{w['name']}  ·  #{w['id']}")
        self.d_badge.configure(text=w["state"].upper(), fg=color, bg=p["panel_hi"])
        kv = self.kv
        kv["profile"].configure(text=w["profile"])
        kv["pid"].configure(text=str(w["pid"]) if w["pid"] else "- (no process)")
        if pr:
            kv["ownership"].configure(
                text=f"ppid {pr['ppid']} {'(controller)' if pr['owned'] else '(NOT OWNED)'}, pgid {pr['pgid']}",
                fg=p["text"] if pr["owned"] else p["error"])
            kv["proc"].configure(text=f"{pr['state']} ({pr['state_name']}), {pr['threads']} thread(s)")
            kv["cpu"].configure(text=f"{pr['cpu_seconds']:.2f} s  ({w['cpu_pct']:.0f}% now)")
            kv["rss"].configure(text=fmt_mem(pr["rss_kb"]))
            kv["ctx"].configure(text=f"{pr['voluntary_ctxt_switches']} voluntary, "
                                     f"{pr['nonvoluntary_ctxt_switches']} involuntary")
        else:
            for key in ("ownership", "proc", "cpu", "rss", "ctx"):
                kv[key].configure(text="-", fg=p["text"])
        hcolor = {"ok": p["ok"], "late": p["warn"], "unresponsive": p["error"],
                  "paused": p["paused"]}.get(w["health"], p["muted"])
        kv["health"].configure(text=w["health"], fg=hcolor)
        kv["uptime"].configure(text=f"{fmt_duration(w['uptime_ms'])}  (since {w['started'][11:19]})"
                               if w["pid"] else "-")
        kv["restarts"].configure(text=str(w["restarts"]))
        kv["failures"].configure(text=str(w["consecutive_failures"]))
        kv["exit"].configure(text=f"{w['last_exit']}  at {w['exit_time'][11:19]}" if w["last_exit"] else "-",
                             fg=p["error"] if w["exit_signal"] or (w["exit_code"] not in (-1, 0)) else p["text"])
        kv["reason"].configure(text=w["fail_reason"] or "-",
                               fg=p["error"] if w["fail_reason"] else p["text"])
        kv["heartbeat"].configure(text=f"{w['heartbeat_age_ms']} ms ago" if w["pid"] else "-")

        parts = []
        for label, raw in (("SIGUSR1 status report", w["last_status"]),
                           ("SIGUSR2 diagnostic snapshot", w["last_snapshot"])):
            parts.append(f"{label}\n" + "-" * len(label))
            if raw:
                try:
                    parts.append(json.dumps(json.loads(raw), indent=2))
                except json.JSONDecodeError:
                    parts.append(raw)
            else:
                parts.append("(none yet - use the toolbar to request one)")
            parts.append("")
        self._set_text(self.reports, "\n".join(parts))

        self._fill_list(self.health_list, [(h["ts"][11:19], h["text"],
                                            "warn" if "no " in h["text"] or "missing" in h["text"] else "info")
                                           for h in w["health_history"]])
        self._fill_list(self.restart_list, [(h["ts"][11:19], h["text"], "ok")
                                            for h in w["restart_history"]])
        self._fill_list(self.wevents, [(e["ts"][11:19], f"{e['type']}: {e['message']}", e["severity"])
                                       for e in reversed(info.get("events", []))])

    # ---------------------------------------------------------- controls
    def _on_select(self, _event=None):
        sel = self.tree.selection()
        self.selected_id = int(sel[0]) if sel else None
        self._render_details(None)
        if self.filter.get() == "Selected worker":
            self._render_events(full=True)
        self._update_controls()

    def _update_controls(self):
        w = self.workers.get(self.selected_id) if self.connected else None
        st = w["state"] if w else None
        busy = bool(w and (w["pending"] or w["id"] in self.busy))
        shutting = bool(self.data.get("shutting_down"))
        allow = {
            "pause":    st == "running",
            "resume":   st == "paused",
            "status":   st == "running",
            "snapshot": st == "running",
            "restart":  st in ("running", "paused", "stopped", "completed", "failed", "backoff"),
            "stop":     st in ("running", "paused", "starting", "backoff"),
            "fault":    st == "running",
            "remove":   bool(w) and not w["pid"],
        }
        for key, button in self.tool_buttons.items():
            ok = allow[key] and not busy and not shutting
            button.state(["!disabled"] if ok else ["disabled"])
        live = sum(1 for x in self.workers.values() if x["pid"] or x["state"] == "backoff")
        for button, ok in ((self.btn_spawn, self.connected and not shutting),
                           (self.btn_stopall, self.connected and live > 0 and not shutting),
                           (self.btn_watchdog, self.connected and not shutting),
                           (self.btn_settings, self.connected and not shutting),
                           (self.btn_shutdown, self.connected and not shutting)):
            button.state(["!disabled"] if ok else ["disabled"])

    def flash(self, message, level="info"):
        colors = {"ok": PALETTE["ok"], "error": PALETTE["error"], "warn": PALETTE["warn"],
                  "info": PALETTE["text"]}
        self.status.configure(text=f"{time.strftime('%H:%M:%S')}  {message}", fg=colors[level])
        if self.status_clear_job:
            self.after_cancel(self.status_clear_job)
        self.status_clear_job = self.after(9000, lambda: self.status.configure(fg=PALETTE["muted"]))

    # ---------------------------------------------------------- actions
    def run_action(self, label, command, worker_id=None, timeout=15):
        """Send a command in a background thread; report the result."""
        if worker_id is not None:
            self.busy.add(worker_id)
            self._update_controls()
        self.flash(f"{label}...", "info")

        def work():
            try:
                result = self.client.request(command, timeout=timeout)
            except ControllerError as e:
                result = {"ok": False, "error": str(e)}
            self.queue.put(("action", label, result, worker_id))

        threading.Thread(target=work, daemon=True).start()

    def _apply_action_result(self, label, result, worker_id):
        self.busy.discard(worker_id)
        if result.get("ok"):
            self.flash(f"{label}: {result.get('message', 'done')}", "ok")
        else:
            self.flash(f"{label} failed: {result.get('error', 'unknown error')}", "error")
        if label.startswith("Settings") and result.get("config"):
            self.config_values = result["config"]
        self._update_controls()

    def _selected(self):
        return self.workers.get(self.selected_id)

    def worker_action(self, verb, label):
        w = self._selected()
        if w:
            self.run_action(f"{label} '{w['name']}'", f"{verb} {w['id']}", w["id"])

    def confirm(self, title, message, detail="", ok_text="Confirm", danger=True):
        return ConfirmDialog(self, self.fonts, title, message, detail, ok_text, danger).show()

    def on_spawn(self):
        if not self.connected:
            return
        if not self.profiles:
            self.flash("Profiles not loaded yet; try again in a moment", "warn")
            return
        res = SpawnDialog(self, self.fonts, self.profiles).show()
        if not res:
            return
        profile, name, count = res

        def work():
            ok = 0
            last = {}
            for _ in range(count):
                try:
                    last = self.client.request(f"SPAWN {profile}" + (f" {name}" if name else ""))
                except ControllerError as e:
                    last = {"ok": False, "error": str(e)}
                if not last.get("ok"):
                    break
                ok += 1
            msg = {"ok": ok == count, "message": f"{ok} worker(s) started",
                   "error": last.get("error", "")}
            self.queue.put(("action", f"Start {profile}", msg, None))

        threading.Thread(target=work, daemon=True).start()

    def on_stop(self):
        w = self._selected()
        if w and self.confirm("Stop worker", f"Send SIGTERM to '{w['name']}' (PID {w['pid'] or '-'})?",
                              "The worker finishes cleanly and exits. If it does not exit within the "
                              "grace period the controller escalates to SIGKILL. An intentional stop "
                              "is never restarted by the watchdog.", "Stop worker"):
            self.run_action(f"Stop '{w['name']}'", f"STOP {w['id']}", w["id"])

    def on_restart(self):
        w = self._selected()
        if not w:
            return
        if w["pid"] and not self.confirm("Restart worker",
                                         f"Gracefully stop and restart '{w['name']}'?",
                                         "SIGTERM is sent first; a new process is created once the "
                                         "old one has been reaped.", "Restart", danger=False):
            return
        self.run_action(f"Restart '{w['name']}'", f"RESTART {w['id']}", w["id"])

    def on_remove(self):
        w = self._selected()
        if w and self.confirm("Remove worker", f"Remove '{w['name']}' from the registry?",
                              "Its history stays in the event log.", "Remove"):
            self.run_action(f"Remove '{w['name']}'", f"REMOVE {w['id']}")

    def on_fault_menu(self):
        b = self.tool_buttons["fault"]
        self.fault_menu.tk_popup(b.winfo_rootx(), b.winfo_rooty() + b.winfo_height())

    def on_fault(self, kind):
        w = self._selected()
        if w and self.confirm("Inject test fault", f"Make '{w['name']}' fail on purpose ({kind})?",
                              "This is a testing aid that demonstrates crash detection and watchdog "
                              "recovery. The worker receives the instruction through its command pipe.",
                              "Inject fault"):
            self.run_action(f"Fault '{kind}' on '{w['name']}'", f"FAULT {w['id']} {kind}", w["id"])

    def on_stop_all(self):
        if self.confirm("Stop all workers", "Send SIGTERM to every worker owned by this controller?",
                        "Pending automatic restarts are cancelled. Processes not started by this "
                        "controller are never affected.", "Stop all"):
            self.run_action("Stop all", "STOPALL")

    def on_toggle_watchdog(self):
        enable = not self.data.get("watchdog", True)
        self.run_action("Watchdog", f"WATCHDOG {'on' if enable else 'off'}")

    def on_settings(self):
        if not self.config_values:
            try:
                self.config_values = self.client.request("CONFIG").get("config", {})
            except ControllerError as e:
                self.flash(f"Cannot load settings: {e}", "error")
                return
        res = SettingsDialog(self, self.fonts, self.config_values).show()
        if not res:
            return
        changes, save = res

        def work():
            errors, last = [], None
            for key, value in changes:
                try:
                    r = self.client.request(f"CONFIG SET {key} {value}")
                except ControllerError as e:
                    r = {"ok": False, "error": str(e)}
                if r.get("ok"):
                    last = r
                else:
                    errors.append(f"{key}: {r.get('error')}")
            if save and not errors:
                try:
                    r = self.client.request("CONFIG SAVE")
                    if not r.get("ok"):
                        errors.append(r.get("error"))
                    else:
                        last = r
                except ControllerError as e:
                    errors.append(str(e))
            if errors:
                result = {"ok": False, "error": "; ".join(errors)}
            else:
                result = {"ok": True, "config": (last or {}).get("config"),
                          "message": f"{len(changes)} change(s) applied" + (" and saved" if save else "")}
            self.queue.put(("action", "Settings", result, None))

        threading.Thread(target=work, daemon=True).start()

    def on_shutdown(self):
        live = sum(1 for w in self.workers.values() if w["pid"])
        if self.confirm("Shut down controller",
                        f"Stop the controller and its {live} running worker(s)?",
                        "Every worker receives SIGTERM and is reaped before the controller exits. "
                        "The event log is kept.", "Shut down"):
            self.run_action("Shutdown", "SHUTDOWN")

    def on_start_controller(self):
        exe = os.path.join(ROOT, "build", "sigctld")
        if not os.access(exe, os.X_OK):
            self.flash("build/sigctld not found: run 'make' in the project folder first", "error")
            return
        os.makedirs(os.path.join(ROOT, "logs"), exist_ok=True)
        out = open(os.path.join(ROOT, "logs", "controller.out"), "a")
        try:
            # New session: closing the dashboard must not stop the controller.
            proc = subprocess.Popen([exe, "-q", "-c", self.config_path], cwd=ROOT, stdout=out,
                                    stderr=subprocess.STDOUT, start_new_session=True)
        except OSError as e:
            self.flash(f"Cannot start controller: {e}", "error")
            return
        finally:
            out.close()
        self.flash(f"Controller starting (pid {proc.pid})...", "info")
        self.after(1500, lambda: proc.poll() is not None and self.flash(
            "Controller exited immediately; see logs/controller.out", "error"))

    def _on_close(self):
        self.stop_event.set()
        self.destroy()


def main():
    parser = argparse.ArgumentParser(description="Dashboard for sigctld")
    parser.add_argument("-c", "--config", default=os.path.join(ROOT, "config", "sigctl.conf"))
    args = parser.parse_args()
    app = Dashboard(args.config)
    app.mainloop()


if __name__ == "__main__":
    main()
