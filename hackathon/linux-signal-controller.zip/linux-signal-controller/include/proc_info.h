/*
 * proc_info.h - Read process information from the Linux /proc filesystem.
 */
#ifndef SIGCTL_PROC_INFO_H
#define SIGCTL_PROC_INFO_H

#include <sys/types.h>

typedef struct {
    char               state;        /* R, S, D, T, Z ... from /proc/pid/stat */
    pid_t              ppid;
    pid_t              pgid;
    unsigned long long cpu_ticks;    /* utime + stime                          */
    long               rss_kb;
    int                threads;
    long long          vol_ctxt;     /* voluntary context switches             */
    long long          invol_ctxt;   /* involuntary context switches           */
} proc_info_t;

/* Returns 0 on success, -1 if the process does not exist or cannot be read. */
int proc_read(pid_t pid, proc_info_t *out);

/* 1 if pid exists and its parent is `parent`, 0 otherwise. */
int proc_is_child_of(pid_t pid, pid_t parent);

/* Human readable meaning of a /proc state letter. */
const char *proc_state_name(char state);

/* Clock ticks per second (sysconf(_SC_CLK_TCK)). */
long proc_clk_tck(void);

#endif /* SIGCTL_PROC_INFO_H */
