/*
 * watchdog.h - Recovery policy (pure functions) and runtime hooks.
 *
 * The policy functions take plain values and return a decision, so they
 * can be unit tested without forking any process.
 */
#ifndef SIGCTL_WATCHDOG_H
#define SIGCTL_WATCHDOG_H

#include <stdint.h>

typedef enum {
    WD_INTENTIONAL = 0,  /* stop was requested: never restart                */
    WD_COMPLETED,        /* exited with code 0 on its own: task finished     */
    WD_START_FAILURE,    /* exec failed / died instantly: restarting is futile */
    WD_DISABLED,         /* failure, but the watchdog is switched off         */
    WD_RESTART,          /* failure, eligible: restart after a backoff delay  */
    WD_LIMIT             /* failure, restart limit exceeded: give up          */
} wd_decision_t;

typedef struct {
    int     stop_requested;      /* controller sent SIGTERM on purpose        */
    int     exited;              /* WIFEXITED                                 */
    int     exit_code;           /* WEXITSTATUS                               */
    int     signaled;            /* WIFSIGNALED                               */
    int64_t uptime_ms;           /* how long this incarnation ran             */
    int     watchdog_enabled;
    int     max_restarts;
    int     stable_reset_s;
    int     consecutive_failures;/* failures before this one                  */
} wd_input_t;

typedef struct {
    wd_decision_t decision;
    int           failures;      /* updated consecutive failure count         */
    int64_t       delay_ms;      /* for WD_RESTART                            */
} wd_result_t;

/* Exponential backoff: base * 2^(attempt-1), capped at max. attempt >= 1. */
int64_t watchdog_backoff_ms(int attempt, int base_ms, int max_ms);

/* Decide what to do after a worker terminated. */
wd_result_t watchdog_decide(const wd_input_t *in, int base_ms, int max_ms);

const char *watchdog_decision_name(wd_decision_t d);

/* Exit code used by the worker (and the child after a failed exec) to say
 * "could not start". */
#define EXIT_START_FAILURE 127
/* A worker that dies within this many ms with code 127 is a start failure. */
#define START_FAILURE_WINDOW_MS 2000

#endif /* SIGCTL_WATCHDOG_H */
