/*
 * tasks.h - Workloads executed by worker processes.
 *
 * A task is advanced in small steps so the worker can check for signals,
 * commands and heartbeat deadlines between steps.
 */
#ifndef SIGCTL_TASKS_H
#define SIGCTL_TASKS_H

#include <stddef.h>

typedef struct task task_t;

task_t     *task_create(const char *name, char *err, size_t n);
void        task_step(task_t *t);                 /* one small unit of work */
long long   task_progress(const task_t *t);
void        task_describe(const task_t *t, char *buf, size_t n);
const char *task_name(const task_t *t);
void        task_destroy(task_t *t);

#endif /* SIGCTL_TASKS_H */
