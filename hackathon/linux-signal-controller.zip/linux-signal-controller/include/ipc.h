/*
 * ipc.h - Unix domain socket server used by the GUI and the CLI client.
 *
 * Protocol (see docs/PROTOCOL.md): the client connects, sends ONE request
 * line terminated by '\n', receives ONE JSON line, and the connection is
 * closed. One-shot connections make GUI disconnects harmless.
 */
#ifndef SIGCTL_IPC_H
#define SIGCTL_IPC_H

#include <stddef.h>

/* Create, bind (mode 0600) and listen. Returns the fd or -1. */
int ipc_listen(const char *path, char *err, size_t errlen);

/*
 * Accept one client, verify with SO_PEERCRED that it runs as our own user,
 * and read its request line (bounded time and size).
 * Returns the client fd (request in `line`), or -1 if the client was
 * rejected or failed (the reason is written to err).
 */
int ipc_accept(int lfd, char *line, size_t n, char *err, size_t errlen);

/* Send `json` + '\n' and close the client fd. Write errors (e.g. the GUI
 * already disconnected) are reported but never fatal. Returns 0 or -1. */
int ipc_reply(int cfd, const char *json);

#endif /* SIGCTL_IPC_H */
