/*
 * signals.h - Controller-side signal management.
 *
 * Strategy: asynchronous handlers installed with sigaction() only set
 * volatile sig_atomic_t flags and write one byte to a non-blocking
 * "self-pipe". The main loop poll()s the read end of that pipe, wakes up,
 * and then does all real work (waitpid, logging, restarts) in normal
 * program context where every function is safe to call.
 */
#ifndef SIGCTL_SIGNALS_H
#define SIGCTL_SIGNALS_H

#include <signal.h>

typedef struct {
    int chld;     /* SIGCHLD: a child changed state (exit, stop, continue)  */
    int term;     /* SIGTERM / SIGINT: graceful shutdown requested          */
    int hup;      /* SIGHUP: reload configuration                           */
    int usr1;     /* SIGUSR1: write a controller diagnostic report          */
} sig_flags_t;

/* Install handlers and create the self-pipe. Returns 0 or -1. */
int  signals_install(void);

/* Read end of the self-pipe, for poll(). */
int  signals_fd(void);

/* Drain the pipe and atomically fetch-and-clear the pending flags. */
void signals_take(sig_flags_t *out);

/* Block every catchable signal (used around fork()). */
void signals_block_all(sigset_t *old);
void signals_restore(const sigset_t *old);

/*
 * Called in the child between fork() and exec(): restore default
 * dispositions (an ignored SIGPIPE would otherwise survive exec) and
 * restore the signal mask that was saved before fork().
 */
void signals_reset_in_child(const sigset_t *old);

#endif /* SIGCTL_SIGNALS_H */
