/*
 * logger.h - Timestamped event log: in-memory ring + persistent JSON lines.
 *
 * Logging is only ever called from the main loop, never from a signal
 * handler, because stdio and malloc are not async-signal-safe.
 */
#ifndef SIGCTL_LOGGER_H
#define SIGCTL_LOGGER_H

#include <stdint.h>
#include "common.h"
#include "json.h"

#define EVENT_RING 2000

typedef enum { SEV_INFO = 0, SEV_OK, SEV_WARN, SEV_ERROR } severity_t;

typedef struct {
    uint64_t   seq;
    int64_t    ts_ms;            /* wall-clock                              */
    severity_t sev;
    char       type[24];         /* e.g. worker_exit, signal_sent           */
    int        worker_id;        /* 0 = controller                          */
    char       worker[NAME_LEN];
    int        pid;
    char       action[24];       /* signal or command                       */
    char       msg[224];         /* result / human readable detail          */
} event_t;

/* Open the log file (append). Returns 0, or -1 if the file failed (the
 * in-memory ring keeps working and the failure is reported to clients). */
int  logger_init(const char *path, int echo_stdout);
int  logger_reopen(const char *path, char *err, size_t errlen);
void logger_close(void);

void log_event(severity_t sev, const char *type, int worker_id,
               const char *worker, int pid, const char *action,
               const char *fmt, ...) __attribute__((format(printf, 7, 8)));

int         logger_file_ok(void);
const char *logger_path(void);
const char *logger_error(void);
uint64_t    logger_last_seq(void);
const char *severity_name(severity_t s);

/* Append a JSON array of events with seq > since (oldest first). */
void logger_events_json(jbuf_t *j, uint64_t since, int limit, int worker_id);

#endif /* SIGCTL_LOGGER_H */
