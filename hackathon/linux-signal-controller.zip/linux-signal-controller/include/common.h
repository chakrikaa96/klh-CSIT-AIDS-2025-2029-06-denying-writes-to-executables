/*
 * common.h - Shared constants and small utilities used by every module.
 *
 * Linux Signal-Based Process Controller
 */
#ifndef SIGCTL_COMMON_H
#define SIGCTL_COMMON_H

#include <stddef.h>
#include <stdint.h>
#include <sys/types.h>

#define SIGCTL_VERSION     "1.0.0"
#define MAX_WORKERS        32      /* worker IDs are 1..MAX_WORKERS          */
#define MAX_LINE           1024    /* max length of one protocol line         */
#define NAME_LEN           32
#define PATH_LEN           256

/* Monotonic clock in milliseconds: used for timers and uptime.             */
int64_t now_ms(void);

/* Wall-clock time in milliseconds since the epoch: used for log timestamps. */
int64_t wall_ms(void);

/* Format wall-clock milliseconds as "YYYY-MM-DDTHH:MM:SS.mmm" (local time). */
void format_wall(int64_t ms, char *buf, size_t n);

/* Human readable name of a signal number ("SIGTERM"), never NULL.          */
const char *signal_name(int sig);

/*
 * Strictly parse a decimal integer in [min, max].
 * Returns 0 on success, -1 if the text is empty, contains junk or is out
 * of range. Used for every value that arrives from the IPC socket.
 */
int parse_long(const char *s, long min, long max, long *out);

/* Put a file descriptor into non-blocking mode. Returns 0 or -1.           */
int set_nonblock(int fd);

/* Copy at most n-1 bytes and always NUL-terminate.                         */
void copy_str(char *dst, const char *src, size_t n);

/* Format a duration in milliseconds as "1h 02m 03s" style text.             */
void format_duration(int64_t ms, char *buf, size_t n);

#endif /* SIGCTL_COMMON_H */
