/*
 * controller.h - Process registry and controller state.
 *
 * Ownership model: the controller only ever signals PIDs stored in this
 * registry, and a registry PID always belongs to one of our own children
 * that has not been reaped yet. Linux cannot reuse a PID until its parent
 * has collected it with waitpid(), so between fork() and waitpid() the PID
 * is guaranteed to name our worker. We clear the PID in the same step in
 * which we reap it, which closes the "stale PID" race. As defence in depth
 * every kill() is also preceded by a /proc ppid check.
 */
#ifndef SIGCTL_CONTROLLER_H
#define SIGCTL_CONTROLLER_H

#include <stdint.h>
#include <sys/types.h>

#include "common.h"
#include "config.h"
#include "json.h"

typedef enum {
    ST_EMPTY = 0,
    ST_STARTING,     /* forked, waiting for the worker's hello message      */
    ST_RUNNING,
    ST_PAUSED,       /* confirmed stopped by waitpid(WUNTRACED)              */
    ST_STOPPING,     /* SIGTERM sent, waiting for exit                       */
    ST_STOPPED,      /* exited after an intentional stop                     */
    ST_COMPLETED,    /* exited with code 0 on its own                        */
    ST_BACKOFF,      /* crashed, restart scheduled                           */
    ST_FAILED        /* crashed, not restarting (limit / disabled / start)   */
} wstate_t;

typedef enum {
    H_NONE = 0,      /* not running                                          */
    H_OK,            /* heartbeats arriving on time                          */
    H_LATE,          /* one or more heartbeats missed                        */
    H_UNRESPONSIVE,  /* alive but not answering (heartbeat / status timeout) */
    H_PAUSED
} health_t;

typedef enum {
    OP_NONE = 0, OP_PAUSE, OP_RESUME, OP_STATUS, OP_SNAPSHOT, OP_STOP, OP_RESTART
} op_t;

/* A request waiting for confirmation (e.g. PAUSE waits for waitpid to
 * report the stop). The client connection is answered when it completes. */
typedef struct {
    op_t    op;
    int     client_fd;       /* -1 if nobody is waiting for the answer      */
    int64_t started_ms;
    int64_t deadline_ms;
    int     escalated;       /* STOP: SIGKILL already sent                   */
} pending_t;

#define HIST_LEN 10

typedef struct {
    int64_t ts_ms;           /* wall clock                                    */
    char    text[96];
} hist_t;

typedef struct {
    int       id;
    int       in_use;
    char      name[NAME_LEN];
    char      profile[16];
    pid_t     pid;               /* 0 = no live process                       */
    wstate_t  state;
    health_t  health;

    int       status_fd;         /* worker -> controller pipe (read end)      */
    int       cmd_fd;            /* controller -> worker pipe (write end)     */
    char      rbuf[MAX_LINE];
    size_t    rlen;

    int64_t   created_wall_ms;
    int64_t   started_ms;        /* monotonic, current incarnation            */
    int64_t   started_wall_ms;
    int64_t   last_heartbeat_ms;
    long long progress;
    char      task[96];

    int       restarts_total;
    int       consecutive_failures;
    int64_t   restart_at_ms;     /* ST_BACKOFF: when to restart               */
    int       stop_requested;
    int       restart_after_stop;

    int       exit_valid;
    int       exit_code;
    int       exit_signal;
    int       exit_core;
    char      exit_desc[96];
    int64_t   exit_wall_ms;
    char      fail_reason[96];

    pending_t pend;

    char      last_status[MAX_LINE];
    int64_t   last_status_wall_ms;
    char      last_snapshot[MAX_LINE];
    int64_t   last_snapshot_wall_ms;

    hist_t    health_hist[HIST_LEN];
    int       health_hist_n;
    hist_t    restart_hist[HIST_LEN];
    int       restart_hist_n;

    /* /proc metrics */
    char      proc_state;
    double    cpu_pct;
    long      rss_kb;
    int       threads;
    unsigned long long prev_ticks;
    int64_t   prev_ticks_ms;
} worker_t;

typedef struct {
    config_t  cfg;
    char      config_path[PATH_LEN];
    worker_t  w[MAX_WORKERS + 1];    /* index = worker id, slot 0 unused     */
    int       listen_fd;
    int       lock_fd;
    int64_t   start_ms;
    int64_t   start_wall_ms;
    char      boot_id[24];
    int       name_seq;

    int       shutting_down;
    int64_t   shutdown_deadline_ms;
    int       shutdown_escalated;
    int       exit_now;
    int64_t   last_metrics_ms;
} controller_t;

extern controller_t g_ctl;

/* ---- registry.c ------------------------------------------------------- */
typedef struct {
    const char *name;
    const char *task;
    const char *description;
    int         crash_after_s;
    int         exit_after_s;
    int         exit_code;
    int         reply_delay_ms;
} profile_t;

const profile_t *profile_find(const char *name);
void        profiles_json(jbuf_t *j);
const char *state_name(wstate_t s);
const char *health_name(health_t h);

worker_t   *reg_get(int id);                 /* in-use slot or NULL          */
worker_t   *reg_by_pid(pid_t pid);
worker_t   *reg_alloc(const profile_t *p, const char *name, char *err, size_t n);
void        reg_free(worker_t *w);
int         reg_spawn(worker_t *w, char *err, size_t n);
int         reg_signal(worker_t *w, int sig, const char *why, char *err, size_t n);
int         reg_send_cmd(worker_t *w, const char *cmd, char *err, size_t n);
void        reg_read_pipe(worker_t *w);
void        reg_close_pipes(worker_t *w);
void        reg_hist_add(hist_t *h, int *count, const char *fmt, ...)
            __attribute__((format(printf, 3, 4)));
void        reg_refresh_metrics(int64_t now);
void        worker_json(jbuf_t *j, const worker_t *w, int detailed);
int         reg_live_count(void);

/* ---- watchdog/runtime.c ------------------------------------------------- */
void reap_children(void);                    /* call after SIGCHLD           */
void watchdog_tick(int64_t now);             /* timers, health, backoff      */
int64_t watchdog_next_deadline(int64_t now); /* for the poll() timeout       */

/* ---- commands.c --------------------------------------------------------- */
void cmd_handle(int cfd, char *line);
/* Complete the worker's pending operation: answer the waiting client (if
 * any) with ok/message, an optional raw worker report, and the worker. */
void op_finish(worker_t *w, int ok, const char *message, const char *report);
void cmd_worker_message(worker_t *w, const char *line);
void controller_stop_all_for_shutdown(void);

/* ---- main.c --------------------------------------------------------------- */
void controller_begin_shutdown(const char *why, const char *action);

#endif /* SIGCTL_CONTROLLER_H */
