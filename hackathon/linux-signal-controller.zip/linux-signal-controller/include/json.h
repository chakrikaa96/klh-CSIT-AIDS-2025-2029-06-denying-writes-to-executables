/*
 * json.h - Minimal JSON writer and a tiny reader for flat worker messages.
 *
 * The writer tracks commas automatically, so callers never assemble JSON by
 * hand with printf (which is where escaping bugs usually come from).
 */
#ifndef SIGCTL_JSON_H
#define SIGCTL_JSON_H

#include <stddef.h>
#include <stdint.h>

#define JB_MAX_DEPTH 16

typedef struct {
    char  *buf;
    size_t len;
    size_t cap;
    int    oom;                      /* set if an allocation ever failed     */
    int    depth;
    int    count[JB_MAX_DEPTH];      /* number of items in each open level   */
    int    after_key;                /* next value follows a key: no comma   */
} jbuf_t;

void jb_init(jbuf_t *j);
void jb_free(jbuf_t *j);
const char *jb_cstr(const jbuf_t *j);

void jb_obj_begin(jbuf_t *j);
void jb_obj_end(jbuf_t *j);
void jb_arr_begin(jbuf_t *j);
void jb_arr_end(jbuf_t *j);
void jb_key(jbuf_t *j, const char *key);

void jb_str(jbuf_t *j, const char *s);   /* escaped, quoted; NULL -> null    */
void jb_int(jbuf_t *j, long long v);
void jb_double(jbuf_t *j, double v);
void jb_bool(jbuf_t *j, int v);
void jb_null(jbuf_t *j);

/* Convenience: key followed by value. */
void jb_kstr(jbuf_t *j, const char *k, const char *v);
void jb_kint(jbuf_t *j, const char *k, long long v);
void jb_kdouble(jbuf_t *j, const char *k, double v);
void jb_kbool(jbuf_t *j, const char *k, int v);

/* Escape s into out (quoted). Returns 0, or -1 if out is too small. */
int json_escape(const char *s, char *out, size_t n);

/*
 * Reader for flat, single-line objects produced by our own worker
 * (e.g. {"type":"hb","progress":12}). Not a general JSON parser.
 * Return 0 when the key is found, -1 otherwise.
 */
int json_get_str(const char *line, const char *key, char *out, size_t n);
int json_get_ll(const char *line, const char *key, long long *out);

#endif /* SIGCTL_JSON_H */
