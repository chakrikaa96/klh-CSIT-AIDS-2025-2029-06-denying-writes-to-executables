/*
 * config.h - Controller configuration (key = value file).
 */
#ifndef SIGCTL_CONFIG_H
#define SIGCTL_CONFIG_H

#include <stddef.h>
#include "common.h"

typedef struct {
    /* Watchdog / recovery policy */
    int  watchdog_enabled;       /* 1 = restart eligible failed workers      */
    int  max_restarts;           /* consecutive failures allowed             */
    int  backoff_base_ms;        /* first restart delay                      */
    int  backoff_max_ms;         /* upper bound for exponential backoff      */
    int  stable_reset_s;         /* uptime after which failures reset to 0   */

    /* Monitoring */
    int  monitor_interval_ms;    /* health check / metrics period            */
    int  heartbeat_interval_ms;  /* passed to newly started workers          */
    int  status_timeout_ms;      /* SIGUSR1/SIGUSR2 reply deadline           */
    int  stop_grace_ms;          /* SIGTERM grace before SIGKILL escalation  */

    /* Paths (made absolute at startup) */
    char log_file[PATH_LEN];
    char socket_path[108];       /* sizeof(sun_path) on Linux                */
    char pid_file[PATH_LEN];
    char worker_path[PATH_LEN];
    char worker_log[PATH_LEN];
} config_t;

void config_defaults(config_t *c);

/* Load key = value pairs. Unknown keys and bad values produce an error. */
int  config_load(config_t *c, const char *path, char *err, size_t errlen);

/*
 * Change one setting. If runtime is non-zero only keys that are safe to
 * change while the controller is running are accepted.
 */
int  config_set(config_t *c, const char *key, const char *value, int runtime,
                char *err, size_t errlen);

/* Write the current settings back to a config file (atomic rename). */
int  config_save(const config_t *c, const char *path, char *err, size_t errlen);

/* Turn relative paths into absolute ones based on the current directory. */
int  config_absolutize(config_t *c, char *err, size_t errlen);

#endif /* SIGCTL_CONFIG_H */
