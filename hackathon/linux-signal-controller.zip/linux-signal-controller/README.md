# Linux Signal-Based Process Controller with Intelligent Watchdog, Real-Time Monitoring, and Fault Recovery

A Linux operating-systems project in C and Python. A central controller process (`sigctld`) creates worker processes with `fork()` and `execv()`. It controls them with real POSIX signals, confirms every state change through `waitpid()` and `/proc`, and restarts failed workers using a watchdog with restart limits and exponential backoff. A dark desktop dashboard (Tkinter) displays the verified state live and drives the controller over a Unix domain socket.

![Dashboard](docs/screenshots/01-dashboard-overview.png)

## Highlights

- **Real process control.** Every worker is a real Linux process. Pause is `SIGSTOP`, resume is `SIGCONT`, a status report is `SIGUSR1`, a diagnostic snapshot is `SIGUSR2`, and a graceful stop is `SIGTERM`. Nothing is simulated in the GUI.
- **Verified state.** A worker is shown as *paused* only after `waitpid(WUNTRACED)` reports the stop. It is *running* only after the worker's handshake or `WCONTINUED`. It is *exited* only after its exit status has been reaped.
- **Async-signal-safe design.**
  - The controller uses `sigaction()` handlers that only set `volatile sig_atomic_t` flags and write to a self-pipe.
  - Workers block their signals with `sigprocmask()` and consume them synchronously with `sigtimedwait()`.
- **Intelligent watchdog.** It distinguishes:
  - an intentional stop from a crash,
  - a crash from a normal completion,
  - a start failure from a runtime failure,
  - a *slow or unresponsive* worker from a *dead* one.

  It applies a restart limit and exponential backoff, and logs every decision.
- **Safe ownership.** Clients address workers by registry ID, never by PID. The controller signals only its own unreaped children, verifies the parent PID in `/proc` before every `kill()`, and puts each worker in its own process group. It also uses `PR_SET_PDEATHSIG` so workers never outlive a crashed controller.
- **Robust operation.** The project includes:
  - a single-instance lock (`flock`) and stale-socket recovery;
  - a `SO_PEERCRED` same-user check;
  - a refusal to run as root;
  - `SIGHUP` configuration reload;
  - persistent JSON-lines event log.
- **Tested.** The test suite covers:
  - 72 unit checks;
  - 21 integration tests against real processes, covering all 14 required scenarios and 7 more edge cases;
  - an automated GUI smoke test.

  Every test also passes under AddressSanitizer and UndefinedBehaviorSanitizer.

## Requirements

- Linux (tested on Ubuntu 24.04, kernel 6.x, GCC 13, Python 3.12). On macOS, use a Linux VM: see [docs/MACOS.md](docs/MACOS.md).
- `build-essential` (gcc, make) and `python3`, plus `python3-tk` for the dashboard.
- Optional: `xvfb` for headless GUI testing.

```bash
sudo apt-get install -y build-essential python3 python3-tk      # or ./scripts/setup_ubuntu.sh
```

Run everything as a normal user. The controller refuses to run as root.

## Quick start

```bash
make                    # builds build/sigctld, build/sigworker, build/sigctl
make test               # unit tests + integration tests against real processes
./scripts/start.sh      # starts the controller in the background and opens the dashboard
```

To run the controller in the foreground, use two terminals:

```bash
make run                            # terminal 1: controller, events printed live
./build/sigctl SPAWN primes         # terminal 2: command-line client
./build/sigctl LIST
python3 gui/dashboard.py            # dashboard (connects automatically)
```

## Command-line client

`build/sigctl` sends one command and prints the JSON reply. It exits with 0 on success.

| Command | Effect |
|---|---|
| `PING`, `LIST`, `INFO <id>`, `EVENTS [since] [limit]`, `PROFILES`, `CONFIG` | Read-only queries |
| `SPAWN <profile> [name]` | `fork()` + `execv()` a new worker |
| `PAUSE <id>` / `RESUME <id>` | `SIGSTOP` / `SIGCONT`, confirmed by `waitpid()` |
| `STATUS <id>` / `SNAPSHOT <id>` | `SIGUSR1` / `SIGUSR2`, reply returned through the worker's pipe |
| `STOP <id>` | `SIGTERM`, escalating to `SIGKILL` only after the grace period |
| `RESTART <id>` | Graceful stop, reap, then start a new process |
| `FAULT <id> crash\|segv\|hang\|exit [code]` | Test hook: make a worker fail on purpose |
| `REMOVE <id>`, `STOPALL`, `WATCHDOG on\|off`, `CONFIG SET <k> <v>`, `CONFIG SAVE`, `SHUTDOWN` | Management |

### Worker profiles

| Profile | Purpose |
|---|---|
| `primes`, `hasher`, `sorter` | Normal workloads |
| `crashy` | Test worker: aborts itself after 5 s |
| `flaky` | Test worker: exits with code 3 after 6 s |
| `sleepy` | Test worker: answers status requests after 4 s, slower than the 2 s timeout |

## Project structure

```
linux-signal-controller/
├── src/
│   ├── controller/   main.c (event loop), registry.c (fork/exec, ownership), commands.c (IPC commands)
│   ├── worker/       worker.c (sigtimedwait loop), tasks.c (workloads)
│   ├── signals/      signals.c (sigaction handlers, self-pipe, fork-safe masks)
│   ├── watchdog/     policy.c (pure decision logic), runtime.c (reaping, backoff, health)
│   ├── logger/       logger.c (ring buffer + JSON-lines file)
│   ├── ipc/          ipc_server.c (Unix socket, SO_PEERCRED, bounded reads)
│   ├── common/       util.c, json.c, config.c, proc_info.c
│   └── client/       sigctl.c (command-line client)
├── include/          one header per module
├── gui/              dashboard.py, dialogs.py, theme.py, client.py
├── tests/            unit_tests.c, integration_test.py, gui_smoke_test.py
├── config/           sigctl.conf
├── logs/             runtime logs (sample-events.jsonl is a real captured run)
├── docs/             report, viva bank, architecture, signals, protocol, testing, demo, screenshots
├── scripts/          start.sh, demo.sh, check_zombies.sh, setup_ubuntu.sh
├── Makefile
├── README.md
└── LICENSE
```

## Documentation

| Document | Contents |
|---|---|
| [docs/REPORT.md](docs/REPORT.md) | Complete academic report (abstract through conclusion, 22 sections) |
| [docs/VIVA.md](docs/VIVA.md) | Viva question bank with answers |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | Components, data flow, state machine, ownership model |
| [docs/SIGNALS.md](docs/SIGNALS.md) | Signal architecture, safety rules, coalescing, flows |
| [docs/PROTOCOL.md](docs/PROTOCOL.md) | IPC request/response protocol and worker pipe protocol |
| [docs/TESTING.md](docs/TESTING.md) | Test plan, coverage of the required cases, actual results |
| [docs/DEMO.md](docs/DEMO.md) | 5–8 minute demonstration script with expected output |
| [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) | Common problems and fixes |
| [docs/MACOS.md](docs/MACOS.md) | Developing on a Mac with a Linux VM |

## License

MIT. See [LICENSE](LICENSE).
