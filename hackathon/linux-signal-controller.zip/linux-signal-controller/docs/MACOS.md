# Developing on a Mac

The project depends on Linux-specific kernel interfaces, so it does **not** build or run natively on macOS:

| Feature used | Linux | macOS |
|---|---|---|
| `/proc/<pid>/stat`, `/proc/<pid>/status` | yes | no `/proc` filesystem |
| `prctl(PR_SET_PDEATHSIG)` | yes | not available |
| `pipe2()`, `accept4()` with flags | yes | not available |
| `SO_PEERCRED` | yes | macOS uses `LOCAL_PEERCRED` / `getpeereid()` |
| `sigtimedwait()` | yes | not available |

The Makefile detects a non-Linux system and stops with a clear message instead of producing confusing compiler errors.

## Recommended setup: Ubuntu in UTM

This works on Apple Silicon and Intel Macs.

1. Install **UTM** (free) from <https://mac.getutm.app>.
2. Download **Ubuntu 24.04 LTS Desktop**: the ARM64 image for Apple Silicon (M1–M4), or AMD64 for Intel Macs.
3. In UTM, choose *Create a New Virtual Machine → Virtualize → Linux*, select the ISO, and give it at least **2 CPU cores, 4 GB RAM and 20 GB disk**.
4. Install Ubuntu, log in, open a terminal and run:

   ```bash
   sudo apt-get update
   sudo apt-get install -y build-essential python3 python3-tk git
   ```

5. Copy the project into the VM in one of three ways:
   - extract the zip inside the VM;
   - use UTM's shared folder;
   - `git clone` the project from your repository.

6. Build, test and run as your normal VM user:

   ```bash
   cd linux-signal-controller
   make && make test
   ./scripts/start.sh
   ```

For the presentation, run UTM in full screen. The dashboard runs on the VM's own desktop, so you do not need XQuartz.

## Editing on macOS, running in the VM

You can edit the source in any macOS editor if the project folder is shared with the VM through UTM's *Shared Directory* setting (VirtFS). Build and run only inside the VM. Remove `build/` (`make clean`) if you switch between machines with different CPU architectures.

## Alternatives

- **Multipass** (`brew install multipass`, then `multipass launch 24.04`) gives a fast headless Ubuntu. The CLI and the tests work. For the GUI you would need X forwarding or `xvfb-run`, so UTM is easier for demonstrations.
- **Docker** can run `make test` (`docker run -it -v $PWD:/src ubuntu:24.04`), but the container runs as root by default. Create a normal user inside it, because the controller refuses to run as root. The GUI is impractical in Docker on macOS.
- **A college Linux lab machine** works out of the box: run `make && make test && ./scripts/start.sh`.
