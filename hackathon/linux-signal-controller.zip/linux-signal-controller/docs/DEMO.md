# Demonstration Script (5–8 minutes)

## Setup (before the evaluators arrive)

```bash
cd linux-signal-controller
make clean && make && make test          # shows the build and tests are real
rm -f logs/events.jsonl logs/workers.log # optional: start with a fresh log
```

Open two terminals and arrange them next to the dashboard window:

- **Terminal 1:** the controller in the foreground. Its live event echo is useful to show.
- **Terminal 2:** evaluator commands (`ps`, `sigctl`).

```bash
# Terminal 1
make run
# Then, in another terminal or from the desktop:
python3 gui/dashboard.py
```

The dashboard connects automatically. If you start it first, it offers a **Start controller** button.

---

## 1. Launch the controller (30 s)

**Do:** Show terminal 1. The first line is `controller_start ... listening on .../run/sigctl.sock`.

**Say:** "The controller is a C program. It runs one event loop built on `poll()`, which waits on a Unix socket for commands, on one pipe per worker, and on a self-pipe that its signal handlers write to. It refuses to run as root, and a second instance is blocked by a file lock."

**Optional:** run `./build/sigctld` in terminal 2. Expected output: `another controller is already running (pid N ...)`.

## 2. Start three workers (45 s)

**Do:** In the dashboard, click **+ Start worker**, choose `primes`, set Count to `1`, then click **Start**. Repeat for `hasher` and `sorter`. Alternatively, choose a profile and set Count to 3.

**Expected:** Three rows appear with state **running** and health **ok**. The *Workers* and *Running* cards show 3. The event feed shows `worker_spawn` (fork/exec) followed by `worker_ready` (hello) for each worker.

**Say:** "Each worker is created with `fork()` then `execv()`. A worker is only shown as running after it sends a hello message through its pipe. That is verification, not a guess."

## 3. Show PIDs and real states (30 s)

**Do** in terminal 2:

```bash
ps -o pid,ppid,pgid,stat,comm --ppid $(cat run/sigctld.pid)
```

**Expected:** Three `sigworker` lines. `PPID` equals the controller PID shown in the dashboard header, and each `PGID` equals the worker's own PID.

**Say:** "They are genuine child processes. Each worker has its own process group, so a Ctrl-C in the controller's terminal reaches only the controller, which then shuts the workers down properly."

## 4. Status report with `SIGUSR1` (45 s)

**Do:** Select `primes-1` and click **Status SIGUSR1**. Open the **Reports** tab.

**Expected:** The status bar shows `status report received in 0 ms`. The Reports tab shows the JSON report, including `sender_pid`, which equals the controller PID. The event feed shows `signal_sent SIGUSR1` followed by `status_report`.

**Say:** "A signal carries no data. It only says 'report now'. The worker has `SIGUSR1` blocked and collects it with `sigtimedwait()`. Then it writes the actual report to its pipe. `sender_pid` comes from `siginfo_t`, so the worker knows who asked."

**Optional:** click **Snapshot SIGUSR2** and point to `sig_blocked_mask`, which shows the signals blocked with `sigprocmask()`.

## 5. Pause and resume (45 s)

**Do:** Select `hasher-2` and click **Pause SIGSTOP**. In terminal 2:

```bash
ps -o pid,stat,comm -p <hasher PID>
```

**Expected:** The row turns amber and shows state **paused**. The Paused card shows 1. `ps` shows `STAT` = `T` (stopped). The CPU column drops to 0%.

**Do:** Click **Resume SIGCONT**. The worker returns to **running**, and `ps` shows `S` or `R`.

**Say:** "`SIGSTOP` cannot be caught or ignored. The kernel freezes the process directly. The dashboard only shows *paused* after `waitpid()` with `WUNTRACED` confirms it. Resume is confirmed by `WCONTINUED`. While a worker is paused, the controller refuses status requests, because the signal would just stay pending."

## 6. Crash a test worker (30 s)

**Do:** Click **+ Start worker**, choose `crashy` (marked TEST), and click **Start**. Alternatively, select any worker and use **Inject fault → Crash**.

**Expected:** After about 5 s the event feed shows `fault` (warn), then `worker_crash: killed by SIGABRT` (error, red).

## 7. Watchdog detects the exit and restarts the worker (45 s)

**Expected:** The next events are:

- `recovery_scheduled: restart 1 of 3 in 1000 ms (exponential backoff)`; the row shows **backoff** and *restart in 0.9s*;
- `recovery: restarted automatically`;
- the same row now shows a **new PID**, and *Restarts* = 1.

**Say:** "The kernel sends `SIGCHLD`. The handler only sets a flag and writes one byte to a pipe. The main loop then calls `waitpid()` in a loop, because several exits can collapse into a single `SIGCHLD`. The watchdog distinguishes a crash from a requested stop and from a normal exit with code 0, and waits 1 s, 2 s, then 4 s between restarts."

## 8. Restart limit reached (45 s)

**Do:** Wait about 25 s total. You can explain the Health and Restarts tabs of `crashy` meanwhile.

**Expected:** After the 3rd automatic restart crashes as well:

- `worker_crash` (error);
- `recovery_stopped: restart limit of 3 reached; recovery stopped`;
- the row turns red with state **failed**, and the details panel shows the recovery note `restart limit reached (4 consecutive failures)`.

The worker is not restarted again. Clicking **Restart** starts it manually and resets the failure counter.

**Optional:** with `sleepy`, clicking **Status** shows *no reply within 2000 ms ... unresponsive, not crashed*, and the worker is **not** restarted. This demonstrates the difference between slow and dead.

## 9. Graceful shutdown of all workers (30 s)

**Do:** Pause one worker first (optional). Then click **Stop all** and confirm.

**Expected:** For every worker the feed shows `signal_sent SIGTERM`, then `worker_bye`, then `worker_exit: exited with code 0 (graceful stop)`. A paused worker also receives `SIGCONT`, so it can handle the pending `SIGTERM`. No `SIGKILL` appears.

**Say:** "`SIGKILL` is never the normal path. It is only sent if a worker ignores `SIGTERM` for the whole grace period, and that escalation is logged as a warning."

## 10. Persistent log and no zombies (45 s)

**Do** in terminal 2:

```bash
./scripts/check_zombies.sh
tail -n 6 logs/events.jsonl
```

Then click **Shut down controller** in the dashboard and confirm.

**Expected:**

- `check_zombies.sh` shows `Zombie children: 0`, and no remaining `sigworker` processes after the shutdown.
- The log contains JSON lines with timestamps and ends with `controller_stop: all workers reaped`.
- Terminal 1 returns to the prompt.
- The dashboard switches to the **Controller is not running** state.

**Say:** "Every child is reaped by `waitpid()` as soon as `SIGCHLD` arrives, so zombies cannot accumulate. The log is appended and flushed on every event, so it survives restarts. If the controller is started again, the old history is still in the file."

---

## Terminal-only alternative

`./scripts/demo.sh` runs the same scenario with `sigctl` commands. Press Enter to advance each step. It is useful if the GUI is unavailable on the presentation machine.

## Evaluator checklist

| Observation | Where |
|---|---|
| Real child processes | `ps --ppid` output (step 3) |
| Signal sent, then confirmed | Event feed pairs `signal_sent` with `worker_paused`/`status_report` |
| Kernel-level stop | `STAT T` (step 5) |
| Crash reason | `killed by SIGABRT` (step 6) |
| Backoff and restart count | `restart 1 of 3 in 1000 ms`, Restarts column (step 7) |
| Limit enforced | `recovery_stopped`, state failed (step 8) |
| Graceful shutdown | `exited with code 0`, no `SIGKILL` (step 9) |
| No zombies, persistent log | `check_zombies.sh`, `logs/events.jsonl` (step 10) |
