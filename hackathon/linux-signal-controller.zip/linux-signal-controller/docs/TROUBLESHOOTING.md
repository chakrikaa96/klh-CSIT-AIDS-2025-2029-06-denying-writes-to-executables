# Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `make: error: this project uses Linux-only APIs` | Building on macOS or another non-Linux system | Build inside a Linux VM (see `MACOS.md`) |
| `sigctld: refusing to run as root` | Started with `sudo` or as root | Run as your normal user. Use `--allow-root` only if you understand the risk |
| `another controller is already running (pid N)` | A controller holds the lock | Use the running controller, or stop it with `./build/sigctl SHUTDOWN` |
| `sigctl: cannot connect to run/sigctl.sock: No such file or directory` | Controller not running, or started from a different directory | Start it from the project root (`make run` or `./scripts/start.sh`). Relative paths in the config are resolved from the starting directory |
| Dashboard shows **Controller is not running** | Same as above | Click **Start controller**, or run `make run` |
| `ModuleNotFoundError: No module named 'tkinter'` | Tk bindings not installed | `sudo apt-get install python3-tk`. If you use a non-system Python, run the dashboard with `/usr/bin/python3` |
| `_tkinter.TclError: no display name` | No graphical session (SSH or a headless VM) | Use the VM's desktop, `ssh -X`, or `xvfb-run` for tests |
| `cannot start worker: worker program ... is not executable (run 'make')` | `build/sigworker` missing | Run `make` |
| Dashboard fonts look different | Inter or DejaVu fonts not installed | Optional: `sudo apt-get install fonts-inter fonts-dejavu-core`. The GUI falls back automatically |
| Log shows `LOG UNAVAILABLE` in the dashboard | Log directory missing or not writable | Fix the permissions, or set a new path in **Settings → Log file**. The controller keeps running with in-memory events |
| Status on a worker returns *unresponsive, not crashed* | The worker did not answer within `status_timeout_ms` (expected for the `sleepy` profile, or with the `hang` fault) | Wait for the late reply, or stop or restart the worker. This is a deliberate classification, not an error |
| Stop takes about 3 seconds, then the log shows `stop_escalation` | The worker ignored `SIGTERM` (for example after a `hang` fault) | Expected. `SIGKILL` is used only after `stop_grace_ms` |
| Worker shows **failed: restart limit reached** | It crashed more than `max_restarts` times in a row | Fix the cause, then click **Restart**, which resets the counter. Alternatively raise the limit in Settings |
| `make test` fails with `Run the tests as a normal user` | Tests started as root | Run as your normal user |
| After a crash or power loss, `run/sigctl.sock` still exists | Stale socket left by a dead controller | Nothing to do. The next controller detects that the lock is free and replaces the socket |
| Integration tests fail only on a very slow VM | Timeouts tuned for normal hardware | Give the VM 2 or more CPU cores, close other heavy programs, and re-run |

## Useful commands

```bash
./build/sigctl LIST | python3 -m json.tool                  # full state
./build/sigctl EVENTS 0 20 | python3 -m json.tool           # recent events
ps -o pid,ppid,pgid,stat,etime,comm --ppid $(cat run/sigctld.pid)
./scripts/check_zombies.sh
kill -USR1 $(cat run/sigctld.pid)     # controller diagnostic event
kill -HUP  $(cat run/sigctld.pid)     # reload config/sigctl.conf
tail -f logs/events.jsonl             # live log
cat logs/workers.log                  # worker stderr (normally empty)
```
