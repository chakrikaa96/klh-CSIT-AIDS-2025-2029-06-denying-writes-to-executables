# Linux Signal-Based Process Controller with Intelligent Watchdog, Real-Time Monitoring, and Fault Recovery

**Operating Systems Project Report**

| | |
|---|---|
| Submitted by | Hrushika Habeeb (Roll No. 2520090054) |
| Course | Operating Systems |
| Platform | Linux (Ubuntu 24.04 LTS), C11, Python 3 / Tkinter |
| Version | 1.0.0 |

---

## Table of Contents

1. Abstract
2. Problem Statement
3. Motivation and Real-World Applications
4. Objectives
5. Existing System and Its Limitations
6. Proposed System
7. Functional Requirements
8. Non-Functional Requirements
9. System Architecture Diagram
10. Process and Signal Flow Diagram
11. Module Descriptions
12. Linux System Calls and APIs Used
13. Signal Comparison Table
14. Algorithms and Pseudocode
15. Implementation Details
16. Test Cases and Actual Results
17. Screenshots
18. Limitations
19. Future Enhancements
20. Conclusion
21. References
22. Viva Question Bank

---

## 1. Abstract

This project implements a process supervisor for Linux that manages a set of worker processes using the operating system's own process-control mechanisms.

**The controller.** A central controller written in C creates each worker with `fork()` and `execv()`. It controls the workers with POSIX signals: `SIGSTOP` and `SIGCONT` to pause and resume, `SIGUSR1` and `SIGUSR2` to request a status report and a diagnostic snapshot, and `SIGTERM` for graceful termination. It learns about every child state change through `SIGCHLD` and `waitpid()`.

**Verified state.** No state is assumed. A worker is reported as paused, resumed or exited only after the kernel has confirmed the change through `waitpid()` or the worker has acknowledged the request.

**Signal safety.** Signal handling follows async-signal-safe practice:

- the controller's handlers only set `sig_atomic_t` flags and write to a self-pipe;
- the workers block their signals and consume them synchronously with `sigtimedwait()`.

**Watchdog.** An intelligent watchdog distinguishes intentional stops, normal completion, start failures and genuine crashes. It restarts eligible workers with exponential backoff and stops after a configurable number of consecutive failures. It also tells a slow (unresponsive) process apart from a dead one.

**Dashboard and log.** A dark-themed Tkinter dashboard shows live metrics, a process table, per-worker diagnostics and a real-time event feed. It communicates with the controller over an authenticated Unix domain socket. All events are written to a persistent JSON-lines log.

**Testing.** The system is verified by 72 unit checks, 21 integration tests that run against real processes, and an automated GUI test.

## 2. Problem Statement

Long-running services, such as web servers, data pipelines and background job runners, are usually split into several worker processes. Workers fail: they crash on a bad input, exit with an error code, hang, or become slow. An operator needs to:

- start and stop workers in a controlled way;
- pause and resume them;
- ask them for their status;
- learn immediately when one fails, and why;
- restart failed workers automatically, without restarting a fundamentally broken worker forever;
- shut everything down cleanly, leaving no zombie or orphan processes;
- keep a history of what happened.

Doing this correctly on Linux is subtle:

- Signals are asynchronous and can interrupt a program anywhere.
- Most library functions are unsafe inside signal handlers.
- Standard signals coalesce.
- A PID can be reused once a process is reaped.
- `SIGSTOP` cannot be intercepted.
- "Signal sent" is not the same as "action completed".

The problem is to build a supervisor that handles these issues correctly, in a form a student can explain and an evaluator can verify.

## 3. Motivation and Real-World Applications

Process supervision is a core function of every production system:

| Real system | Related behaviour in this project |
|---|---|
| `systemd` service manager | Restart policies (`Restart=on-failure`), restart limits (`StartLimitBurst`), `SIGTERM` then `SIGKILL` after `TimeoutStopSec` |
| `supervisord`, `runit`, `s6` | Supervising child processes, automatic restarts with backoff, process status |
| Kubernetes / container runtimes | `CrashLoopBackOff` (exponential backoff), liveness checks separate from process existence, graceful termination period |
| Nginx, PostgreSQL, Apache | Master process managing workers, `SIGHUP` reload, `SIGTERM` graceful shutdown |
| Erlang/OTP supervisors | Restart intensity limits that prevent infinite restart loops |
| Job control in shells | `SIGSTOP`/`SIGCONT`, process groups, `waitpid(WUNTRACED)` |

Building a small but correct version of these mechanisms demonstrates the operating-system concepts behind them: process creation, process states, inter-process communication, signals, reaping and resource cleanup.

## 4. Objectives

1. Create and manage multiple worker processes using `fork()`, `execv()` and `waitpid()`.
2. Control workers with real signals (`SIGUSR1`, `SIGUSR2`, `SIGTERM`, `SIGSTOP`, `SIGCONT`) and react to `SIGCHLD`.
3. Implement signal handling that is async-signal-safe and free of race conditions.
4. Confirm every state change through the kernel (`waitpid`, `/proc`) or a worker acknowledgement.
5. Return detailed worker status through a pipe, because a signal cannot carry data.
6. Detect worker failures, record the exact exit reason, and restart eligible workers with exponential backoff and a restart limit.
7. Distinguish crashed, completed, intentionally stopped, slow and unresponsive workers.
8. Guarantee that only processes owned by the application are ever signalled.
9. Prevent zombie and orphan processes, and shut down gracefully.
10. Provide a professional real-time dashboard and a command-line client over an authenticated IPC channel.
11. Persist a timestamped event log across restarts.
12. Verify all of the above with automated tests.

## 5. Existing System and Its Limitations

Without a supervisor, a developer typically manages worker processes by hand or with ad-hoc scripts:

| Existing approach | Limitations |
|---|---|
| Starting processes manually from a shell (`./worker &`) and stopping them with `kill` | No automatic failure detection or restart. Easy to signal the wrong PID. Crashed processes may go unnoticed. |
| Shell loops such as `while true; do ./worker; done` | Restarts forever, including on a fundamentally broken worker (tight crash loop). No backoff, no limit, no distinction between a crash and a normal exit, no status reporting. |
| `cron` checks every minute | Slow detection (up to a minute), polling instead of events, no process ownership. |
| Naive C supervisors | Common bugs: `printf` or `malloc` in signal handlers; one `waitpid()` per `SIGCHLD` (zombies when signals coalesce); assuming a signal was handled because `kill()` returned 0; `SIGKILL` as the normal stop; acting on stale PIDs. |
| Full-featured systems (`systemd`, Kubernetes) | Correct, but large and complex. Their internals are hard to study or demonstrate in an academic setting, and they need root or a cluster. |

## 6. Proposed System

The proposed system has five parts:

1. **Controller (`sigctld`).** A single-threaded, event-driven C daemon that owns a registry of up to 32 workers. It forks and executes workers, signals them only after ownership checks, reaps them on `SIGCHLD`, enforces the watchdog policy, serves an IPC socket and writes the event log.
2. **Worker (`sigworker`).** A C program that runs a CPU workload (prime counting, hashing or sorting) at a limited duty cycle. It blocks its control signals and consumes them synchronously, and it reports through a pipe. Test options make it crash, exit with a code, hang or answer slowly.
3. **Watchdog.** A pure decision function (unit-testable) plus runtime timers. It provides a restart policy with exponential backoff, a consecutive-failure limit with a stable-uptime reset, health tracking from heartbeats, status timeouts and `SIGKILL` escalation.
4. **IPC layer.** A Unix domain socket with `0600` permissions and an `SO_PEERCRED` same-user check. It uses a one-request-per-connection text protocol with JSON replies.
5. **Dashboard.** A Tkinter desktop application with metric cards, a process table, per-worker details (process information, reports, health history, restart history, events), a live event monitor, settings and confirmation dialogs. A command-line client (`sigctl`) offers the same functionality.

The system has several advantages over the existing approaches:

- events instead of polling;
- verified rather than assumed state;
- bounded and explained recovery;
- explicit ownership;
- clean shutdown;
- full traceability;
- an implementation small enough to read in an afternoon.

## 7. Functional Requirements

| ID | Requirement | Implemented in |
|---|---|---|
| FR1 | Start workers of a chosen profile, with an optional name | `SPAWN`, `reg_spawn()` |
| FR2 | List workers with name, PID, state, health, uptime, restart count, last exit, current task, CPU and memory | `LIST`, `worker_json()` |
| FR3 | Pause (`SIGSTOP`) and resume (`SIGCONT`) a worker, with confirmation | `PAUSE`/`RESUME`, `on_stopped()`/`on_continued()` |
| FR4 | Request a status report (`SIGUSR1`) and a diagnostic snapshot (`SIGUSR2`), returned through a pipe | `STATUS`/`SNAPSHOT`, worker `send_status()`/`send_snapshot()` |
| FR5 | Stop a worker gracefully (`SIGTERM`) with escalation after a grace period | `STOP`, `begin_stop()`, `check_pending_timeout()` |
| FR6 | Restart a worker manually | `RESTART` |
| FR7 | Stop all application-owned workers | `STOPALL` |
| FR8 | Detect worker exits and record the exit code, terminating signal and core-dump flag | `reap_children()`, `describe_exit()` |
| FR9 | Automatically restart eligible failed workers with a backoff and a limit | `watchdog_decide()`, `watchdog_tick()` |
| FR10 | Enable or disable automatic recovery | `WATCHDOG on/off` |
| FR11 | View and change settings: maximum restarts, backoff, monitoring interval, heartbeat, timeouts, log file | `CONFIG GET/SET/SAVE`, Settings dialog |
| FR12 | Show a live, timestamped event feed with severity | `EVENTS`, event monitor |
| FR13 | Show per-worker details: process information, recent events, health history, restart history, exit information | `INFO`, details panel |
| FR14 | Persist events across controller restarts | `logs/events.jsonl` |
| FR15 | Shut down the controller gracefully | `SHUTDOWN`, `SIGTERM`/`SIGINT` |
| FR16 | Reload configuration on `SIGHUP`; write a diagnostic report on `SIGUSR1` | `reload_config()`, `controller_report()` |
| FR17 | Inject test faults (crash, segfault, hang, exit code) | `FAULT`, worker command pipe |

## 8. Non-Functional Requirements

| Category | Requirement | How it is met |
|---|---|---|
| Correctness | No unsafe calls in asynchronous handlers | Handlers only set `sig_atomic_t` flags and call `write()` |
| Correctness | No lost child events | `waitpid()` loop until it returns 0, on every loop iteration |
| Correctness | State reflects reality | State changes only on `waitpid()` results or worker messages; checked against `/proc` in tests |
| Safety | Never signal unrelated processes | Registry IDs only, PID cleared when reaped, `/proc` ppid check, own process groups |
| Safety | No orphans or zombies | `PR_SET_PDEATHSIG`, immediate reaping, orderly shutdown |
| Security | Local access only, same user only | Unix socket `0600`, `SO_PEERCRED`, refusal to run as root, no shell commands, strict input validation |
| Reliability | One instance at a time; recovery from crashes | `flock()` on the PID file; stale socket replaced |
| Reliability | Survives client misbehaviour | One-shot connections, 1 s request deadline, size limit, `MSG_NOSIGNAL` |
| Reliability | Survives a log failure | Falls back to the in-memory ring and reports the error |
| Performance | Fast detection | Event-driven; crash-to-detection is under 1 ms in tests; status replies take about 0 ms |
| Resource use | Modest CPU | Workers compute for 20% of each 50 ms cycle and sleep the rest |
| Usability | Clear, professional UI; confirmations for destructive actions; helpful empty and error states | Dashboard design, dialogs, status bar |
| Maintainability | Small modules, one header per module, no external C dependencies | Source layout; the Python GUI uses only the standard library |
| Portability | Documented Linux requirement; Mac path via a VM | `check-linux` in the Makefile, `docs/MACOS.md` |
| Testability | Automated, reproducible tests | `make test`, `make gui-test` |

## 9. System Architecture Diagram

```
                      +--------------------------------------+
                      |          Dashboard (Tkinter)         |
                      |  poller thread | action threads | UI |
                      +-------------------+------------------+
                                          |   one request line / one JSON reply
   +---------------------+                v   run/sigctl.sock (0600, SO_PEERCRED)
   |  sigctl (CLI, C)    |----------> +---------------------------------------------+
   +---------------------+            |                 sigctld                     |
                                      |                                             |
     kill -USR1/-HUP/-TERM ---------->|  signals.c   sigaction() -> flags + self-pipe|
                                      |  main.c      poll() event loop               |
                                      |  commands.c  validate -> pending operations  |
                                      |  registry.c  fork/execv, ownership, kill()   |
                                      |  runtime.c   waitpid loop, backoff, health   |
                                      |  policy.c    restart decision (pure)         |
                                      |  logger.c    ring buffer + JSON lines file --+--> logs/events.jsonl
                                      +-----+---------------+---------------+--------+
                                            |               |               |
                      fork+execv, kill,     |               |               |
                      waitpid, SIGCHLD      v               v               v
                                      +-----------+   +-----------+   +-----------+
                                      | sigworker |   | sigworker |   | sigworker |
                                      | pgid=self |   | pgid=self |   | pgid=self |
                                      +-----------+   +-----------+   +-----------+
                                       fd3 -> status pipe (JSON lines)   stdin <- command pipe
```

## 10. Process and Signal Flow Diagram

### 10.1 Lifecycle of a worker

```
 SPAWN --> fork() --> child: reset signals, setpgid, PDEATHSIG, dup2 pipes, execv(sigworker)
                          |
                          v
                     STARTING --(hello on pipe)--> RUNNING
                                                     |
       +---------------------------------------------+------------------------------+
       | PAUSE: kill(SIGSTOP)                         | STOP: kill(SIGTERM)          | crash / exit
       v                                              v                              v
  waitpid: WIFSTOPPED --> PAUSED              STOPPING                  SIGCHLD -> waitpid -> watchdog_decide()
       | RESUME: kill(SIGCONT)                        | exit reaped           |-- exit 0        -> COMPLETED
       v                                              |  (or SIGKILL after    |-- exit 127 fast -> FAILED (start)
  waitpid: WIFCONTINUED --> RUNNING                   |   grace period)       |-- watchdog off  -> FAILED
                                                      v                       |-- n <= max      -> BACKOFF --delay--> SPAWN
                                                   STOPPED                    |-- n >  max      -> FAILED (limit)
```

### 10.2 Signal flow for a status request

```
 Client            Controller (sigctld)                            Worker (sigworker)
   |  STATUS 2       |                                                   |
   |---------------->| parse_long("2") -> slot 2 -> pid P               |
   |                 | /proc/P/stat: ppid == getpid()  (ownership)       |
   |                 | kill(P, SIGUSR1) -------------------------------->| SIGUSR1 pending (blocked)
   |                 | pending = STATUS, deadline = now + 2000 ms        |
   |                 |                ... poll() keeps serving ...       | sigtimedwait() -> SIGUSR1, si_pid
   |                 |<---- {"type":"status",...}\n on the pipe --------|  write() < PIPE_BUF: atomic
   |<----------------| {"ok":true,"report":...}                          |
   |                 |   (if no reply by the deadline: health = unresponsive, NOT crashed)
```

### 10.3 Signal flow for a crash

```
 Worker: abort()  -> kernel terminates it (SIGABRT) and marks it a zombie -> SIGCHLD to the controller
 Controller handler: g_chld = 1; write(self_pipe)            [async-signal-safe only]
 Main loop: poll() wakes -> waitpid(-1, WNOHANG|WUNTRACED|WCONTINUED) repeated until it returns 0
            -> zombie reaped, PID cleared, "killed by SIGABRT" recorded
            -> watchdog_decide(): failure k of max -> BACKOFF (1 s, 2 s, 4 s ...) or FAILED (limit)
            -> on the deadline: fork()+execv() -> new PID -> hello -> RUNNING
```

## 11. Module Descriptions

| Module | Description |
|---|---|
| `main.c` | Parses options, refuses root, loads and absolutizes the configuration, takes an exclusive `flock()` on the PID file (single instance), opens the log, installs the signal handlers and creates the socket. Runs the `poll()` loop. Implements shutdown: `SIGTERM` to every worker (plus `SIGCONT` for paused ones), waits for them to be reaped, escalates to `SIGKILL` only after the grace period, removes the socket and exits with 0. Handles `SIGHUP` (reload) and `SIGUSR1` (diagnostic report). |
| `registry.c` | The worker table (slots 1–32), the built-in profiles, and `reg_spawn()` (pipes, fork, child set-up, `execv`). `reg_signal()` performs the ownership check, then `kill()`, then logging. Also contains the pipe reader that splits JSON lines, `/proc` metrics (CPU% and RSS), and JSON serialisation of workers. |
| `commands.c` | Tokenises and validates client requests and implements every command. Operations that need confirmation are stored as pending operations with a deadline and the client fd; `op_finish()` replies later. Interprets worker messages: `hello`, `hb`, `status`, `snapshot`, `bye`, `fault` and `exec_error`. |
| `signals.c` | Installs the handlers (`sigaction`, `SA_RESTART`, full `sa_mask`), the non-blocking `O_CLOEXEC` self-pipe and `SIGPIPE` ignore. `signals_take()` atomically fetches and clears the flags. Provides helpers that block all signals around `fork()` and reset dispositions and mask in the child. |
| `policy.c` | `watchdog_decide()` and `watchdog_backoff_ms()`: pure functions with no I/O, fully unit-tested. |
| `runtime.c` | `reap_children()` (the `waitpid` loop), handlers for stopped, continued and terminated children, recovery actions, timeouts for pending operations, `SIGKILL` escalation, heartbeat-based health and the next-deadline computation used for the `poll()` timeout. |
| `logger.c` | Assigns sequence numbers, keeps a 2000-entry ring buffer, appends JSON lines (line-buffered, close-on-exec), optionally echoes coloured lines to the terminal, and answers filtered queries. Keeps working if the file fails. |
| `ipc_server.c` | Creates the socket with `umask(0077)`, rejects peers with a different UID (`SO_PEERCRED`), reads one line under a 1 s deadline and a size limit, and replies with `MSG_NOSIGNAL`. |
| `config.c`, `json.c`, `proc_info.c`, `util.c` | Range-validated configuration with atomic save; a JSON writer with automatic commas and escaping; a robust `/proc/<pid>/stat` parser (parses after the last `)`); helpers for time, signal names, strict integer parsing and safe string copies. |
| `worker.c`, `tasks.c` | The worker main loop: compute for the duty share of a 50 ms cycle, check scheduled faults, send heartbeats, read commands, then `sigtimedwait()` for the rest of the cycle. Handles `SIGUSR1`, `SIGUSR2` and `SIGTERM` in normal context. The three workloads are deterministic. |
| `sigctl.c` | The command-line client. |
| `gui/` | `client.py` (socket client), `theme.py` (palette and ttk styles), `dialogs.py` (confirm, start-worker and settings dialogs), `dashboard.py` (main window, poller, action threads, rendering). |

## 12. Linux System Calls and APIs Used

| Call | Where | Purpose and notes |
|---|---|---|
| `fork()` | `reg_spawn` | Creates the worker process (a copy of the controller). |
| `execv()` | `reg_spawn` (child) | Replaces the child image with `sigworker` and a fixed argument vector; no shell is involved. |
| `waitpid(-1, &st, WNOHANG\|WUNTRACED\|WCONTINUED)` | `reap_children` | Collects exits (prevents zombies) and reports stops and continues. Called in a loop until it returns 0. |
| `WIFEXITED`, `WEXITSTATUS`, `WIFSIGNALED`, `WTERMSIG`, `WCOREDUMP`, `WIFSTOPPED`, `WSTOPSIG`, `WIFCONTINUED` | `runtime.c` | Decode the status value from `waitpid()`. |
| `kill(pid, sig)` | `reg_signal` | Sends `SIGSTOP`, `SIGCONT`, `SIGUSR1`, `SIGUSR2`, `SIGTERM`, and `SIGKILL` (escalation only). |
| `sigaction()` | `signals.c` | Installs the controller handlers with a defined mask and flags (preferred over `signal()`). |
| `sigprocmask()` | controller (around `fork`, in `signals_take`), worker | Blocks signals: protects critical sections in the controller and makes signals pending for synchronous handling in workers. |
| `sigtimedwait()` | worker | Synchronously receives a pending signal with `siginfo_t` (sender PID and UID); also acts as an interruptible sleep. |
| `sigemptyset()`, `sigfillset()`, `sigaddset()` | both | Build signal sets. |
| `pipe2(O_CLOEXEC [\| O_NONBLOCK])` | self-pipe, worker pipes | Async-safe wake-up, and worker status and command channels; `O_CLOEXEC` prevents descriptor leaks into other workers. |
| `dup2()` | child | Places the pipes at fd 0 (commands) and fd 3 (status), and redirects stdout and stderr to the worker log. |
| `setpgid()`, `getpgrp()` | child and parent | Each worker leads its own process group (called on both sides to avoid a race). |
| `prctl(PR_SET_PDEATHSIG, SIGTERM)` | child | The kernel signals the worker if the controller dies. |
| `getppid()`, `getpid()` | child, ownership check | Detects a parent that died before `prctl`; confirms ownership. |
| `poll()` | main loop, IPC | Waits on the self-pipe, the listening socket and the worker pipes, with a computed timeout. |
| `socket(AF_UNIX)`, `bind()`, `listen()`, `accept4()` | `ipc_server.c` | Local IPC endpoint. |
| `getsockopt(SO_PEERCRED)` | `ipc_accept` | Obtains the client's UID, PID and GID from the kernel for authentication. |
| `send(MSG_NOSIGNAL)` | `ipc_reply` | Prevents `SIGPIPE` when a client has disconnected. |
| `umask()`, `unlink()` | `ipc_listen` | Creates the socket with mode 0600; removes a stale socket. |
| `open()`, `flock(LOCK_EX\|LOCK_NB)`, `ftruncate()`, `pwrite()` | `acquire_lock` | Single-instance guard; the kernel releases the lock automatically on death. |
| `read()`, `write()` | everywhere | Pipe I/O. Writes under `PIPE_BUF` are atomic. |
| `fcntl(F_SETFL, O_NONBLOCK)`, `fcntl(F_GETFD)` | util, worker | Non-blocking I/O; detects whether fd 3 exists (standalone mode). |
| `clock_gettime(CLOCK_MONOTONIC / CLOCK_REALTIME)` | util | Timers (unaffected by clock changes) and timestamps. |
| `nanosleep()` | worker | Simulates a slow reply; the hang fault. |
| `getrusage(RUSAGE_SELF)` | worker | CPU time, page faults and context switches in the snapshot. |
| `abort()`, `raise()`, `exit()`, `_exit()` | worker, child | Fault injection; `_exit()` after a failed exec (no stdio flush in the child). |
| `/proc/<pid>/stat`, `/proc/<pid>/status`, `/proc/self/status` | `proc_info.c`, worker | Process state letter, parent PID, process group, CPU ticks, RSS, threads, context switches, signal masks (`SigBlk`, `SigPnd`). |
| `sysconf(_SC_CLK_TCK)` | `proc_info.c` | Converts CPU ticks to seconds. |
| `access(X_OK)`, `realpath()`, `getcwd()`, `mkdir()`, `rename()` | start-up, config | Early worker-binary check, path resolution, atomic config save. |

## 13. Signal Comparison Table

| Signal | Number | Default action | Catchable | Blockable | Generated by | Use in this project | Notes |
|---|---|---|---|---|---|---|---|
| `SIGHUP` | 1 | Terminate | Yes | Yes | User / terminal hang-up | Controller: reload config. Worker: graceful exit | Classic daemon "reload" convention |
| `SIGINT` | 2 | Terminate | Yes | Yes | Ctrl-C | Controller: orderly shutdown | Workers are in other process groups, so a terminal Ctrl-C does not reach them |
| `SIGABRT` | 6 | Core dump | Yes | Yes | `abort()` | Simulated crash (`crashy`, `FAULT crash`) | Reported as `killed by SIGABRT` |
| `SIGKILL` | 9 | Terminate | **No** | **No** | `kill()` | Last resort after the stop grace period | Never the normal shutdown path |
| `SIGUSR1` | 10 | Terminate | Yes | Yes | Controller / user | Worker: status report. Controller: diagnostic report | Carries no data; the report goes through a pipe |
| `SIGSEGV` | 11 | Core dump | Yes | Yes | Invalid memory access / `raise()` | Simulated crash (`FAULT segv`) | |
| `SIGUSR2` | 12 | Terminate | Yes | Yes | Controller | Worker: diagnostic snapshot | |
| `SIGPIPE` | 13 | Terminate | Yes | Yes | Write to a closed pipe or socket | Ignored, so writes fail with `EPIPE` | `SIG_IGN` survives `exec`, so it is reset in the child |
| `SIGTERM` | 15 | Terminate | Yes | Yes | Controller / user | Graceful stop of workers and of the controller | Escalated to `SIGKILL` only after the grace period |
| `SIGCHLD` | 17 | Ignore | Yes | Yes | Kernel | Controller: a child exited, stopped or continued | Coalesces; the controller reaps in a loop |
| `SIGCONT` | 18 | Continue | Yes (always continues) | Yes (still continues) | Controller | Resume a worker; also sent after `SIGTERM` to a paused worker | Confirmed by `WIFCONTINUED` |
| `SIGSTOP` | 19 | Stop | **No** | **No** | Controller | Pause a worker | Confirmed by `WIFSTOPPED`; `/proc` state `T` |

Numbers are for Linux on x86-64 and ARM64.

## 14. Algorithms and Pseudocode

### 14.1 Controller main loop

```
initialise: config, refuse root, flock(pid_file), open log, install handlers, listen()
loop until exit_now:
    fds      <- [self_pipe, listen_socket] + [status pipe of every worker]
    timeout  <- min(next backoff restart, next pending deadline, monitor interval)
    poll(fds, timeout)                       # retried on EINTR
    flags    <- signals_take()               # drain pipe, copy+clear flags atomically
    if flags.term:  begin_shutdown()
    if flags.hup:   reload_config()
    if flags.usr1:  log controller report
    reap_children()                          # always: SIGCHLD may have coalesced
    for each readable worker pipe: read lines -> handle_worker_message()
    if listen socket readable: accept up to 16 clients -> validate -> handle command
    watchdog_tick(now)
    if shutting_down: progress_shutdown(now)
cleanup: log stop, close and unlink the socket, truncate the pid file, close the log
```

### 14.2 Reaping children

```
procedure reap_children():
    repeat:
        pid <- waitpid(-1, &status, WNOHANG | WUNTRACED | WCONTINUED)
        if pid == 0: return                  # children exist, none changed
        if pid < 0:
            if errno == EINTR: continue
            return                           # ECHILD: no children
        w <- registry entry with this pid (if none: log a warning, continue)
        if WIFSTOPPED(status):   on_stopped(w)     # confirms PAUSE
        elif WIFCONTINUED(status): on_continued(w) # confirms RESUME
        else:                    on_terminated(w, status)
```

### 14.3 Watchdog decision

```
function watchdog_decide(stop_requested, exited, code, uptime, enabled,
                         max_restarts, stable_reset, failures):
    if stop_requested:                         return INTENTIONAL
    if exited and code == 127 and uptime < 2 s: return START_FAILURE
    if exited and code == 0:                   return COMPLETED, failures = 0
    if uptime >= stable_reset: failures <- 0    # it had been healthy
    failures <- failures + 1
    if not enabled:                            return DISABLED
    if failures > max_restarts:                return LIMIT
    return RESTART, delay = backoff(failures)

function backoff(n):  return min(base * 2^(n-1), max)       # 1 s, 2 s, 4 s, 8 s, 16 s, 16 s ...
```

### 14.4 Handling a terminated worker

```
procedure on_terminated(w, status):
    read the remaining pipe data (for example the final "bye")
    w.pid <- 0                                 # cleared in the same step as reaping
    close pipes; record exit code / signal / core flag and uptime
    d <- watchdog_decide(...)
    case d:
        INTENTIONAL:   state <- STOPPED; if restart requested: spawn again
        COMPLETED:     state <- COMPLETED
        START_FAILURE: state <- FAILED ("could not start")
        DISABLED:      state <- FAILED ("watchdog disabled")
        RESTART:       state <- BACKOFF; restart_at <- now + delay
        LIMIT:         state <- FAILED ("restart limit reached")
    answer any pending client request; log every decision
```

### 14.5 Pending-operation timeouts

```
for each worker w with a pending operation and now >= deadline:
    STATUS/SNAPSHOT: health <- UNRESPONSIVE      # process exists: not a crash
                     reply error "no reply ... unresponsive, not crashed"
    PAUSE/RESUME:    reply error "not confirmed by waitpid"
    STOP/RESTART:    if not escalated: kill(SIGKILL), deadline <- now + 3 s
                     else: reply error
```

### 14.6 Worker loop

```
block {USR1, USR2, TERM, INT, HUP}; ignore SIGPIPE; send hello
loop:
    do task steps for duty% of a 50 ms cycle
    if a scheduled crash or exit is due: send fault; abort() / exit(code)
    if a heartbeat is due: send hb(progress)
    read the command pipe: crash | segv | hang | exit N   (EOF: controller gone -> exit)
    sig <- sigtimedwait(set, info, remaining cycle time)
    while sig is a signal:
        USR1: send status (with info.si_pid)
        USR2: send snapshot
        TERM/INT/HUP: send bye; free resources; exit(0)
        sig <- sigtimedwait(set, info, 0)          # drain without sleeping
```

### 14.7 Health check

```
for each RUNNING worker:
    age <- now - last_heartbeat
    if health == UNRESPONSIVE and age <= interval: health <- OK ("restored")
    elif age > 3 * interval:              health <- UNRESPONSIVE (logged, NOT restarted)
    elif age > 1.5 * interval + 250 ms:   health <- LATE
    else:                                 health <- OK
```

## 15. Implementation Details

**Async-signal safety.** The controller's only handler, `on_signal()`, saves `errno`, sets one `volatile sig_atomic_t` flag, writes one byte to a non-blocking self-pipe and restores `errno`. The handler is installed with `sigaction()`, with `sa_mask` filled so that handlers do not nest, and with `SA_RESTART`. `SA_NOCLDSTOP` is not set, so stops and continues also raise `SIGCHLD`. `signals_take()` blocks signals while it copies and clears the flags, so no notification is lost between reading and resetting.

**Synchronous handling in workers.** Workers block their control signals and use `sigtimedwait()` with the remainder of each 50 ms cycle as the timeout. They therefore respond to a request within one work slice (at most about 10 ms) and use no CPU while idle. Because there is no asynchronous handler, building a JSON report with `snprintf` and reading `/proc/self/status` is safe.

**Fork safety.** All signals are blocked across `fork()`. The child restores default dispositions (an inherited `SIG_IGN` for `SIGPIPE` would otherwise survive `execve`) and the original mask before `execv`. Every controller descriptor is close-on-exec, so a worker receives exactly fds 0 to 3.

**Confirmation via pending operations.** A request that needs confirmation records `{operation, client fd, start time, deadline}` in the worker slot. The event loop completes it when the confirming event arrives:

- `WIFSTOPPED` for pause;
- `WIFCONTINUED` for resume;
- a `status` or `snapshot` line for a probe;
- the reaped exit for a stop.

If the deadline passes first, the timeout path runs instead. Only one operation per worker can be pending, and the controller never blocks while it waits.

**Unresponsive versus crashed.** A missed reply or heartbeat only changes *health*. The process demonstrably still exists (its `/proc` state is included in the message), so it is not restarted. A worker is treated as failed only when `waitpid()` returns its termination status. A reply that arrives late is logged as "worker was slow, not dead", and health returns to `ok`.

**Stopping a paused worker.** `SIGTERM` is sent first, then `SIGCONT`. The worker resumes, finds `SIGTERM` pending and exits cleanly. Because the controller has already set the state to `STOPPING`, the resulting `WIFCONTINUED` does not change the state back to running.

**Backoff and limit.** With the defaults (`max_restarts=3`, base 1 s, maximum 16 s), a worker that keeps crashing is restarted after 1 s, 2 s and 4 s. The fourth consecutive failure stops recovery. If a worker had run for at least `stable_reset_s` (30 s) before failing, its earlier failures are forgotten, so an occasional crash in a long-running worker never accumulates to the limit. A manual restart resets the counter.

**Persistence.** Events are appended to `logs/events.jsonl` with line buffering, so each event reaches the file immediately. If the file cannot be opened, or a write fails, the controller continues with its in-memory ring and reports `log_ok: false` to clients. Changing the log path at runtime opens the new file before closing the old one.

**Security.** The socket is created with `umask(0077)`, giving mode 0600. The peer UID from `SO_PEERCRED` must equal the controller's UID. Requests are size-limited and must arrive within 1 s. Commands and IDs are strictly validated. Workers are executed with `execv()` and a fixed argument vector, never through a shell. The controller refuses to start as root unless `--allow-root` is given explicitly.

**Dashboard.** Network I/O never runs on the Tk thread. A poller thread and per-action threads exchange data with the UI through a queue drained every 80 ms. The process table is updated in place, which avoids flicker and keeps the selection. Buttons are enabled only when the selected worker's verified state allows the action, and every destructive action asks for confirmation.

**Build quality.** The project compiles with `-std=c11 -Wall -Wextra -Wshadow -Wformat=2` and produces no warnings. The unit and integration suites also pass with `-fsanitize=address,undefined`.

## 16. Test Cases and Actual Results

The tests ran on Linux 6.18 (x86-64), Ubuntu 24.04.5 LTS, GCC 13.3.0 and Python 3.12.3, as an unprivileged user. The full output is in `docs/test-results.txt`.

**Summary:** 72 of 72 unit checks passed, 21 of 21 integration tests passed, and 8 of 8 GUI smoke checks passed. All suites also passed under AddressSanitizer and UndefinedBehaviorSanitizer.

| TC | Test case | Expected result | Actual result | Status |
|---|---|---|---|---|
| 1 | Create three workers | Three distinct PIDs, each a child of the controller and leader of its own process group | pids [2365, 2366, 2367], ppid 2364, each its own process group | Pass |
| 2 | `SIGUSR1` status | Report through the pipe, sender identified, counter increments | report received, sender_pid=2368 (controller), usr1 count 2 | Pass |
| 3 | `SIGUSR2` snapshot | Snapshot through the pipe; worker signal mask shows USR1, USR2 and TERM blocked | SigBlk=0000000000004a03, rss 1884 kB | Pass |
| 4 | Pause and resume | `/proc` state `T` while paused, no progress; running after resume; no false "unresponsive" | T state while paused, progress frozen, R/S after resume | Pass |
| 5 | Graceful termination | Exit code 0, `bye` logged, no restart | exit code 0, bye message logged, no restart | Pass |
| 6 | Unexpected exit | Crash detected with its reason | detected: killed by SIGABRT | Pass |
| 7 | Watchdog restart | New PID, restarts = 1 | pid 2379 -> 2380, restarts=1, last exit 'exited with code 3' | Pass |
| 8 | Restart limit (max 2) | Exactly 2 restarts, then failed; manual restart recovers | 2 restarts, then 'restart limit reached'; manual restart recovers | Pass |
| 9 | Simultaneous exits (5) | All reaped, no zombies | 5 exits handled, 0 zombies | Pass |
| 10 | Invalid worker IDs | All rejected; valid worker unaffected | 8 malformed IDs, an unused ID, a raw PID, a bad profile and a bad name were all rejected | Pass |
| 11 | IPC disconnection | Controller unaffected | silent, partial and vanished clients handled; controller alive | Pass |
| 12 | Log persistence | History kept across restart | 10 events kept after restart, 13 total | Pass |
| 13 | Clean shutdown (`SIGTERM`) | All workers exit 0 (one paused), no `SIGKILL`, socket removed, exit 0 | 3 workers (1 paused) exited 0, socket removed, controller exit 0 | Pass |
| 14 | Zombie prevention | 0 zombies; kernel's children = registry | 0 zombies; kernel children [2407, 2408] == registry | Pass |
| 15 | Slow worker | Unresponsive, not restarted, recovers | timeout -> unresponsive; late reply -> ok; restarts 0 | Pass |
| 16 | Hung worker | `SIGKILL` only after the grace period | SIGTERM ignored, SIGKILL after 1.50 s grace | Pass |
| 17 | Second instance / stale socket | Refused; stale socket recovered | second instance refused (exit 1); stale socket recovered | Pass |
| 18 | Controller killed | No orphan workers | workers exited after the controller was killed | Pass |
| 19 | Log unavailable | Controller continues and reports it | log_ok=false reported; workers and events still work | Pass |
| 20 | Watchdog off, config validation | No restart; invalid values rejected; saved | no restart with watchdog off; config validated and saved | Pass |
| 21 | `SIGHUP` reload | New values applied | max_restarts 3 -> 9 after SIGHUP | Pass |
| G1–G8 | Dashboard against a real controller | GUI renders the real state; buttons change real processes | connected; SPAWN, PAUSE (`/proc` T), RESUME and STOP (exit 0) worked; details and feed populated; offline state shown | Pass |

## 17. Screenshots

All screenshots were captured from the running application, connected to a real controller and real worker processes. The files are in `docs/screenshots/`.

| File | Shows |
|---|---|
| `01-dashboard-overview.png` | Main dashboard: metric cards, process table (running, paused, backoff), details panel and live event feed |
| `02-status-report.png` | A `SIGUSR1` status report in the Reports tab (note `sender_pid` = controller PID) |
| `03-restart-limit.png` | The `crashy` test worker after the restart limit: state failed, recovery note, `recovery_stopped` event |
| `04-health-history.png` | Health history of a worker |
| `05-confirm-stop-all.png` | Confirmation dialog for a destructive action |
| `06-start-worker-dialog.png` | Start-worker dialog with profiles and test workers |
| `07-settings.png` | Settings dialog (watchdog policy, intervals, log location) |
| `08-after-stop-all.png` | All workers stopped gracefully (exit code 0) |
| `09-controller-offline.png` | Offline state after the controller shut down |

![Dashboard](screenshots/01-dashboard-overview.png)

![Status report](screenshots/02-status-report.png)

![Restart limit](screenshots/03-restart-limit.png)

## 18. Limitations

1. **Linux only.** The project uses `/proc`, `prctl(PR_SET_PDEATHSIG)`, `pipe2`, `accept4`, `SO_PEERCRED` and `sigtimedwait`. On macOS it runs inside a Linux VM.
2. **Built-in workloads.** Workers are the project's own `sigworker` program with fixed profiles. The controller does not supervise arbitrary third-party programs, which would need a configurable command line and a different health protocol.
3. **Unresponsive workers are flagged, not restarted.** This is deliberate, to avoid false positives. An automatic restart-on-hang policy is not implemented.
4. **Registry not persisted.** If the controller exits, its workers are stopped (or receive `SIGTERM` through `PDEATHSIG` if it crashed). A restarted controller begins with an empty table. Only the event history persists.
5. **Single host, single user.** Access control is based on UID, and there is no remote management.
6. **Single-threaded controller.** A misbehaving same-user client can delay the loop by up to 1 s (the request deadline). A per-client non-blocking state machine would remove this.
7. **Approximate metrics.** CPU% is sampled from `/proc` at the monitoring interval, and heartbeat interval changes apply to newly started workers only.
8. **PID-based signalling.** Races are excluded by the reaping discipline and the ownership check, but the newer `pidfd` API would make the guarantee structural (see Future Enhancements).
9. **Capacity.** At most 32 workers. The in-memory event ring holds 2000 events, and the GUI keeps the latest 800 (the file keeps everything).

## 19. Future Enhancements

1. **pidfd API.** Use `pidfd_open()`, `pidfd_send_signal()` and `waitid(P_PIDFD)` so that a signal can never reach a recycled PID, even in theory.
2. **signalfd.** Use `signalfd()` as an alternative to the self-pipe, delivering signals as readable file-descriptor events.
3. **cgroups v2.** Per-worker CPU and memory limits (`cpu.max`, `memory.max`), with kill notifications for out-of-memory events.
4. **Generic supervision.** Run arbitrary commands defined in the configuration, with environment, working directory and per-worker restart policies (`always`, `on-failure`, `never`).
5. **Configurable hang policy.** Restart a worker after N consecutive missed heartbeats, with a separate limit.
6. **Real-time signals.** Use `sigqueue()` with `SIGRTMIN+n` to carry small integer payloads, and compare queueing with standard signals.
7. **State recovery.** Persist the registry and re-adopt still-running workers after a controller restart.
8. **Metrics export.** A Prometheus-compatible text endpoint and charts of CPU and memory history in the dashboard.
9. **systemd integration.** A unit file with `Type=notify` and watchdog keep-alive (`sd_notify`).
10. **Remote access.** A TLS-protected TCP interface with authentication for multi-host management.

## 20. Conclusion

The project delivers a working, tested Linux process controller that demonstrates the central operating-system concepts of process management:

- process creation with `fork()` and `execv()`;
- process states and transitions (running, stopped, zombie);
- inter-process communication with signals, pipes and Unix domain sockets;
- reaping with `waitpid()`;
- process groups;
- kernel-assisted lifetime management (`PR_SET_PDEATHSIG`);
- inspection through `/proc`.

Several design choices separate a correct supervisor from a naive one:

- performing only async-signal-safe work in handlers;
- treating `SIGCHLD` as a coalescing hint and reaping in a loop;
- never equating "signal sent" with "action done";
- returning data through pipes rather than signals;
- distinguishing slow from dead processes;
- bounding recovery with backoff and limits;
- restricting every signal to provably owned processes.

Each of these is implemented, documented and verified by automated tests that check the kernel's own view of the processes. The result is a system that is useful in practice, presentable to evaluators, and small enough for a student to understand completely and defend in a viva.

## 21. References

Linux manual pages (section numbers in parentheses), available locally with `man <section> <name>`:

1. `fork(2)`, `execve(2)`, `exec(3)`, `_exit(2)`
2. `wait(2)`: `waitpid`, `WUNTRACED`, `WCONTINUED`, status macros
3. `kill(2)`, `signal(7)`, `signal-safety(7)`, `sigaction(2)`, `sigprocmask(2)`, `sigtimedwait(2)`, `sigsetops(3)`
4. `pipe(2)` / `pipe(7)` (atomicity of writes up to `PIPE_BUF`), `dup(2)`, `fcntl(2)`
5. `setpgid(2)`, `credentials(7)`
6. `prctl(2)` (`PR_SET_PDEATHSIG`)
7. `poll(2)`, `unix(7)` (`SO_PEERCRED`), `socket(2)`, `accept(2)`, `send(2)` (`MSG_NOSIGNAL`)
8. `flock(2)`, `umask(2)`, `clock_gettime(2)`, `getrusage(2)`, `sysconf(3)`
9. `proc(5)` (`/proc/<pid>/stat`, `/proc/<pid>/status`, `SigBlk`, `SigPnd`)
10. `pidfd_open(2)`, `pidfd_send_signal(2)`, `signalfd(2)` (for the future enhancements)

Further reading:

- M. Kerrisk, *The Linux Programming Interface*, No Starch Press, 2010: chapters 20–22 (signals), 24–26 (process creation, termination, monitoring child processes), 34 (process groups), 44 (pipes) and 57 (Unix domain sockets).
- W. R. Stevens and S. A. Rago, *Advanced Programming in the UNIX Environment*, 3rd ed., Addison-Wesley, 2013: chapters 8 (process control) and 10 (signals).
- systemd documentation: `systemd.service(5)` (`Restart=`, `RestartSec=`, `StartLimitBurst=`, `TimeoutStopSec=`).

## 22. Viva Question Bank

The complete question bank with answers (more than 60 questions grouped by topic) is in [`VIVA.md`](VIVA.md).
