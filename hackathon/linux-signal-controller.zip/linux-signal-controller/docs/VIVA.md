# Viva Question Bank

The answers are kept short so they can be said aloud. File references point to where each concept lives in the code.

## A. Project overview

**1. What does your project do, in one sentence?**
It is a C controller that creates worker processes with `fork()`/`execv()`, controls them with real Linux signals, confirms every state change through `waitpid()`, and automatically restarts crashed workers with backoff and a limit, while a Tkinter dashboard shows everything live.

**2. Why is it an operating-systems project and not just an application?**
Every feature is an OS mechanism: process creation, process states, signals, reaping, process groups, pipes, Unix sockets, `/proc`, and kernel-assisted cleanup (`PR_SET_PDEATHSIG`). The GUI simulates nothing; it only displays what the kernel reports.

**3. What are the main components?**
- `sigctld` (controller);
- `sigworker` (worker);
- `sigctl` (CLI);
- the Tkinter dashboard;
- the persistent event log.

**4. Why is the controller written in C and the GUI in Python?**
The process and signal APIs are C system calls, so the logic that must be correct lives in C. The GUI does no process management, and Python/Tkinter makes a clean UI quick to build without extra dependencies.

**5. How does the GUI talk to the controller?**
Through a Unix domain socket. The GUI sends one text command per connection (for example `STATUS 2`) and receives one JSON reply. The GUI never sends PIDs or signals itself.

## B. Processes

**6. What does `fork()` return?**
It returns twice: 0 in the child, the child's PID in the parent, and -1 on error (in the parent, with no child created).

**7. Why use `execv()` after `fork()`?**
`fork()` copies the controller. `execv()` replaces that copy with the `sigworker` program, giving a clean process image with its own `main()`. I use `execv()` with a fixed argument array, not `system()` or a shell, so there is no command injection.

**8. What happens if `execv()` fails?**
The child writes an `exec_error` message to its status pipe and calls `_exit(127)`. The watchdog treats exit 127 within 2 seconds as a start failure and does not restart, to avoid a crash loop. Before forking, I also check `access(X_OK)` to give a clear error early.

**9. Why `_exit()` and not `exit()` in the child?**
`exit()` runs `atexit` handlers and flushes stdio buffers copied from the parent, which could duplicate output. `_exit()` ends the process immediately.

**10. What is a zombie process?**
A process that has terminated but whose parent has not yet collected its exit status with `wait()`/`waitpid()`. Its process-table entry and PID stay reserved.

**11. How do you prevent zombies?**
On every loop iteration, especially after `SIGCHLD`, I call `waitpid(-1, &status, WNOHANG | WUNTRACED | WCONTINUED)` in a loop until it returns 0. Test 09 makes five workers exit together and confirms there are no zombies in `/proc`.

**12. What is an orphan process, and how do you prevent orphans?**
An orphan is a child whose parent died; it is re-parented to `init` or a subreaper. Each worker calls `prctl(PR_SET_PDEATHSIG, SIGTERM)`, so the kernel sends it `SIGTERM` when the controller dies, even if the controller was killed by `SIGKILL`. Test 18 verifies this.

**13. There is a race with `PR_SET_PDEATHSIG`. What is it?**
The parent could die between `fork()` and `prctl()`, so the death signal would never be sent. Right after `prctl()`, the child compares `getppid()` with the parent's PID saved before the fork, and exits if they differ.

**14. What is a process group, and why does each worker get its own?**
A process group is a set of processes that can be signalled together and that terminal signals target. If workers shared the controller's group, Ctrl-C in the terminal would kill them directly. With their own groups, only the controller receives Ctrl-C, and it shuts the workers down gracefully.

**15. Why call `setpgid()` in both parent and child?**
To avoid a race: whichever runs first sets the group, so the group is correct no matter how the scheduler orders them. If the child has already called `exec`, the parent's call fails with `EACCES`, which is harmless.

**16. What do the process states in `/proc/<pid>/stat` mean?**
`R` running, `S` sleeping (interruptible), `D` uninterruptible disk wait, `T` stopped (by `SIGSTOP`), `Z` zombie. I use `T` to verify a pause in tests.

## C. Signals

**17. What is a signal?**
An asynchronous notification sent to a process by the kernel, another process or itself. It is identified only by a number. It interrupts the normal flow, and the process either runs a handler, takes the default action, or has the signal blocked (left pending).

**18. Which signals does your project use, and for what?**
- `SIGUSR1`: status report.
- `SIGUSR2`: diagnostic snapshot.
- `SIGTERM`: graceful stop.
- `SIGSTOP`/`SIGCONT`: pause and resume.
- `SIGCHLD`: tells the controller a child changed state.
- `SIGHUP`: config reload.
- `SIGINT`: shutdown.
- `SIGKILL`: last resort only.
- `SIGPIPE`: ignored.

**19. Why `sigaction()` instead of `signal()`?**
`signal()` has historically inconsistent semantics: whether the handler resets, and whether system calls restart. `sigaction()` lets me specify the mask while the handler runs, and flags such as `SA_RESTART`, explicitly and portably.

**20. What is "async-signal-safe"?**
A function that can safely be called from a signal handler even if the handler interrupted that same function. POSIX lists them in `signal-safety(7)`; `write()` is safe, while `printf()`, `malloc()` and `fopen()` are not, because they use internal locks and shared state.

**21. What exactly does your controller's signal handler do?**
It saves `errno`, sets a `volatile sig_atomic_t` flag, writes one byte to a non-blocking self-pipe, and restores `errno`. Nothing else (`signals.c`).

**22. What is the self-pipe trick?**
The handler writes a byte into a pipe whose read end is in the main loop's `poll()` set. The signal therefore becomes an ordinary readable file-descriptor event: `poll()` wakes up, and the main loop does the real work safely. It also removes the race in which a signal arrives just before the program goes to sleep.

**23. Why `volatile sig_atomic_t`?**
`sig_atomic_t` is guaranteed to be read and written in one indivisible step, even with respect to signals. `volatile` stops the compiler from caching the value in a register, so the main loop always sees the handler's update.

**24. How do the workers handle signals differently?**
They block `SIGUSR1`, `SIGUSR2`, `SIGTERM`, `SIGINT` and `SIGHUP` with `sigprocmask()`, so these stay pending, and collect them with `sigtimedwait()` in their main loop. There is no asynchronous handler at all, so they can safely use `printf` and file I/O when responding.

**25. What does `sigtimedwait()` give you besides the signal number?**
A `siginfo_t` containing, among other things, `si_pid` and `si_uid` of the sender. The worker includes `sender_pid` in its report, and test 02 checks that it equals the controller's PID. The timeout also makes it the loop's sleep, which wakes immediately when a signal arrives.

**26. What does it mean that standard signals coalesce?**
For signals 1–31, the kernel keeps one pending bit per signal, not a queue or a count. If `SIGCHLD` is sent five times before it is handled, the process sees it once.

**27. How does coalescing affect your design?**
Two ways:
- For `SIGCHLD`, I never assume one signal means one child: I reap in a loop until `waitpid()` returns 0.
- For `SIGUSR1`, two requests may produce one report, so the controller treats any report after the request as the answer. Signals are not used as a message queue.

**28. Can a signal carry a status report?**
No. A standard signal carries only its number (plus sender information in `siginfo_t`). The worker sends the actual report as a JSON line over its status pipe (fd 3).

**29. Why are writes to the pipe safe from interleaving?**
POSIX guarantees that `write()`s of up to `PIPE_BUF` bytes (4096 on Linux) to a pipe are atomic. Every message is under 1000 bytes, so each line arrives whole.

**30. Can `SIGSTOP` be caught or ignored?**
No. `SIGSTOP` and `SIGKILL` cannot be caught, blocked or ignored. The kernel acts on them directly, which guarantees an administrator can always pause or kill a process.

**31. How do you know a pause actually happened?**
`kill()` returning 0 only means the signal was accepted. I wait for `waitpid()` with `WUNTRACED` to report `WIFSTOPPED` for that child before showing "paused". In tests I also check that `/proc/<pid>/stat` shows `T`.

**32. Why do you need `WCONTINUED`?**
To confirm a resume. `waitpid()` reports `WIFCONTINUED` when a stopped child is continued by `SIGCONT`.

**33. Why did you not set `SA_NOCLDSTOP`?**
That flag suppresses `SIGCHLD` for stop and continue events. I want those notifications, because they are how pause and resume are confirmed promptly.

**34. How do you stop a paused worker?**
I send `SIGTERM` and then `SIGCONT`. A stopped process cannot act on `SIGTERM` until it is continued; after `SIGCONT` it finds `SIGTERM` pending and exits cleanly. Test 13 does this.

**35. Why not just use `SIGKILL` to stop workers?**
`SIGKILL` gives no chance to clean up: buffers are not flushed and resources are not released. I always send `SIGTERM` first, and escalate to `SIGKILL` only if the worker has not exited after the grace period. That escalation is logged as a warning (test 16).

**36. Why do you ignore `SIGPIPE`?**
Writing to a socket whose client disconnected would otherwise kill the controller. With `SIGPIPE` ignored (and `MSG_NOSIGNAL` on `send`), the write just fails with `EPIPE`, which I handle.

**37. Does an ignored signal survive `exec`?**
Yes. Dispositions set to `SIG_IGN` are inherited across `execve()`, while caught handlers are reset to default. That is why the child explicitly resets `SIGPIPE` to `SIG_DFL` before `execv()`.

**38. Why block all signals around `fork()`?**
Between `fork()` and resetting the handlers, a signal could run the controller's handler inside the child and write to the controller's self-pipe. Blocking prevents that. The child restores the mask after resetting dispositions.

**39. What is `EINTR`, and how do you handle it?**
A blocking system call interrupted by a signal handler may fail with `errno == EINTR`. I use `SA_RESTART`, so most calls restart automatically, and every loop around `poll`, `read`, `write`, `waitpid`, `nanosleep` and `sigtimedwait` retries on `EINTR`.

**40. What are `SIGUSR1` and `SIGHUP` used for on the controller itself?**
`kill -USR1 <controller>` writes a diagnostic summary event. `kill -HUP <controller>` reloads `config/sigctl.conf`, the classic daemon convention (test 21).

## D. Watchdog and fault recovery

**41. How does the watchdog decide whether to restart?**
`watchdog_decide()` in `policy.c` checks, in order:
1. Was the stop requested? Then it is intentional: no restart.
2. Exit 127 within 2 s? Start failure: no restart.
3. Exit code 0? The task completed: no restart.
4. Otherwise it is a failure. Increase the failure count (reset first if the worker ran at least 30 s). If the watchdog is disabled, give up. If the count exceeds `max_restarts`, give up with "limit reached". Otherwise restart after a backoff delay.

**42. What is exponential backoff, and why use it?**
The delay doubles after each consecutive failure (1 s, 2 s, 4 s, ... capped at 16 s). It avoids a tight crash loop that wastes CPU and floods logs, and it gives transient problems time to clear. Kubernetes' `CrashLoopBackOff` works the same way.

**43. How do you prevent infinite restart loops?**
With the restart limit (`max_restarts`, default 3 consecutive failures), plus the start-failure rule. After the limit, the worker is marked failed and stays down until an operator restarts it manually (test 08).

**44. Why reset the failure count after a stable period?**
A worker that runs for hours and then crashes once is not "crash looping". Without the reset, rare crashes spread over days would eventually hit the limit.

**45. How do you distinguish an intentional stop from a crash?**
The controller sets `stop_requested` before sending `SIGTERM`. When the exit is reaped, that flag makes it intentional, whatever the exit status.

**46. How do you distinguish a crashed process from a slow one?**
A process is "failed" only when `waitpid()` returns its termination status. A missed status reply or missed heartbeats only mark *health* as unresponsive; the process still exists (I include its `/proc` state in the message), so it is not restarted. The `sleepy` profile demonstrates this (test 15).

**47. How does the heartbeat health check avoid false positives?**
- A worker is "late" only after about 1.5 intervals, and "unresponsive" only after 3 missed intervals.
- Paused workers are excluded, and the timer resets on resume.
- A late status reply restores health.
- Unresponsive never triggers a restart.

**48. What happens if two workers crash at the same moment?**
Possibly only one `SIGCHLD` arrives. The `waitpid()` loop still collects both, and each gets its own watchdog decision and backoff timer (test 09).

**49. Can the user turn recovery off?**
Yes: the Watchdog toggle in the GUI, or `WATCHDOG off`. A crash is then recorded as failed with "watchdog disabled". A restart that was already scheduled is cancelled when it comes due.

## E. Safety and security

**50. How do you ensure you never signal an unrelated process?**
- Clients can only name workers by registry ID (1–32), never by PID.
- A registry PID always belongs to an unreaped child, because the kernel does not reuse a PID until the parent reaps it, and I clear the PID in the same step as reaping.
- Before every `kill()`, I check in `/proc` that the process's parent is the controller.

**51. What is PID reuse, and why is it dangerous?**
After a process is reaped, its PID can be given to a new, unrelated process. A supervisor that keeps an old PID and signals it later might kill the wrong program. My reaping discipline prevents that, and `pidfd` would be the modern structural fix.

**52. How is the IPC socket secured?**
- It is a local Unix socket created with mode 0600.
- On every connection I read the peer's UID with `SO_PEERCRED` and reject other users.
- Requests are size-limited, must arrive within 1 s, and are strictly validated.

**53. Why refuse to run as root?**
A root controller could signal any process if there were a bug. Running as a normal user means the kernel itself prevents signals to other users' processes (principle of least privilege).

**54. How do you prevent two controllers from running?**
An exclusive non-blocking `flock()` on the PID file. The kernel releases the lock automatically if the controller dies, so a stale PID file never blocks a restart. A second instance exits with a clear message (test 17).

**55. What is a stale socket, and how do you handle it?**
A socket file left behind by a controller that crashed. Because the new controller already holds the lock, any existing socket file must be stale, so it is unlinked before `bind()` (test 17).

**56. What if the GUI disconnects in the middle of a request?**
Nothing breaks. Each connection carries one request. The controller's reply fails with `EPIPE`, which is handled, and the result stays in the event log. Workers keep running (test 11).

## F. IPC and design

**57. Why one request per connection?**
It makes the protocol trivial (no framing state), makes disconnections harmless, and lets the controller answer slow requests later by simply keeping that connection open.

**58. How can the single-threaded controller wait for a stop without freezing?**
The stop becomes a pending operation with a deadline stored in the worker slot. The loop keeps serving clients and other workers. When `waitpid()` reports the exit, or the deadline passes, it answers the waiting client.

**59. Why `poll()` instead of threads?**
One thread means no locks and no data races between signal handling, reaping and IPC. Every step happens in a fixed order in one loop, which is easier to reason about and to explain.

**60. Why pipes for worker status instead of shared memory?**
Pipes give ordered, atomic messages, work with `poll()`, and need no synchronisation. They also deliver end-of-file automatically when the worker dies.

**61. What do the two pipes per worker carry?**
fd 3 carries JSON status lines (hello, heartbeat, status, snapshot, bye) from the worker to the controller. stdin carries text commands from the controller to the worker (fault injection for testing). If the worker reads end-of-file on stdin, the controller has gone away, and the worker exits.

**62. Why mark descriptors close-on-exec?**
Without `O_CLOEXEC`, every worker would inherit the listening socket, the log file and the other workers' pipes. That would keep pipes open, so end-of-file would never be seen, and it would leak resources. With it, a worker has only fds 0–3.

**63. How is the event log made persistent and safe?**
- Each event is appended as one JSON line, flushed immediately.
- If the file cannot be opened or written, the controller keeps working with its in-memory ring and reports `log_ok: false`.
- Logging never happens inside a signal handler.

## G. Testing and results

**64. How did you test the project?**
- 72 unit checks of the pure logic (watchdog, backoff, parsing, JSON, config, `/proc`, logger).
- 21 integration tests that start a real controller with real workers and verify results independently through `/proc` and the log.
- An automated GUI test that drives the real dashboard against a real controller.
- The C tests and integration tests also pass under AddressSanitizer and UndefinedBehaviorSanitizer.

**65. How do you prove the GUI is not faking anything?**
The GUI smoke test clicks Pause through the dashboard code, then reads `/proc/<pid>/stat` directly and finds state `T`. During the demo, `ps --ppid <controller>` shows the same PIDs and states as the dashboard.

**66. Give an example of a bug the tests or tools caught during development.**
Two examples:
- GCC's `_FORTIFY_SOURCE` caught `realpath()` being given a 256-byte buffer instead of `PATH_MAX`; it aborted the controller at start-up, and I fixed it.
- I also found that passing custom `CFLAGS` on the `make` command line dropped the include path, and fixed the Makefile with `override`.

**67. What are the main limitations?**
- Linux only.
- Built-in workloads rather than arbitrary programs.
- Unresponsive workers are flagged but not auto-restarted.
- The registry is not persisted across controller restarts.
- At most 32 workers.

**68. How would you improve it?**
- `pidfd_send_signal()` to make PID reuse structurally impossible.
- `signalfd()` instead of the self-pipe.
- cgroups v2 resource limits.
- Configurable commands for supervising any program.
- An optional restart-on-hang policy.
- Metrics export.

## H. Quick definitions

| Term | One-line definition |
|---|---|
| PID / PPID / PGID | Process ID / parent's PID / process group ID |
| Zombie | Terminated child not yet reaped by its parent |
| Orphan | Child whose parent died; adopted by init or a subreaper |
| Reaping | Collecting a child's exit status with `wait`/`waitpid` |
| Pending signal | Generated but not yet delivered (for example because it is blocked) |
| Blocked signal | Delivery postponed by the signal mask; stays pending |
| Signal mask | Per-thread set of blocked signals (`sigprocmask`) |
| Disposition | What happens on delivery: default, ignore, or a handler |
| Async-signal-safe | Callable from inside a signal handler |
| Self-pipe trick | Handler writes to a pipe that the main loop polls |
| Coalescing | Repeated standard signals merge into one pending instance |
| Backoff | Increasing delay between retries |
| `PIPE_BUF` | Largest pipe write guaranteed to be atomic (4096 bytes on Linux) |
| `SO_PEERCRED` | Socket option giving the connected peer's PID, UID and GID |
| `PR_SET_PDEATHSIG` | Ask the kernel to signal me when my parent dies |
