# Signal Architecture

This document explains which signals the project uses, why the handling is designed the way it is, and how each operation flows through the system.

## 1. Signals used

| Signal | No. (x86-64) | Sent by | Received by | Default action | Can be caught or blocked | Purpose in this project |
|---|---|---|---|---|---|---|
| `SIGUSR1` | 10 | controller (`kill`) | worker | terminate | yes | Request a status report. The reply travels through the worker's pipe. |
| `SIGUSR1` | 10 | user (`kill -USR1`) | controller | terminate | yes | Controller writes a diagnostic summary event. |
| `SIGUSR2` | 12 | controller | worker | terminate | yes | Request a detailed diagnostic snapshot (rusage, RSS, signal masks). |
| `SIGTERM` | 15 | controller / user | worker / controller | terminate | yes | Graceful shutdown: say goodbye, release resources, exit 0. |
| `SIGINT` | 2 | terminal Ctrl-C | controller | terminate | yes | Treated like `SIGTERM`: orderly shutdown. |
| `SIGHUP` | 1 | user | controller | terminate | yes | Reload configuration from the file. |
| `SIGCHLD` | 17 | kernel | controller | ignore | yes | A child exited, stopped or continued. Triggers `waitpid()`. |
| `SIGSTOP` | 19 | controller | worker | stop | **no** | Pause a worker. The kernel stops it unconditionally. |
| `SIGCONT` | 18 | controller | worker | continue | can be caught, but always continues | Resume a paused worker. |
| `SIGKILL` | 9 | controller | worker | terminate | **no** | **Last resort only**, after the stop grace period expires. |
| `SIGPIPE` | 13 | kernel | controller / worker | terminate | yes | **Ignored**, so writes to a closed socket or pipe return `EPIPE`. |
| `SIGABRT`, `SIGSEGV` | 6, 11 | the worker itself | worker | core dump | yes | Fault injection only (`abort()`, `raise(SIGSEGV)`), to demonstrate crash detection. |

## 2. The rule: do as little as possible inside a signal handler

A signal can interrupt the program at any instruction, including in the middle of `malloc()` or `printf()` while their internal locks are held. If the handler called those functions again, the process could deadlock or corrupt its heap. POSIX therefore allows only a short list of *async-signal-safe* functions in handlers; `write()` is on it, but `printf()`, `malloc()`, `fopen()` and `syslog()` are not.

This project uses two safe patterns.

### Pattern A: flag plus self-pipe (controller)

```c
static volatile sig_atomic_t g_chld, g_term, g_hup, g_usr1;

static void on_signal(int sig)
{
    int saved = errno;              /* do not disturb the interrupted code   */
    if (sig == SIGCHLD) g_chld = 1;
    ...
    write(g_pipe[1], "x", 1);       /* async-signal-safe; wakes up poll()    */
    errno = saved;
}
```

- `volatile sig_atomic_t` guarantees the flag is read and written atomically, and that the compiler does not cache it in a register.
- The handler is installed with `sigaction()`, with `sa_mask = all signals` so handlers do not nest, and with `SA_RESTART` so most interrupted system calls resume automatically. `SA_NOCLDSTOP` is deliberately **not** set, because the controller needs `SIGCHLD` for stops and continues too.
- The main loop `poll()`s the pipe's read end. When it wakes, `signals_take()` drains the pipe and copies and clears the flags with signals briefly blocked, so no flag can be lost between reading and resetting it.
- All real work (`waitpid`, logging, restarts) then happens in normal program context.

### Pattern B: block, then wait synchronously (worker)

```c
sigset_t set;                        /* USR1, USR2, TERM, INT, HUP */
sigprocmask(SIG_BLOCK, &set, NULL);  /* not lost: the kernel marks them pending */
...
sig = sigtimedwait(&set, &info, &timeout);  /* also serves as the loop's sleep */
```

- Blocked signals are not discarded. They stay *pending* until the program asks for them.
- `sigtimedwait()` returns the signal number plus a `siginfo_t`. The worker uses `info.si_pid` and `info.si_uid` to report **who** sent the request. The snapshot test proves this: `sender_pid` equals the controller's PID.
- Because there is no asynchronous handler at all, the worker can safely use `printf`, `malloc` and `/proc` file I/O when it reacts.
- The worker's `/proc/self/status` field `SigBlk` shows the mask (for example `0000000000004a03`: bits 1, 2, 10, 12 and 15 are SIGHUP, SIGINT, SIGUSR1, SIGUSR2 and SIGTERM). This is included in every `SIGUSR2` snapshot and verified by test 03.

## 3. A signal is not a message: coalescing

Standard signals (1–31) are represented in the kernel by **one bit per signal** in the pending set. If the same signal is sent three times before the target handles it, the bit is simply set three times: **the process sees it once**. The kernel queues no data and keeps no count. Real-time signals (`SIGRTMIN`+) queue, but they are not needed here.

Two consequences shape the design.

1. **`SIGCHLD` is a hint, not a count.** If five workers exit at the same moment, the controller may receive one `SIGCHLD`. Therefore the controller never assumes "one signal = one child". It calls `waitpid(-1, &status, WNOHANG | WUNTRACED | WCONTINUED)` in a loop until it returns 0, and does so on **every** loop iteration, not only when the flag is set. Test 09 makes five workers exit together and confirms all five are reaped with no zombie.
2. **Signals cannot carry a status report.** `SIGUSR1` only says "please report". The actual report is a JSON line written by the worker to its status pipe (fd 3). Each line is under `PIPE_BUF` (4096 bytes), so `write()` is atomic and lines never interleave. If two `SIGUSR1`s coalesce, the worker sends one report, and the controller treats any report arriving after the request as the answer.

## 4. Delivery is not confirmation

`kill()` returning 0 only means the kernel accepted the signal. It does not mean the target has reacted. The controller therefore treats every request as **pending** until it receives independent proof:

| Request | Signal sent | Considered done when | Timeout behaviour |
|---|---|---|---|
| Pause | `SIGSTOP` | `waitpid()` reports `WIFSTOPPED` | 1.5 s, then "not confirmed" |
| Resume | `SIGCONT` | `waitpid()` reports `WIFCONTINUED` | 1.5 s, then "not confirmed" |
| Status | `SIGUSR1` | a `status` line arrives on the pipe | 2 s, then **unresponsive** (not crashed) |
| Snapshot | `SIGUSR2` | a `snapshot` line arrives on the pipe | 2 s, then **unresponsive** |
| Stop | `SIGTERM` | `waitpid()` returns the exit status | grace (3 s), then `SIGKILL` and a warning |
| Start | `fork`/`execv` | worker sends `hello` | 3 s, then health "unresponsive" |

Tests 04 and 13 additionally read `/proc/<pid>/stat` to confirm the kernel's own view: state `T` while paused, and the process gone after a stop.

## 5. `SIGSTOP` cannot be caught, blocked or ignored

`SIGSTOP` (and `SIGKILL`) are handled entirely by the kernel, so a misbehaving program can never refuse to be paused. This has three practical effects:

- The worker contains no code for pausing. It is simply frozen. Its blocked `SIGUSR1` would stay pending, so the controller **refuses** a status request on a paused worker and explains why, instead of waiting for a timeout.
- A stopped process cannot run its `SIGTERM` handling. To stop a paused worker, the controller sends `SIGTERM` followed by `SIGCONT`. The worker continues, finds `SIGTERM` pending and exits cleanly (test 13 stops a paused worker this way).
- After `SIGCONT`, the controller resets the heartbeat timer, so the pause gap is not misreported as "unresponsive".

## 6. Why `SIGKILL` is not the normal shutdown

`SIGKILL` gives the target no chance to clean up: buffers are not flushed and resources are not released, and the worker cannot say goodbye. The controller always sends `SIGTERM` first. Only if the worker has not exited after `stop_grace_ms` does it escalate to `SIGKILL`, and it logs that decision as a warning (`stop_escalation`). Test 16 hangs a worker on purpose, so that `SIGTERM` stays pending, and verifies the escalation happens only after the grace period. Test 13 verifies that a normal shutdown needs no `SIGKILL` at all.

## 7. Interrupted system calls and races

| Concern | How it is handled |
|---|---|
| `EINTR` | `SA_RESTART` restarts most calls. `poll`, `read`, `write`, `waitpid`, `nanosleep` and `sigtimedwait` loops retry explicitly on `EINTR`. |
| A signal arriving between "check flag" and "sleep" | Impossible to miss, because the handler writes to the self-pipe and `poll()` sees it even if the signal came before `poll()` started. |
| A handler running in the child between `fork()` and `exec()` | All signals are blocked around `fork()`. The child resets dispositions and the mask before `exec`. |
| An ignored disposition surviving `exec` | `SIG_IGN` survives `execve()`, so the child explicitly restores `SIGPIPE` to `SIG_DFL`. Caught handlers reset automatically. |
| A PID recycled after reaping | The PID is cleared in the same step as `waitpid()`. Signals are sent only to unreaped children. A `/proc` ppid check runs before each `kill()`. |
| Controller dies before `prctl(PDEATHSIG)` | The child compares `getppid()` with the expected parent right after `prctl()` and exits if they differ. |
| Two exits at once | `waitpid` loop until it returns 0 (see coalescing, above). |
| `waitpid` from a parent with no children | `ECHILD` ends the loop. It is not an error. |

## 8. Flow examples

### Status request (`SIGUSR1`)

```
GUI/CLI            sigctld                                  sigworker
   | STATUS 2         |                                          |
   |----------------->| validate id 2 -> registry slot           |
   |                  | /proc/<pid>/stat: ppid == me ?            |
   |                  | kill(pid, SIGUSR1) ---------------------->| (pending: blocked)
   |                  | pend = STATUS, deadline = now + 2 s       |
   |                  |            ... poll() ...                 | sigtimedwait() returns SIGUSR1
   |                  |                                           | si_pid = controller
   |                  |<--------- {"type":"status",...}\n (fd 3) -|
   |<-----------------| {"ok":true,"report":"{...}"}              |
```

### Crash and recovery

```
sigworker: abort()  --> kernel kills it with SIGABRT, sends SIGCHLD to sigctld
sigctld:   handler sets g_chld, writes the self-pipe --> poll() wakes
           waitpid(-1, WNOHANG...) --> pid, WIFSIGNALED, WTERMSIG = SIGABRT
           registry pid cleared (same step), last exit "killed by SIGABRT"
           watchdog_decide(): failure 1 of 3 -> RESTART after 1000 ms (backoff)
           ... 1000 ms later, in watchdog_tick() ...
           fork() + execv() --> new pid, restarts = 1 --> hello --> RUNNING
           4th consecutive failure --> FAILED "restart limit reached"
```

## 9. References (Linux manual pages)

`signal(7)`, `signal-safety(7)`, `sigaction(2)`, `sigprocmask(2)`, `sigtimedwait(2)`, `kill(2)`, `waitpid(2)`, `fork(2)`, `execve(2)`, `prctl(2)` (`PR_SET_PDEATHSIG`), `setpgid(2)`, `pipe(7)`, `proc(5)`.
