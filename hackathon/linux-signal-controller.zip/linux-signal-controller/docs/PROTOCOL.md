# Protocols

The system has two communication channels:

1. **Client to controller:** a Unix domain stream socket.
2. **Controller to workers:** two anonymous pipes per worker.

## 1. Client protocol (Unix domain socket)

- **Socket:** `socket_path` from the config (default `run/sigctl.sock`), created with mode `0600`.
- **Authentication:** the controller calls `getsockopt(SO_PEERCRED)` and rejects any peer whose UID differs from its own.
- **Framing:** the client connects, sends **one** request line terminated by `\n`, and receives **one** JSON object terminated by `\n`. The server then closes the connection.
- **Limits:** a request line may be at most 1023 bytes. The client must send it within 1 s, or the controller drops the connection.
- **Encoding:** a request is a command word followed by space-separated arguments, case-insensitive (`STATUS 3`). Replies are UTF-8 JSON.
- **Result:** every reply contains `"ok": true|false`. Failures carry `"error": "<reason>"`.

### Commands

| Request | Reply fields (in addition to `ok`) |
|---|---|
| `PING` | `message` |
| `LIST` | `controller` (pid, version, boot_id, uptime_ms, watchdog, counts, restarts, log status), `workers[]` |
| `INFO <id>` | `worker` (detailed, with `health_history`, `restart_history`, `last_status`, `last_snapshot`), `proc` (`/proc` view: state, ppid, pgid, owned, threads, rss, cpu, context switches), `events[]` |
| `EVENTS [since] [limit]` | `boot_id`, `last_seq`, `events[]` (events with `seq > since`, oldest first, at most `limit`) |
| `PROFILES` | `profiles[]` (`name`, `task`, `description`, `test_worker`) |
| `CONFIG` / `CONFIG GET` | `config` |
| `CONFIG SET <key> <value>` | `config` (updated), or `error` with the valid range |
| `CONFIG SAVE` | `config` |
| `SPAWN <profile> [name]` | `message`, `worker` |
| `PAUSE`, `RESUME`, `STATUS`, `SNAPSHOT`, `STOP`, `RESTART` `<id>` | `message` or `error`, `worker`; `STATUS`/`SNAPSHOT` also return `report` (the worker's raw JSON line as a string) |
| `FAULT <id> crash\|segv\|hang\|exit [code]` | `message`, `worker` |
| `REMOVE <id>` | `message` |
| `STOPALL` | `message` |
| `WATCHDOG on\|off` | `message` |
| `SHUTDOWN` | `message` (sent before the shutdown begins) |

While the controller is shutting down, only read-only commands are accepted.

### Validation rules

- **Worker IDs** must be decimal integers in `1..32` that refer to an in-use slot. Strings such as `0`, `33`, `-1`, `abc`, `1;ls` and `1.5` are rejected. A PID is never accepted in place of an ID.
- **Worker names** may use only `A-Z a-z 0-9 - _ .`, with a length of 1 to 31 characters, and must be unique.
- **Profiles** must be one of the built-in profiles.
- **Configuration values** are integers checked against fixed ranges. Path keys cannot change at runtime, except `log_file`, which is opened before the switch so logging is never lost.
- **One operation at a time:** a worker with a pending operation rejects a second one (`operation 'stop' is already in progress`).

### Pending operations

Requests that need confirmation keep the client connection open until they complete:

- `PAUSE` waits for `WIFSTOPPED`.
- `RESUME` waits for `WIFCONTINUED`.
- `STATUS` and `SNAPSHOT` wait for the worker's reply.
- `STOP` and `RESTART` wait until the worker has been reaped.

The controller does not block while waiting; it keeps serving other clients and workers.

If the client disconnects first, the reply fails with `EPIPE`. The send uses `MSG_NOSIGNAL`, so no signal is raised. The result is still recorded in the event log.

### Example

```
$ ./build/sigctl STATUS 1
{"ok":true,"message":"status report received in 0 ms","report":"{\"type\":\"status\",\"name\":\"primes-1\",\"pid\":856,\"ppid\":852,\"pgid\":856,\"task\":\"primes\",\"uptime_ms\":1547,\"progress\":92287,...,\"sender_pid\":852,...}","worker":{...}}

$ ./build/sigctl STATUS 99
{"ok":false,"error":"invalid worker id '99' (expected 1-32)"}
```

## 2. Worker protocol (pipes)

Each worker has two pipes, both created with `O_CLOEXEC` so they are never inherited by other workers.

| Direction | Worker side | Controller side | Content |
|---|---|---|---|
| Worker to controller | fd 3 | non-blocking read end, polled | JSON lines (one object per line, each under `PIPE_BUF`, so every `write()` is atomic) |
| Controller to worker | stdin (fd 0, non-blocking) | write end | text commands, one per line (fault injection only) |

### Messages from the worker

| `type` | When | Main fields |
|---|---|---|
| `hello` | after `exec`, before any work | `pid`, `ppid`, `task`, `version` |
| `hb` | every `heartbeat_interval_ms` | `progress`, `detail` |
| `status` | after consuming `SIGUSR1` | `pid`, `ppid`, `pgid`, `uptime_ms`, `progress`, `detail`, `usr1_received`, `usr2_received`, `heartbeats_sent`, `sender_pid`, `sender_uid`, `reply_delay_ms` |
| `snapshot` | after consuming `SIGUSR2` | the above, plus `user_cpu_ms`, `sys_cpu_ms`, `max_rss_kb`, `vm_rss_kb`, page faults, context switches, `sig_blocked_mask`, `sig_pending_mask` |
| `bye` | after consuming `SIGTERM`/`SIGINT`/`SIGHUP`, or when the command pipe closes | `reason`, `progress` |
| `fault` | just before a deliberate failure | `kind` |
| `exec_error` | written by the child if `execv()` failed | (none) |

### Commands to the worker

| Command | Effect |
|---|---|
| `crash` | `abort()`, so the worker dies by `SIGABRT` |
| `segv` | `raise(SIGSEGV)` |
| `exit N` | `exit(N)` |
| `hang` | stop consuming signals forever; `SIGTERM` stays pending, so a stop escalates to `SIGKILL` |

If the worker reads end-of-file on stdin, the controller has gone away, and the worker exits cleanly. `PR_SET_PDEATHSIG` covers the same case at the kernel level.

## 3. Event log format

`logs/events.jsonl` holds one JSON object per line, appended and flushed per event:

```json
{"seq":19,"ts":"2026-10-16T15:47:10.740","ts_ms":1792165630740,"severity":"error",
 "type":"worker_crash","worker_id":4,"worker":"crashy-4","pid":2077,"action":"SIGABRT",
 "message":"killed by SIGABRT after 5s"}
```

| Field | Values |
|---|---|
| `severity` | `info`, `ok`, `warn`, `error` |
| `type` | `controller_start`, `controller_stop`, `controller_shutdown`, `worker_spawn`, `worker_ready`, `signal_sent`, `signal_refused`, `signal_failed`, `worker_paused`, `worker_resumed`, `status_report`, `snapshot`, `status_timeout`, `worker_bye`, `worker_exit`, `worker_crash`, `recovery_scheduled`, `recovery`, `recovery_stopped`, `recovery_skipped`, `recovery_cancelled`, `start_failure`, `stop_escalation`, `health`, `fault`, `fault_requested`, `invalid_request`, `config_changed`, `config_saved`, `config_reload`, `controller_report`, `stop_all`, `worker_restart`, `worker_removed`, `ipc`, and others |

`seq` restarts at 1 for each controller run. `boot_id` (returned by `LIST` and `EVENTS`) identifies the run. A real captured log is in `logs/sample-events.jsonl`.
