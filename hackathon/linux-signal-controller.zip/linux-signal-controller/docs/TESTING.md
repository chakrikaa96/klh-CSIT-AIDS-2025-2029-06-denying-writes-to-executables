# Testing

## 1. Test levels

| Level | File | What it exercises | Command |
|---|---|---|---|
| Unit (automated, C) | `tests/unit_tests.c` | Watchdog decisions, exponential backoff, strict ID parsing, JSON writer/reader, config parsing/validation/saving, `/proc` parsing, signal names, event ring buffer and log persistence | `make unit` |
| Integration (automated, Python + real processes) | `tests/integration_test.py` | A real `sigctld` with real `sigworker` children, driven through the Unix socket exactly like the GUI, with results checked independently through `/proc` and the log file | `make integration` |
| GUI smoke test (automated) | `tests/gui_smoke_test.py` | The real dashboard code connected to a real controller: rendering, buttons sending `SPAWN`/`PAUSE`/`RESUME`/`STOP`, details panel, event feed, offline state | `make gui-test` |
| Manual GUI demonstration | `docs/DEMO.md` | The 5–8 minute walkthrough for evaluators | see DEMO.md |

Each integration test starts its own controller in a fresh temporary directory, with its own socket, log and PID file and shortened timeouts, so the tests are independent and can run while a normal controller is running. The tests refuse to run as root, because the controller itself refuses root.

## 2. Coverage of the required test cases

| # | Required case | Test | How it is verified (independently of the controller's own claims) |
|---|---|---|---|
| 1 | Creating multiple workers | `test_01` | Three PIDs are distinct, `/proc/<pid>/stat` shows `ppid == controller` and `pgid == pid` (own process group) |
| 2 | Sending and handling `SIGUSR1` | `test_02` | A report arrives through the pipe. `sender_pid` (from `siginfo_t`) equals the controller PID, and the `usr1_received` counter increases |
| 3 | Sending and handling `SIGUSR2` | `test_03` | A snapshot arrives. The worker's `SigBlk` mask has the USR1, USR2 and TERM bits set (proves `sigprocmask` blocking) |
| 4 | Pausing and resuming | `test_04` | `/proc` state is `T` while paused and progress is frozen. Status is refused while paused. After resume the state is `R`/`S`, progress continues and health is not falsely unresponsive |
| 5 | Graceful termination | `test_05` | Exit code 0, a `bye` message, process gone, no watchdog restart afterwards |
| 6 | Unexpected worker exit | `test_06` | `worker_crash` event with the old PID and `killed by SIGABRT` |
| 7 | Watchdog restart | `test_07` | New PID is alive and a child of the controller, `restarts == 1`, last exit recorded |
| 8 | Restart-limit enforcement | `test_08` | With `max_restarts=2`: exactly 2 restarts, then `failed` with `restart limit reached`, no further restarts; manual restart resets the counter |
| 9 | Simultaneous child exits | `test_09` | 5 workers exit together. All 5 are reaped with exit code 7, and there are 0 zombies under the controller in `/proc` |
| 10 | Invalid worker IDs | `test_10` | `0`, `33`, `99`, `-1`, `abc`, `1;ls`, `1.5`, an overflowing number, an unused slot, a raw PID, an unknown profile and an unsafe name are all rejected. A valid worker is unaffected |
| 11 | IPC disconnection | `test_11` | A client that sends nothing, one that sends half a line, and one that disconnects while waiting for a slow status reply. The controller stays alive and responsive |
| 12 | Log persistence | `test_12` | The log is restarted with the same file. The earlier history is byte-identical, two `controller_start` records exist, and boot IDs differ |
| 13 | Clean controller shutdown | `test_13` | Real `SIGTERM` to the controller with one worker paused. All workers exit with code 0, no `SIGKILL` is needed, the socket is removed, and the controller exits with 0 |
| 14 | Zombie-process prevention | `test_14` | After a segfault restart, a stop and a manual restart: 0 zombies, and the kernel's list of children equals the registry |

Additional edge cases:

| Test | Case |
|---|---|
| `test_15` | A slow worker (`sleepy`) is classified **unresponsive, not crashed**. It is not restarted, and the late reply restores its health |
| `test_16` | A hung worker ignores `SIGTERM`. `SIGKILL` is used only after the grace period, and the escalation is logged |
| `test_17` | A second controller instance is refused (exit 1). After a crash leaves a stale socket, a new controller starts cleanly |
| `test_18` | The controller is killed with `SIGKILL`, and its workers still exit (`PR_SET_PDEATHSIG`): no orphans |
| `test_19` | The log file cannot be opened. The controller keeps running, reports `log_ok=false`, and in-memory events still work |
| `test_20` | With the watchdog off a crash is not restarted. `CONFIG SET` validates values and rejects path changes, and `CONFIG SAVE` writes the file |
| `test_21` | `SIGHUP` reloads the configuration file |

Fault tolerance cases from the specification and where they are covered:

| Fault | Covered by |
|---|---|
| Worker exits unexpectedly | test 06, 07 |
| Worker exits normally (exit code 0) | unit test `WD_COMPLETED` |
| Worker cannot be started | `access()` check before fork and the exit-127 start-failure path (unit test `WD_START_FAILURE`) |
| Signal delivery fails | `reg_signal()` reports and logs `kill()` errors |
| Invalid worker ID | test 10 |
| Worker unresponsive | test 15, 16 |
| Multiple simultaneous exits | test 09 |
| Restart limit reached | test 08 |
| Controller shutdown request | test 13 (`SIGTERM`), GUI test (`SHUTDOWN`) |
| GUI disconnect while workers run | test 11, plus one-shot connections by design |
| Log file cannot be opened | test 19 |
| IPC connection fails | test 11; the GUI shows an offline state (GUI test) |
| Controller started twice | test 17 |
| Stale PID or stale socket | test 17 (`flock` decides ownership; a stale socket is unlinked) |
| Operation on an already exited worker | test 10 / API returns `worker N is stopped, not running` |

## 3. Test worker

`sigworker` doubles as the fault-injection test worker:

- **Command-line options:**
  - `--crash-after S` calls `abort()`, so the worker dies by `SIGABRT`.
  - `--exit-after S --exit-code C` exits with code `C`.
  - `--reply-delay-ms MS` makes the worker answer `SIGUSR1`/`SIGUSR2` slowly.
- **Runtime commands** through its stdin pipe (`FAULT` command / GUI "Inject fault" menu): `crash`, `segv`, `hang`, `exit N`.
- **Profiles** `crashy`, `flaky` and `sleepy` preconfigure these options for demonstrations.

## 4. Actual results

These results come from a run in this project's development environment. The complete output is in [`test-results.txt`](test-results.txt).

- **Environment:** Linux 6.18 (x86-64), Ubuntu 24.04.5 LTS, GCC 13.3.0, Python 3.12.3, run as an unprivileged user.
- **Build:** 0 compiler warnings with `-Wall -Wextra -Wshadow -Wformat=2`.
- **Unit tests:** 72 checks, 0 failed.
- **Integration tests:** 21 passed, 0 failed. Three consecutive repetitions also passed.
- **GUI smoke test** (under `xvfb-run`): 8 of 8 checks passed.
- **Sanitizers:** the unit and integration suites were also run with `-fsanitize=address,undefined`. All tests passed and no sanitizer reports were produced.

Results on **your** machine are the ones that count for your submission. Re-run them in your Linux VM:

```bash
make clean && make && make test && make gui-test | tee my-test-results.txt
```

To repeat the sanitizer run:

```bash
make clean
make CFLAGS="-O1 -g -fsanitize=address,undefined" LDFLAGS="-fsanitize=address,undefined"
make CFLAGS="-O1 -g -fsanitize=address,undefined" LDFLAGS="-fsanitize=address,undefined" unit
python3 tests/integration_test.py
make clean && make
```

## 5. Manual checks for the demonstration

| Check | Command | Expected |
|---|---|---|
| Workers are real children | `ps -o pid,ppid,pgid,stat,comm --ppid $(cat run/sigctld.pid)` | One line per running worker; `PPID` = controller; `PGID` = worker's own PID |
| Paused means stopped | after Pause: `ps -o pid,stat -p <pid>` | `STAT` = `T` |
| No zombies | `./scripts/check_zombies.sh` | `Zombie children: 0` |
| Persistent log | `tail -n 5 logs/events.jsonl` | JSON lines with timestamps |
| Controller report via a signal | `kill -USR1 $(cat run/sigctld.pid)` | A `controller_report` event appears |
| Config reload via a signal | edit `config/sigctl.conf`, then `kill -HUP $(cat run/sigctld.pid)` | A `config_reload` event appears and the new values show in Settings |
