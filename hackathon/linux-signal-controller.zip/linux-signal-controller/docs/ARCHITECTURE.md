# Architecture

## 1. Components

```
+--------------------------------------------------------------------------------+
|  User space (normal user account)                                              |
|                                                                                |
|   +-------------------+        Unix domain socket          +----------------+  |
|   |  Dashboard (GUI)  |  ---- one request line ------->    |                |  |
|   |  Python / Tkinter |  <--- one JSON reply line -----    |    sigctld     |  |
|   +-------------------+      run/sigctl.sock (0600)        |  (controller)  |  |
|   +-------------------+      SO_PEERCRED: same uid only    |                |  |
|   |  sigctl (CLI, C)  |  ------------------------------>   |  event loop    |  |
|   +-------------------+                                    |  poll()        |  |
|                                                            +---+--------+---+  |
|                      fork() + execv()  |  kill(): SIGSTOP SIGCONT    |   |      |
|                      waitpid()         |  SIGUSR1 SIGUSR2 SIGTERM    |   |      |
|                                        v                             |   |      |
|        +--------------+  +--------------+  +--------------+          |   |      |
|        |  sigworker   |  |  sigworker   |  |  sigworker   |  ...     |   |      |
|        |  own pgid    |  |  own pgid    |  |  own pgid    |          |   |      |
|        +--+--------+--+  +--+--------+--+  +--+--------+--+          |   |      |
|           |  fd 3  ^ stdin  |        ^        |        ^             |   |      |
|           |  status| cmds   |        |        |        |             |   |      |
|           +--------+--------+--------+--------+--------+-- pipes ----+   |      |
|                                                                          |      |
|        logs/events.jsonl  <------- every event (JSON lines) -------------+      |
|                                                                                |
+--------------------------------------------------------------------------------+
|  Kernel: process table, signal delivery, SIGCHLD, /proc/<pid>/stat|status     |
+--------------------------------------------------------------------------------+
```

| Module | Files | Responsibility |
|---|---|---|
| Controller core | `src/controller/main.c` | Start-up checks, single-instance lock, `poll()` event loop, shutdown sequence, `SIGHUP` reload |
| Process registry | `src/controller/registry.c` | Worker slots, profiles, `fork()`/`execv()`, validated `kill()`, pipe reader, `/proc` metrics |
| Command layer | `src/controller/commands.c` | Parses and validates IPC requests, starts pending operations, handles worker messages |
| Signal layer | `src/signals/signals.c` | `sigaction()` handlers, self-pipe wake-up, signal masks around `fork()` |
| Watchdog policy | `src/watchdog/policy.c` | Pure functions that decide restart versus give up, plus exponential backoff (unit tested) |
| Watchdog runtime | `src/watchdog/runtime.c` | `waitpid()` reaping loop, confirmations, backoff timers, health checks, `SIGKILL` escalation |
| Logger | `src/logger/logger.c` | 2000-event ring buffer for clients and a JSON-lines file for persistence |
| IPC server | `src/ipc/ipc_server.c` | Socket creation (0600), `SO_PEERCRED` check, bounded and time-limited request reads |
| Common | `src/common/*.c` | Config parsing and validation, JSON writer, `/proc` parser, utilities |
| Worker | `src/worker/*.c` | Blocks signals and consumes them with `sigtimedwait()`, runs a workload, sends heartbeats |
| CLI client | `src/client/sigctl.c` | Sends one command and prints the reply |
| Dashboard | `gui/*.py` | Background poller, action threads, Tk main thread rendering |

## 2. Why a single-threaded event loop

The controller never uses threads. One `poll()` call waits on the following file descriptors:

1. the read end of the **self-pipe**, which becomes readable when a signal handler ran;
2. the **listening socket**, which becomes readable when a client connects;
3. one **status pipe per worker**, which becomes readable when a worker sends a message.

The `poll()` timeout is the nearest deadline (a backoff restart, a confirmation timeout or the monitoring interval). This design has three advantages:

- **No locks.** Signal handlers, `waitpid()`, IPC and timers can never race on the registry, because only the main loop touches it.
- **Easy to explain.** Every action happens in a fixed order in one loop iteration.
- **Never blocked by a slow operation.** Operations that need confirmation (pause, status, stop) become *pending operations* with a deadline. The client connection is answered later, when the kernel or the worker confirms.

One loop iteration does the following, in order:

```
poll()                               wait for fds or the nearest deadline
signals_take()                       fetch-and-clear flags (SIGCHLD/SIGTERM/SIGHUP/SIGUSR1)
reap_children()                      waitpid(-1, WNOHANG|WUNTRACED|WCONTINUED) until 0
read worker pipes                    hello / hb / status / snapshot / bye / fault lines
accept clients                       up to 16 per iteration, one request each
watchdog_tick()                      backoff restarts, pending timeouts, health, /proc metrics
progress_shutdown()                  only while shutting down
```

## 3. Worker state machine

The controller changes state only on **confirmed** events.

```
             SPAWN / auto-restart
                    |
                    v
              +-----------+   hello on pipe      +-----------+
              | STARTING  | -------------------> |  RUNNING  | <-----------------+
              +-----------+                      +-----------+                   |
                                                   |   |    |                    |
                         SIGSTOP + WIFSTOPPED      |   |    |  SIGCONT +         |
                       +---------------------------+   |    |  WIFCONTINUED      |
                       v                               |    |                    |
                 +-----------+   SIGCONT+WCONTINUED    |    |                    |
                 |  PAUSED   | ------------------------+----+--------------------+
                 +-----------+                         |
                       | STOP (SIGTERM + SIGCONT)      | STOP (SIGTERM)
                       v                               v
                 +-------------------------------------------+
                 |                 STOPPING                  |--- grace expired --> SIGKILL
                 +-------------------------------------------+
                                    | reaped (waitpid)
                                    v
                               +----------+      RESTART       (back to STARTING)
                               | STOPPED  | ----------------->
                               +----------+

  RUNNING --(exit/crash, not requested, reaped)--> watchdog_decide():
        exit code 0                        -> COMPLETED   (task finished, no restart)
        exit 127 within 2 s                -> FAILED      (start failure, no restart loop)
        failure, watchdog off              -> FAILED      ("watchdog disabled")
        failure, failures <= max_restarts  -> BACKOFF ---(delay elapses)---> STARTING
        failure, failures >  max_restarts  -> FAILED      ("restart limit reached")
```

Health is tracked separately from state, because *alive* and *responsive* are different questions:

| Health | Meaning |
|---|---|
| `ok` | Heartbeats are arriving on time. |
| `late` | A heartbeat is more than about 1.5 intervals overdue. |
| `unresponsive` | No heartbeat for 3 intervals, or no reply to `SIGUSR1`/`SIGUSR2` within the timeout. The process still exists, so it is **not** treated as crashed and **not** restarted. |
| `paused` | The process is stopped by `SIGSTOP`, so missing heartbeats are expected. |

## 4. Ownership model: why the controller cannot signal the wrong process

1. **Clients never send PIDs.** Every command names a worker by its registry ID (1–32). The ID is parsed with `strtol` and full validation, then looked up in the registry.
2. **A registry PID is always an unreaped child.** The kernel does not reuse a PID until the parent has collected it with `waitpid()`. The controller clears `w->pid` in the same function that reaps it (`on_terminated`), so a stored PID can never refer to an unrelated, recycled process.
3. **Defence in depth.** Before every `kill()`, `reg_signal()` reads `/proc/<pid>/stat` and requires `ppid == getpid()`. If the check fails, the controller refuses and logs the refusal.
4. **Process groups.** Each worker calls `setpgid(0, 0)`, and the controller also calls `setpgid(pid, pid)`, which avoids a race. A Ctrl-C in the controller's terminal is therefore delivered only to the controller, which then performs an orderly shutdown instead of having its workers killed underneath it.
5. **No orphans.** Each child calls `prctl(PR_SET_PDEATHSIG, SIGTERM)`, then checks `getppid()` to close the race with a parent that has already died. If the controller is killed, even with `SIGKILL`, every worker receives `SIGTERM` and exits.
6. **No shell.** Workers are started with `execv()` and a fixed argument vector. Shell command strings are never built.

## 5. Process creation in detail (`reg_spawn`)

```
access(worker_path, X_OK)          reject early with a clear error ("run make")
pipe2(status, O_CLOEXEC)           worker -> controller
pipe2(cmd, O_CLOEXEC)              controller -> worker
sigprocmask(SIG_BLOCK, all)        no controller handler may run in the child
pid = fork()
child:
    restore default dispositions   (an ignored SIGPIPE would survive exec)
    restore the old signal mask
    setpgid(0, 0)
    prctl(PR_SET_PDEATHSIG, SIGTERM); if getppid() != parent: _exit(127)
    dup2(cmd[0], 0); dup2(status[1], 3); stdout/stderr -> logs/workers.log
    execv(worker_path, argv)
    write {"type":"exec_error"} to fd 3; _exit(127)
parent:
    setpgid(pid, pid); restore mask; close child ends; non-blocking pipes
    state = STARTING until the worker's "hello" arrives
```

Every descriptor the controller owns is close-on-exec: the log file (`fopen(..., "ae")`), the lock file, the sockets and the pipes. A worker therefore inherits only fds 0–3.

## 6. Configuration

`config/sigctl.conf` uses `key = value` lines.

- Runtime-safe values (policy, intervals, log file) can be changed through `CONFIG SET`, saved with `CONFIG SAVE`, or reloaded from the file with `SIGHUP`.
- Path settings (socket, PID file, worker path) require a restart.
- The controller validates every value against a range. Invalid values are rejected with the line number.

## 7. Dashboard threading

- **Poller thread.** Every monitoring interval it sends `LIST`, `EVENTS <last_seq>` and `INFO <selected>`, and puts the replies on a `queue.Queue`.
- **Action threads.** Each button press runs its request in a short-lived thread, because a graceful stop can take up to the grace period.
- **Tk main thread.** Every 80 ms it drains the queue and updates widgets. Only this thread touches Tk.

Because every connection carries a single request, closing or crashing the GUI leaves the controller and its workers unaffected. The dashboard reconnects automatically and can start the controller in a new session if it is not running.
