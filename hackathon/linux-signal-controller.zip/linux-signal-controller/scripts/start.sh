#!/usr/bin/env bash
# Build if needed, start the controller in the background (if it is not
# already running) and open the dashboard. Closing the dashboard leaves the
# controller running; stop it from the dashboard or with:
#   ./build/sigctl SHUTDOWN
set -euo pipefail
cd "$(dirname "$0")/.."

if [ "$(id -u)" = "0" ]; then
  echo "Please run as a normal user, not root." >&2
  exit 1
fi
make -s
mkdir -p logs run

if ./build/sigctl PING >/dev/null 2>&1; then
  echo "Controller already running."
else
  ./build/sigctld -q -c config/sigctl.conf >>logs/controller.out 2>&1 &
  for _ in $(seq 1 50); do
    ./build/sigctl PING >/dev/null 2>&1 && break
    sleep 0.1
  done
  ./build/sigctl PING >/dev/null || { echo "Controller failed to start; see logs/controller.out" >&2; exit 1; }
  echo "Controller started (pid $(cat run/sigctld.pid))."
fi
exec python3 gui/dashboard.py -c config/sigctl.conf
