#!/usr/bin/env bash
# Install everything needed to build, test and run the project on
# Ubuntu / Debian (including Ubuntu running in a VM on a Mac).
set -euo pipefail
sudo apt-get update
sudo apt-get install -y build-essential python3 python3-tk make
# Optional: headless GUI testing
sudo apt-get install -y xvfb || true
echo "Done. Next: make && make test && ./scripts/start.sh"
