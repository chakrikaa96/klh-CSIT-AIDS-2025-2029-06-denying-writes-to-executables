#!/usr/bin/env bash
# Terminal walkthrough of the demonstration scenario (docs/DEMO.md).
# Run in a second terminal while the controller (and optionally the
# dashboard) is running. Press Enter to advance each step.
set -uo pipefail
cd "$(dirname "$0")/.."
C=./build/sigctl
pretty() { python3 -c 'import json,sys; d=json.load(sys.stdin); print(json.dumps(d, indent=2)[:1500])'; }
step() { echo; echo "=== $1"; read -r -p "[Enter] " _; }
ids() { $C LIST | python3 -c "import json,sys; [print(w['id'], w['name'], w['pid'], w['state'], 'restarts=%d' % w['restarts'], w['last_exit']) for w in json.load(sys.stdin)['workers']]"; }

$C PING || { echo "Start the controller first: ./scripts/start.sh or make run"; exit 1; }
step "1. Start three workers (fork + execv)"
$C SPAWN primes demo-primes | pretty; $C SPAWN hasher demo-hasher >/dev/null; $C SPAWN sorter demo-sorter >/dev/null
sleep 1; ids
step "2. Verify they are real child processes (ppid = controller)"
ps -o pid,ppid,pgid,stat,comm --ppid "$(cat run/sigctld.pid)"
step "3. SIGUSR1 status report from demo-primes"
ID=$($C LIST | python3 -c "import json,sys; print([w['id'] for w in json.load(sys.stdin)['workers'] if w['name']=='demo-primes'][0])")
$C STATUS "$ID" | python3 -c 'import json,sys; d=json.load(sys.stdin); print(d["message"]); print(json.dumps(json.loads(d["report"]), indent=2))'
step "4. Pause (SIGSTOP) - kernel state becomes T"
$C PAUSE "$ID" >/dev/null; ps -o pid,stat,comm -p "$($C LIST | python3 -c "import json,sys; print([w['pid'] for w in json.load(sys.stdin)['workers'] if w['id']==$ID][0])")"
step "5. Resume (SIGCONT)"
$C RESUME "$ID" | python3 -c 'import json,sys; print(json.load(sys.stdin)["message"])'
step "6. Start a crashing test worker (aborts every 5 s) and watch recovery"
$C SPAWN crashy demo-crashy >/dev/null
for i in $(seq 1 40); do sleep 1; ids | grep demo-crashy; done
step "7. Graceful shutdown of all workers"
$C STOPALL; sleep 2; ids
step "8. Check for zombies and show the persistent log tail"
./scripts/check_zombies.sh
tail -n 8 logs/events.jsonl
