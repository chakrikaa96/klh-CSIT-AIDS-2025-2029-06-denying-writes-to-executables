#!/usr/bin/env bash
# Show the controller's child processes and any zombies (state Z).
# Usage: ./scripts/check_zombies.sh
cd "$(dirname "$0")/.."
PID=$(cat run/sigctld.pid 2>/dev/null || true)
if [ -z "$PID" ] || ! kill -0 "$PID" 2>/dev/null; then
  echo "Controller is not running."
  echo "Leftover sigworker processes (should be none):"
  ps -eo pid,ppid,pgid,stat,comm | awk 'NR==1 || /sigworker/'
  exit 0
fi
echo "Controller pid $PID - its children:"
ps -o pid,ppid,pgid,stat,etime,comm --ppid "$PID"
Z=$(ps -o stat= --ppid "$PID" | grep -c '^Z' || true)
echo "Zombie children: $Z"
