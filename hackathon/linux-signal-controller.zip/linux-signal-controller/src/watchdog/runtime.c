/*
 * runtime.c - Child reaping, recovery actions, health checks and timers.
 *
 * Key rule: a worker's state only changes when the kernel confirms it.
 *   - "paused"   only after waitpid() reports WIFSTOPPED
 *   - "running"  only after the worker's hello, or waitpid() WIFCONTINUED
 *   - "exited"   only after waitpid() returns its exit status
 * Sending a signal never changes the state by itself.
 */
#include "controller.h"
#include "logger.h"
#include "proc_info.h"
#include "watchdog.h"

#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <sys/wait.h>

static void on_stopped(worker_t *w, int sig)
{
    if (w->state != ST_RUNNING && w->state != ST_STARTING)
        return;                       /* e.g. already stopping: keep state */
    w->state = ST_PAUSED;
    w->health = H_PAUSED;
    reg_hist_add(w->health_hist, &w->health_hist_n, "paused (%s)", signal_name(sig));
    if (w->pend.op == OP_PAUSE) {
        log_event(SEV_OK, "worker_paused", w->id, w->name, w->pid, signal_name(sig),
                  "stop confirmed by waitpid(WUNTRACED) in %lld ms",
                  (long long)(now_ms() - w->pend.started_ms));
        op_finish(w, 1, "worker paused (confirmed by waitpid)", NULL);
    } else {
        log_event(SEV_WARN, "worker_paused", w->id, w->name, w->pid, signal_name(sig),
                  "stopped by a signal from outside the controller");
    }
}

static void on_continued(worker_t *w)
{
    if (w->state != ST_PAUSED)
        return;                       /* SIGCONT sent during a stop: ignore */
    w->state = ST_RUNNING;
    w->health = H_OK;
    w->last_heartbeat_ms = now_ms();  /* no false "unresponsive" after pause */
    reg_hist_add(w->health_hist, &w->health_hist_n, "resumed (SIGCONT)");
    if (w->pend.op == OP_RESUME) {
        log_event(SEV_OK, "worker_resumed", w->id, w->name, w->pid, "SIGCONT",
                  "continue confirmed by waitpid(WCONTINUED) in %lld ms",
                  (long long)(now_ms() - w->pend.started_ms));
        op_finish(w, 1, "worker resumed (confirmed by waitpid)", NULL);
    } else {
        log_event(SEV_WARN, "worker_resumed", w->id, w->name, w->pid, "SIGCONT",
                  "continued by a signal from outside the controller");
    }
}

static void describe_exit(worker_t *w, int status)
{
    w->exit_valid = 1;
    w->exit_wall_ms = wall_ms();
    w->exit_code = -1;
    w->exit_signal = 0;
    w->exit_core = 0;
    if (WIFEXITED(status)) {
        w->exit_code = WEXITSTATUS(status);
        snprintf(w->exit_desc, sizeof w->exit_desc, "exited with code %d", w->exit_code);
    } else if (WIFSIGNALED(status)) {
        w->exit_signal = WTERMSIG(status);
#ifdef WCOREDUMP
        w->exit_core = WCOREDUMP(status) ? 1 : 0;
#endif
        snprintf(w->exit_desc, sizeof w->exit_desc, "killed by %s%s",
                 signal_name(w->exit_signal), w->exit_core ? " (core dumped)" : "");
    } else {
        snprintf(w->exit_desc, sizeof w->exit_desc, "terminated (status 0x%x)", status);
    }
}

static void respawn(worker_t *w, const char *why_hist, int manual)
{
    char err[200];

    if (reg_spawn(w, err, sizeof err) != 0) {
        w->state = ST_FAILED;
        snprintf(w->fail_reason, sizeof w->fail_reason, "restart failed: %.70s", err);
        log_event(SEV_ERROR, "recovery_failed", w->id, w->name, 0, "fork/exec", "%s", err);
        if (w->pend.op == OP_RESTART)
            op_finish(w, 0, err, NULL);
        return;
    }
    w->restarts_total++;
    reg_hist_add(w->restart_hist, &w->restart_hist_n, "%s -> new pid %d", why_hist, (int)w->pid);
    if (!manual)
        log_event(SEV_OK, "recovery", w->id, w->name, w->pid, "restart",
                  "restarted automatically (attempt %d of %d)",
                  w->consecutive_failures, g_ctl.cfg.max_restarts);
}

static void on_terminated(worker_t *w, int status)
{
    const config_t *c = &g_ctl.cfg;
    int64_t uptime = now_ms() - w->started_ms;
    pid_t old_pid = w->pid;
    wd_input_t in;
    wd_result_t r;
    char up[32];

    reg_read_pipe(w);         /* collect final messages (e.g. "bye")         */
    w->pid = 0;               /* PID cleared in the same step it is reaped   */
    reg_close_pipes(w);
    describe_exit(w, status);
    w->health = H_NONE;
    w->cpu_pct = 0;
    format_duration(uptime, up, sizeof up);

    memset(&in, 0, sizeof in);
    in.stop_requested = w->stop_requested;
    in.exited = WIFEXITED(status);
    in.exit_code = WIFEXITED(status) ? WEXITSTATUS(status) : -1;
    in.signaled = WIFSIGNALED(status);
    in.uptime_ms = uptime;
    in.watchdog_enabled = c->watchdog_enabled && !g_ctl.shutting_down;
    in.max_restarts = c->max_restarts;
    in.stable_reset_s = c->stable_reset_s;
    in.consecutive_failures = w->consecutive_failures;
    r = watchdog_decide(&in, c->backoff_base_ms, c->backoff_max_ms);
    w->consecutive_failures = r.failures;

    if (r.decision == WD_INTENTIONAL) {
        int killed = w->pend.escalated || (WIFSIGNALED(status) && WTERMSIG(status) == SIGKILL);
        w->state = ST_STOPPED;
        w->fail_reason[0] = '\0';
        log_event(killed ? SEV_WARN : SEV_OK, "worker_exit", w->id, w->name, old_pid,
                  killed ? "SIGKILL" : "SIGTERM", "%s after %s (%s)", w->exit_desc, up,
                  killed ? "forced after grace period" : "graceful stop");
        if (w->restart_after_stop && !g_ctl.shutting_down) {
            w->restart_after_stop = 0;
            w->consecutive_failures = 0;   /* operator intervention resets */
            respawn(w, "manual restart", 1);
            if (w->pend.op == OP_RESTART && w->pid > 0) {
                log_event(SEV_OK, "worker_restart", w->id, w->name, w->pid, "restart",
                          "manual restart complete");
                op_finish(w, 1, "worker restarted", NULL);
            }
        } else if (w->pend.op == OP_STOP || w->pend.op == OP_RESTART) {
            op_finish(w, 1, w->exit_desc, NULL);
        }
        return;
    }

    /* Not intentional: any pending request can no longer succeed. */
    if (w->pend.op != OP_NONE) {
        char msg[160];
        snprintf(msg, sizeof msg, "worker exited while waiting: %s", w->exit_desc);
        op_finish(w, 0, msg, NULL);
    }

    switch (r.decision) {
    case WD_COMPLETED:
        w->state = ST_COMPLETED;
        log_event(SEV_INFO, "worker_exit", w->id, w->name, old_pid, "exit",
                  "%s after %s: task finished, not a crash; no restart", w->exit_desc, up);
        break;
    case WD_START_FAILURE:
        w->state = ST_FAILED;
        snprintf(w->fail_reason, sizeof w->fail_reason, "could not start (exit %d)",
                 EXIT_START_FAILURE);
        log_event(SEV_ERROR, "start_failure", w->id, w->name, old_pid, "exec",
                  "worker could not start; not restarting to avoid a loop");
        break;
    case WD_DISABLED:
        w->state = ST_FAILED;
        snprintf(w->fail_reason, sizeof w->fail_reason, "%.70s; watchdog disabled", w->exit_desc);
        log_event(SEV_ERROR, "worker_crash", w->id, w->name, old_pid,
                  w->exit_signal ? signal_name(w->exit_signal) : "exit", "%s after %s",
                  w->exit_desc, up);
        log_event(SEV_WARN, "recovery_skipped", w->id, w->name, old_pid, "",
                  g_ctl.shutting_down ? "controller is shutting down: no restart"
                                      : "watchdog recovery is disabled: no restart");
        break;
    case WD_RESTART:
        w->state = ST_BACKOFF;
        w->restart_at_ms = now_ms() + r.delay_ms;
        log_event(SEV_ERROR, "worker_crash", w->id, w->name, old_pid,
                  w->exit_signal ? signal_name(w->exit_signal) : "exit", "%s after %s",
                  w->exit_desc, up);
        log_event(SEV_WARN, "recovery_scheduled", w->id, w->name, old_pid, "backoff",
                  "restart %d of %d in %lld ms (exponential backoff)", r.failures,
                  c->max_restarts, (long long)r.delay_ms);
        break;
    case WD_LIMIT:
        w->state = ST_FAILED;
        snprintf(w->fail_reason, sizeof w->fail_reason,
                 "restart limit reached (%d consecutive failures)", r.failures);
        log_event(SEV_ERROR, "worker_crash", w->id, w->name, old_pid,
                  w->exit_signal ? signal_name(w->exit_signal) : "exit", "%s after %s",
                  w->exit_desc, up);
        log_event(SEV_ERROR, "recovery_stopped", w->id, w->name, old_pid, "limit",
                  "restart limit of %d reached; recovery stopped (manual restart resets it)",
                  c->max_restarts);
        break;
    default:
        break;
    }
}

void reap_children(void)
{
    for (;;) {
        int status = 0;
        pid_t pid = waitpid(-1, &status, WNOHANG | WUNTRACED | WCONTINUED);
        worker_t *w;

        if (pid == 0)
            break;                    /* children exist, none changed state */
        if (pid < 0) {
            if (errno == EINTR)
                continue;
            break;                    /* ECHILD: no children at all          */
        }
        w = reg_by_pid(pid);
        if (w == NULL) {
            log_event(SEV_WARN, "reap_unknown", 0, "", pid, "waitpid",
                      "collected a child that is not in the registry");
            continue;
        }
        if (WIFSTOPPED(status))
            on_stopped(w, WSTOPSIG(status));
        else if (WIFCONTINUED(status))
            on_continued(w);
        else
            on_terminated(w, status);
    }
}

static void check_pending_timeout(worker_t *w, int64_t now)
{
    char msg[200], err[160];

    if (w->pend.op == OP_NONE || now < w->pend.deadline_ms)
        return;

    switch (w->pend.op) {
    case OP_STATUS:
    case OP_SNAPSHOT: {
        proc_info_t pi;
        char st = proc_read(w->pid, &pi) == 0 ? pi.state : '?';
        const char *sig = w->pend.op == OP_STATUS ? "SIGUSR1" : "SIGUSR2";
        int timeout = g_ctl.cfg.status_timeout_ms;
        w->health = H_UNRESPONSIVE;
        reg_hist_add(w->health_hist, &w->health_hist_n, "no reply to %s within %d ms", sig, timeout);
        snprintf(msg, sizeof msg,
                 "no reply to %s within %d ms; process still exists (state %c: %s), "
                 "so it is classified as unresponsive, not crashed",
                 sig, timeout, st, proc_state_name(st));
        log_event(SEV_WARN, "status_timeout", w->id, w->name, w->pid, sig, "%s", msg);
        op_finish(w, 0, msg, NULL);
        break;
    }
    case OP_PAUSE:
    case OP_RESUME:
        snprintf(msg, sizeof msg, "state change was not confirmed by waitpid within the timeout");
        log_event(SEV_WARN, "confirm_timeout", w->id, w->name, w->pid,
                  w->pend.op == OP_PAUSE ? "SIGSTOP" : "SIGCONT", "%s", msg);
        op_finish(w, 0, msg, NULL);
        break;
    case OP_STOP:
    case OP_RESTART:
        if (!w->pend.escalated) {
            log_event(SEV_WARN, "stop_escalation", w->id, w->name, w->pid, "SIGKILL",
                      "no exit within %d ms grace period; escalating to SIGKILL",
                      g_ctl.cfg.stop_grace_ms);
            w->pend.escalated = 1;
            w->pend.deadline_ms = now + 3000;
            if (reg_signal(w, SIGKILL, "grace period expired", err, sizeof err) != 0)
                op_finish(w, 0, err, NULL);
        } else {
            op_finish(w, 0, "worker did not exit even after SIGKILL", NULL);
        }
        break;
    default:
        break;
    }
}

static void check_health(worker_t *w, int64_t now)
{
    int hb = g_ctl.cfg.heartbeat_interval_ms;
    int64_t age = now - w->last_heartbeat_ms;
    health_t want;

    if (w->state == ST_STARTING) {
        if (age > 3000 && w->health != H_UNRESPONSIVE) {
            w->health = H_UNRESPONSIVE;
            log_event(SEV_WARN, "start_slow", w->id, w->name, w->pid, "",
                      "no hello from worker after 3 s");
        }
        return;
    }
    if (w->state != ST_RUNNING)
        return;
    /* A status timeout keeps the worker marked unresponsive until a fresh
     * heartbeat proves it is making progress again. */
    if (w->health == H_UNRESPONSIVE && age <= hb)
        want = H_OK;
    else if (age > 3LL * hb)
        want = H_UNRESPONSIVE;
    else if (w->health == H_UNRESPONSIVE)
        want = H_UNRESPONSIVE;
    else if (age > hb + hb / 2 + 250)
        want = H_LATE;
    else
        want = H_OK;

    if (want == w->health)
        return;
    if (want == H_UNRESPONSIVE) {
        reg_hist_add(w->health_hist, &w->health_hist_n, "heartbeat missing for %lld ms",
                     (long long)age);
        log_event(SEV_WARN, "health", w->id, w->name, w->pid, "heartbeat",
                  "no heartbeat for %lld ms: unresponsive (process alive, not restarted)",
                  (long long)age);
    } else if (want == H_LATE) {
        reg_hist_add(w->health_hist, &w->health_hist_n, "heartbeat late (%lld ms)", (long long)age);
    } else if (w->health == H_UNRESPONSIVE || w->health == H_LATE) {
        reg_hist_add(w->health_hist, &w->health_hist_n, "heartbeat restored");
        if (w->health == H_UNRESPONSIVE)
            log_event(SEV_OK, "health", w->id, w->name, w->pid, "heartbeat",
                      "heartbeat restored: worker responsive again");
    } else {
        reg_hist_add(w->health_hist, &w->health_hist_n, "healthy");
    }
    w->health = want;
}

void watchdog_tick(int64_t now)
{
    int i;

    for (i = 1; i <= MAX_WORKERS; i++) {
        worker_t *w = &g_ctl.w[i];
        if (!w->in_use)
            continue;

        if (w->state == ST_BACKOFF && now >= w->restart_at_ms) {
            if (!g_ctl.cfg.watchdog_enabled || g_ctl.shutting_down) {
                char desc[sizeof w->exit_desc];
                copy_str(desc, w->exit_desc, sizeof desc);   /* avoid overlap */
                w->state = ST_FAILED;
                snprintf(w->fail_reason, sizeof w->fail_reason, "%.70s; restart cancelled", desc);
                log_event(SEV_WARN, "recovery_skipped", w->id, w->name, 0, "",
                          "scheduled restart cancelled (watchdog disabled)");
            } else {
                char why[96];
                snprintf(why, sizeof why, "auto restart after %.60s", w->exit_desc);
                respawn(w, why, 0);
            }
        }
        check_pending_timeout(w, now);
        if (w->pid > 0)
            check_health(w, now);
    }

    if (now - g_ctl.last_metrics_ms >= g_ctl.cfg.monitor_interval_ms) {
        reg_refresh_metrics(now);
        g_ctl.last_metrics_ms = now;
    }
}

int64_t watchdog_next_deadline(int64_t now)
{
    int64_t next = now + g_ctl.cfg.monitor_interval_ms;
    int i;

    for (i = 1; i <= MAX_WORKERS; i++) {
        const worker_t *w = &g_ctl.w[i];
        if (!w->in_use)
            continue;
        if (w->state == ST_BACKOFF && w->restart_at_ms < next)
            next = w->restart_at_ms;
        if (w->pend.op != OP_NONE && w->pend.deadline_ms < next)
            next = w->pend.deadline_ms;
    }
    return next;
}
