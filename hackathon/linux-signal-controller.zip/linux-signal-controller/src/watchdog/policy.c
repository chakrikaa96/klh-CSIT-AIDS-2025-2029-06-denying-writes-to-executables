/*
 * policy.c - Pure watchdog decision logic.
 *
 * Decision order matters:
 *   1. A requested stop is never a failure.
 *   2. Exit code 127 right after start means the program could not run;
 *      restarting would just loop, so we give up immediately.
 *   3. Exit code 0 means the task finished on its own (not a crash).
 *   4. Everything else (non-zero exit or killed by a signal) is a failure.
 *      If the worker had been stable for stable_reset_s, earlier failures
 *      are forgotten. The failure count is then compared with the limit.
 */
#include "watchdog.h"

int64_t watchdog_backoff_ms(int attempt, int base_ms, int max_ms)
{
    int64_t d = base_ms;
    int i;

    if (attempt < 1)
        attempt = 1;
    for (i = 1; i < attempt && d < max_ms; i++)
        d *= 2;
    return d > max_ms ? max_ms : d;
}

wd_result_t watchdog_decide(const wd_input_t *in, int base_ms, int max_ms)
{
    wd_result_t r = { WD_INTENTIONAL, in->consecutive_failures, 0 };

    if (in->stop_requested) {
        r.decision = WD_INTENTIONAL;
        return r;
    }
    if (in->exited && in->exit_code == EXIT_START_FAILURE &&
        in->uptime_ms < START_FAILURE_WINDOW_MS) {
        r.decision = WD_START_FAILURE;
        return r;
    }
    if (in->exited && in->exit_code == 0) {
        r.decision = WD_COMPLETED;
        r.failures = 0;
        return r;
    }

    /* A real failure. */
    if (in->uptime_ms >= (int64_t)in->stable_reset_s * 1000)
        r.failures = 0;            /* it was healthy for a long time       */
    r.failures++;

    if (!in->watchdog_enabled) {
        r.decision = WD_DISABLED;
        return r;
    }
    if (r.failures > in->max_restarts) {
        r.decision = WD_LIMIT;
        return r;
    }
    r.decision = WD_RESTART;
    r.delay_ms = watchdog_backoff_ms(r.failures, base_ms, max_ms);
    return r;
}

const char *watchdog_decision_name(wd_decision_t d)
{
    switch (d) {
    case WD_INTENTIONAL:   return "intentional";
    case WD_COMPLETED:     return "completed";
    case WD_START_FAILURE: return "start_failure";
    case WD_DISABLED:      return "watchdog_disabled";
    case WD_RESTART:       return "restart";
    case WD_LIMIT:         return "limit_reached";
    default:               return "unknown";
    }
}
