/*
 * tasks.c - Three simple, deterministic CPU workloads.
 *   primes : trial-division prime counting
 *   hash   : FNV-1a hashing of a pseudo-random buffer
 *   sort   : fill an array with pseudo-random numbers and qsort() it
 */
#include "tasks.h"

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define HASH_BUF   (64 * 1024)
#define HASH_CHUNK 4096
#define SORT_N     4096

typedef enum { T_PRIMES, T_HASH, T_SORT } kind_t;

struct task {
    kind_t    kind;
    char      name[16];
    /* primes */
    uint64_t  next;
    long long primes;
    /* hash */
    unsigned char *buf;
    size_t    offset;
    uint64_t  hash;
    long long bytes;
    /* sort */
    int      *arr;
    long long sorts;
    uint32_t  rng;
};

static uint32_t xorshift(uint32_t *s)
{
    uint32_t x = *s;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    return *s = x;
}

static int cmp_int(const void *a, const void *b)
{
    int x = *(const int *)a, y = *(const int *)b;
    return (x > y) - (x < y);
}

task_t *task_create(const char *name, char *err, size_t n)
{
    task_t *t = calloc(1, sizeof *t);
    size_t i;

    if (t == NULL) {
        snprintf(err, n, "out of memory");
        return NULL;
    }
    t->rng = 2463534242u;
    snprintf(t->name, sizeof t->name, "%s", name);
    if (strcmp(name, "primes") == 0) {
        t->kind = T_PRIMES;
        t->next = 2;
    } else if (strcmp(name, "hash") == 0) {
        t->kind = T_HASH;
        t->buf = malloc(HASH_BUF);
        if (t->buf == NULL) {
            free(t);
            snprintf(err, n, "out of memory");
            return NULL;
        }
        for (i = 0; i < HASH_BUF; i++)
            t->buf[i] = (unsigned char)xorshift(&t->rng);
        t->hash = 1469598103934665603ULL;
    } else if (strcmp(name, "sort") == 0) {
        t->kind = T_SORT;
        t->arr = malloc(SORT_N * sizeof *t->arr);
        if (t->arr == NULL) {
            free(t);
            snprintf(err, n, "out of memory");
            return NULL;
        }
    } else {
        free(t);
        snprintf(err, n, "unknown task '%s' (primes, hash, sort)", name);
        return NULL;
    }
    return t;
}

void task_step(task_t *t)
{
    size_t i;

    switch (t->kind) {
    case T_PRIMES: {
        uint64_t c = t->next++, d;
        int prime = c >= 2;
        for (d = 2; d * d <= c; d++)
            if (c % d == 0) {
                prime = 0;
                break;
            }
        t->primes += prime;
        break;
    }
    case T_HASH:
        for (i = 0; i < HASH_CHUNK; i++) {
            t->hash ^= t->buf[(t->offset + i) % HASH_BUF];
            t->hash *= 1099511628211ULL;
        }
        t->offset = (t->offset + HASH_CHUNK) % HASH_BUF;
        t->bytes += HASH_CHUNK;
        break;
    case T_SORT:
        for (i = 0; i < SORT_N; i++)
            t->arr[i] = (int)(xorshift(&t->rng) & 0x7fffffff);
        qsort(t->arr, SORT_N, sizeof *t->arr, cmp_int);
        t->sorts++;
        break;
    }
}

long long task_progress(const task_t *t)
{
    switch (t->kind) {
    case T_PRIMES: return t->primes;
    case T_HASH:   return t->bytes / (1024 * 1024);
    default:       return t->sorts;
    }
}

void task_describe(const task_t *t, char *buf, size_t n)
{
    switch (t->kind) {
    case T_PRIMES:
        snprintf(buf, n, "%lld primes found (testing %llu)", t->primes,
                 (unsigned long long)t->next);
        break;
    case T_HASH:
        snprintf(buf, n, "%lld MiB hashed (fnv %08llx)", t->bytes / (1024 * 1024),
                 (unsigned long long)(t->hash & 0xffffffffULL));
        break;
    default:
        snprintf(buf, n, "%lld arrays of %d sorted", t->sorts, SORT_N);
        break;
    }
}

const char *task_name(const task_t *t) { return t->name; }

void task_destroy(task_t *t)
{
    if (t == NULL)
        return;
    free(t->buf);
    free(t->arr);
    free(t);
}
