/*
 * worker.c - sigworker: a managed worker process.
 *
 * Signal strategy (synchronous): SIGUSR1, SIGUSR2, SIGTERM, SIGINT and
 * SIGHUP are BLOCKED with sigprocmask(). Blocked signals are not lost; the
 * kernel marks them pending. The main loop collects them with
 * sigtimedwait(), so each one is handled in normal program context where
 * printf, malloc and file I/O are all safe. sigtimedwait() also acts as the
 * loop's sleep: it wakes up immediately when a signal arrives.
 *
 *   SIGUSR1  -> write a status report to the status pipe (fd 3)
 *   SIGUSR2  -> write a detailed diagnostic snapshot to the status pipe
 *   SIGTERM  -> say "bye", release resources, exit(0)
 *   SIGSTOP/SIGCONT are handled by the kernel itself (cannot be caught).
 *
 * Communication: fd 3 = status pipe to the controller (JSON lines, each
 * shorter than PIPE_BUF so every write() is atomic); stdin = command pipe
 * from the controller (fault injection for testing).
 */
#include "common.h"
#include "json.h"
#include "tasks.h"

#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <time.h>
#include <unistd.h>

#define STATUS_FD 3

typedef struct {
    char      name[NAME_LEN];
    char      task[16];
    int       heartbeat_ms;
    int       crash_after_s;
    int       exit_after_s;
    int       exit_code;
    int       reply_delay_ms;
    int       duty_pct;          /* share of each cycle spent computing     */
} options_t;

static int     g_out = STATUS_FD;
static int64_t g_start;
static long    g_usr1, g_usr2, g_heartbeats;

static void emit(const char *fmt, ...) __attribute__((format(printf, 1, 2)));

/* Write one JSON line. Lines stay below PIPE_BUF (4096 bytes), which makes
 * each write() atomic, so lines from a worker are never interleaved. */
static void emit(const char *fmt, ...)
{
    char line[1000];
    va_list ap;
    int n;
    ssize_t w;

    va_start(ap, fmt);
    n = vsnprintf(line, sizeof line - 1, fmt, ap);
    va_end(ap);
    if (n < 0)
        return;
    if ((size_t)n > sizeof line - 2)
        n = (int)sizeof line - 2;
    line[n++] = '\n';
    do {
        w = write(g_out, line, (size_t)n);
    } while (w < 0 && errno == EINTR);
    if (w < 0 && errno == EPIPE) {
        /* The controller is gone: nobody to report to. Exit quietly. */
        _exit(0);
    }
}

static void sleep_ms(int ms)
{
    struct timespec ts = { ms / 1000, (long)(ms % 1000) * 1000000L };
    while (nanosleep(&ts, &ts) != 0 && errno == EINTR)
        ;
}

static void read_proc_self(char *sigblk, char *sigpnd, size_t n, long *rss_kb)
{
    FILE *f = fopen("/proc/self/status", "r");
    char line[256];

    copy_str(sigblk, "?", n);
    copy_str(sigpnd, "?", n);
    *rss_kb = 0;
    if (f == NULL)
        return;
    while (fgets(line, sizeof line, f) != NULL) {
        line[strcspn(line, "\n")] = '\0';
        if (strncmp(line, "SigBlk:", 7) == 0)
            copy_str(sigblk, line + 8, n);
        else if (strncmp(line, "SigPnd:", 7) == 0)
            copy_str(sigpnd, line + 8, n);
        else if (strncmp(line, "VmRSS:", 6) == 0)
            *rss_kb = strtol(line + 6, NULL, 10);
    }
    fclose(f);
}

static void send_status(const options_t *o, const task_t *t, const siginfo_t *si)
{
    char detail[96], name[2 * NAME_LEN + 4];

    if (o->reply_delay_ms > 0)          /* simulate a slow worker            */
        sleep_ms(o->reply_delay_ms);
    task_describe(t, detail, sizeof detail);
    json_escape(o->name, name, sizeof name);
    emit("{\"type\":\"status\",\"name\":%s,\"pid\":%d,\"ppid\":%d,\"pgid\":%d,"
         "\"task\":\"%s\",\"uptime_ms\":%lld,\"progress\":%lld,\"detail\":\"%s\","
         "\"usr1_received\":%ld,\"usr2_received\":%ld,\"heartbeats_sent\":%ld,"
         "\"sender_pid\":%d,\"sender_uid\":%d,\"reply_delay_ms\":%d}",
         name, (int)getpid(), (int)getppid(), (int)getpgrp(), task_name(t),
         (long long)(now_ms() - g_start), task_progress(t), detail, g_usr1, g_usr2,
         g_heartbeats, (int)si->si_pid, (int)si->si_uid, o->reply_delay_ms);
}

static void send_snapshot(const options_t *o, const task_t *t, const siginfo_t *si)
{
    struct rusage ru;
    char detail[96], name[2 * NAME_LEN + 4], sigblk[32], sigpnd[32];
    long rss_kb;

    if (o->reply_delay_ms > 0)
        sleep_ms(o->reply_delay_ms);
    getrusage(RUSAGE_SELF, &ru);
    read_proc_self(sigblk, sigpnd, sizeof sigblk, &rss_kb);
    task_describe(t, detail, sizeof detail);
    json_escape(o->name, name, sizeof name);
    emit("{\"type\":\"snapshot\",\"name\":%s,\"pid\":%d,\"task\":\"%s\",\"progress\":%lld,"
         "\"detail\":\"%s\",\"uptime_ms\":%lld,\"user_cpu_ms\":%lld,\"sys_cpu_ms\":%lld,"
         "\"max_rss_kb\":%ld,\"vm_rss_kb\":%ld,\"minor_faults\":%ld,\"major_faults\":%ld,"
         "\"voluntary_ctxt_switches\":%ld,\"involuntary_ctxt_switches\":%ld,"
         "\"sig_blocked_mask\":\"%s\",\"sig_pending_mask\":\"%s\",\"sender_pid\":%d}",
         name, (int)getpid(), task_name(t), task_progress(t), detail,
         (long long)(now_ms() - g_start),
         (long long)ru.ru_utime.tv_sec * 1000 + ru.ru_utime.tv_usec / 1000,
         (long long)ru.ru_stime.tv_sec * 1000 + ru.ru_stime.tv_usec / 1000,
         ru.ru_maxrss, rss_kb, ru.ru_minflt, ru.ru_majflt, ru.ru_nvcsw, ru.ru_nivcsw,
         sigblk, sigpnd, (int)si->si_pid);
}

static void send_heartbeat(const task_t *t)
{
    char detail[96];
    task_describe(t, detail, sizeof detail);
    g_heartbeats++;
    emit("{\"type\":\"hb\",\"progress\":%lld,\"detail\":\"%s\"}", task_progress(t), detail);
}

/* Hang: stop consuming signals forever. Blocked signals stay pending, so
 * SIGUSR1 and SIGTERM get no reaction; SIGSTOP/SIGCONT/SIGKILL still work
 * because the kernel handles them directly. */
static void hang_forever(void)
{
    for (;;)
        sleep_ms(1000);
}

static void fault(const char *kind, const task_t *t)
{
    emit("{\"type\":\"fault\",\"kind\":\"%s\",\"progress\":%lld}", kind, task_progress(t));
}

static void handle_command(char *cmd, task_t *t)
{
    long code;
    cmd[strcspn(cmd, "\r\n")] = '\0';
    if (strcmp(cmd, "crash") == 0) {
        fault("crash: abort()", t);
        abort();                                      /* raises SIGABRT    */
    } else if (strcmp(cmd, "segv") == 0) {
        fault("crash: SIGSEGV", t);
        signal(SIGSEGV, SIG_DFL);
        raise(SIGSEGV);
    } else if (strcmp(cmd, "hang") == 0) {
        fault("hang", t);
        hang_forever();
    } else if (strncmp(cmd, "exit ", 5) == 0 && parse_long(cmd + 5, 0, 255, &code) == 0) {
        char kind[32];
        snprintf(kind, sizeof kind, "exit %ld", code);
        fault(kind, t);
        exit((int)code);
    }
}

static void check_commands(task_t *t, char *buf, size_t *len)
{
    for (;;) {
        ssize_t r = read(STDIN_FILENO, buf + *len, 255 - *len);
        char *nl;
        if (r == 0) {
            if (g_out != STATUS_FD)
                return;                    /* standalone: no command pipe   */
            /* Command pipe closed: the controller has gone away. */
            emit("{\"type\":\"bye\",\"reason\":\"controller pipe closed\",\"progress\":%lld}",
                 task_progress(t));
            exit(0);
        }
        if (r < 0)
            return;                                   /* EAGAIN / no stdin */
        *len += (size_t)r;
        buf[*len] = '\0';
        while ((nl = strchr(buf, '\n')) != NULL) {
            *nl = '\0';
            handle_command(buf, t);
            memmove(buf, nl + 1, strlen(nl + 1) + 1);
            *len = strlen(buf);
        }
        if (*len >= 255)
            *len = 0;
    }
}

static int parse_args(int argc, char **argv, options_t *o)
{
    int i;
    long v;

    memset(o, 0, sizeof *o);
    copy_str(o->name, "worker", sizeof o->name);
    copy_str(o->task, "primes", sizeof o->task);
    o->heartbeat_ms = 1000;
    o->duty_pct = 20;

    for (i = 1; i < argc; i++) {
        const char *a = argv[i], *val = i + 1 < argc ? argv[i + 1] : NULL;
        if (val == NULL)
            return -1;
        if (strcmp(a, "--name") == 0)
            copy_str(o->name, val, sizeof o->name);
        else if (strcmp(a, "--task") == 0)
            copy_str(o->task, val, sizeof o->task);
        else if (strcmp(a, "--heartbeat-ms") == 0 && parse_long(val, 100, 60000, &v) == 0)
            o->heartbeat_ms = (int)v;
        else if (strcmp(a, "--crash-after") == 0 && parse_long(val, 1, 86400, &v) == 0)
            o->crash_after_s = (int)v;
        else if (strcmp(a, "--exit-after") == 0 && parse_long(val, 1, 86400, &v) == 0)
            o->exit_after_s = (int)v;
        else if (strcmp(a, "--exit-code") == 0 && parse_long(val, 0, 255, &v) == 0)
            o->exit_code = (int)v;
        else if (strcmp(a, "--reply-delay-ms") == 0 && parse_long(val, 0, 60000, &v) == 0)
            o->reply_delay_ms = (int)v;
        else if (strcmp(a, "--duty") == 0 && parse_long(val, 1, 100, &v) == 0)
            o->duty_pct = (int)v;
        else
            return -1;
        i++;
    }
    return 0;
}

int main(int argc, char **argv)
{
    options_t o;
    task_t *t;
    sigset_t set;
    struct sigaction sa;
    char err[128], cmdbuf[256];
    size_t cmdlen = 0;
    int64_t next_hb;
    const int cycle_ms = 50;

    if (parse_args(argc, argv, &o) != 0) {
        fprintf(stderr, "usage: sigworker --name N --task primes|hash|sort [--heartbeat-ms MS]\n"
                        "       [--crash-after S] [--exit-after S --exit-code C]\n"
                        "       [--reply-delay-ms MS] [--duty PCT]\n");
        return 2;
    }

    /* Standalone use (no controller): report on stdout instead of fd 3. */
    if (fcntl(STATUS_FD, F_GETFD) < 0)
        g_out = STDOUT_FILENO;

    /* EPIPE instead of a silent SIGPIPE death if the controller vanishes. */
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = SIG_IGN;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGPIPE, &sa, NULL);

    /* Block the signals we consume synchronously. */
    sigemptyset(&set);
    sigaddset(&set, SIGUSR1);
    sigaddset(&set, SIGUSR2);
    sigaddset(&set, SIGTERM);
    sigaddset(&set, SIGINT);
    sigaddset(&set, SIGHUP);
    if (sigprocmask(SIG_BLOCK, &set, NULL) != 0) {
        perror("sigprocmask");
        return 127;
    }

    t = task_create(o.task, err, sizeof err);
    if (t == NULL) {
        fprintf(stderr, "sigworker: %s\n", err);
        return 127;                                /* "could not start"    */
    }
    set_nonblock(STDIN_FILENO);

    g_start = now_ms();
    next_hb = g_start + o.heartbeat_ms;
    emit("{\"type\":\"hello\",\"pid\":%d,\"ppid\":%d,\"task\":\"%s\",\"version\":\"%s\","
         "\"detail\":\"started\"}", (int)getpid(), (int)getppid(), o.task, SIGCTL_VERSION);

    for (;;) {
        int64_t now = now_ms(), work_until;
        int64_t up = now - g_start;
        struct timespec wait;
        siginfo_t si;
        int sig, idle_ms;

        /* 1. Do some work for duty% of the cycle. */
        work_until = now + cycle_ms * o.duty_pct / 100;
        do {
            int k;
            for (k = 0; k < 64; k++)
                task_step(t);
        } while (now_ms() < work_until);

        /* 2. Scheduled test failures. */
        if (o.crash_after_s > 0 && up >= (int64_t)o.crash_after_s * 1000) {
            fault("scheduled crash: abort()", t);
            abort();
        }
        if (o.exit_after_s > 0 && up >= (int64_t)o.exit_after_s * 1000) {
            char kind[40];
            snprintf(kind, sizeof kind, "scheduled exit %d", o.exit_code);
            fault(kind, t);
            exit(o.exit_code);
        }

        /* 3. Heartbeat. */
        now = now_ms();
        if (now >= next_hb) {
            send_heartbeat(t);
            next_hb = now + o.heartbeat_ms;
        }

        /* 4. Commands from the controller (fault injection). */
        check_commands(t, cmdbuf, &cmdlen);

        /* 5. Sleep for the rest of the cycle, waking at once for a signal,
         *    then drain any further pending signals without waiting. */
        idle_ms = cycle_ms - cycle_ms * o.duty_pct / 100;
        wait.tv_sec = 0;
        wait.tv_nsec = (long)idle_ms * 1000000L;
        for (;;) {
            sig = sigtimedwait(&set, &si, &wait);
            if (sig < 0) {
                if (errno == EINTR)
                    continue;
                break;                               /* EAGAIN: timed out  */
            }
            switch (sig) {
            case SIGUSR1:
                g_usr1++;
                send_status(&o, t, &si);
                break;
            case SIGUSR2:
                g_usr2++;
                send_snapshot(&o, t, &si);
                break;
            default:                                 /* SIGTERM/INT/HUP    */
                emit("{\"type\":\"bye\",\"reason\":\"%s\",\"progress\":%lld}",
                     signal_name(sig), task_progress(t));
                task_destroy(t);
                return 0;
            }
            wait.tv_nsec = 0;                        /* drain, don't sleep */
        }
    }
}
