/*
 * logger.c - Event log implementation.
 *
 * Every event is stored in a fixed-size ring buffer (served to the GUI via
 * the EVENTS command) and appended to a JSON-lines file so the history
 * survives controller restarts. If the file cannot be opened the controller
 * keeps running with the in-memory ring only and reports the problem.
 */
#include "logger.h"

#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

static event_t  g_ring[EVENT_RING];
static uint64_t g_seq;              /* last assigned sequence number         */
static FILE    *g_file;
static char     g_path[PATH_LEN];
static char     g_err[160];
static int      g_echo;
static int      g_tty;

const char *severity_name(severity_t s)
{
    switch (s) {
    case SEV_OK:    return "ok";
    case SEV_WARN:  return "warn";
    case SEV_ERROR: return "error";
    default:        return "info";
    }
}

static FILE *open_log(const char *path, char *err, size_t errlen)
{
    /* "e" = O_CLOEXEC (glibc): the log fd must not leak into workers. */
    FILE *f = fopen(path, "ae");
    if (f == NULL) {
        snprintf(err, errlen, "cannot open log file %s: %s", path, strerror(errno));
        return NULL;
    }
    setvbuf(f, NULL, _IOLBF, 0);   /* line buffered: each event is flushed */
    return f;
}

int logger_init(const char *path, int echo_stdout)
{
    g_echo = echo_stdout;
    g_tty = isatty(STDOUT_FILENO);
    copy_str(g_path, path, sizeof g_path);
    g_err[0] = '\0';
    g_file = open_log(path, g_err, sizeof g_err);
    return g_file ? 0 : -1;
}

int logger_reopen(const char *path, char *err, size_t errlen)
{
    FILE *f = open_log(path, err, errlen);
    if (f == NULL)
        return -1;           /* keep the old file: never lose logging */
    if (g_file)
        fclose(g_file);
    g_file = f;
    copy_str(g_path, path, sizeof g_path);
    g_err[0] = '\0';
    return 0;
}

void logger_close(void)
{
    if (g_file) {
        fclose(g_file);
        g_file = NULL;
    }
}

int         logger_file_ok(void)  { return g_file != NULL; }
const char *logger_path(void)     { return g_path; }
const char *logger_error(void)    { return g_err; }
uint64_t    logger_last_seq(void) { return g_seq; }

static void event_to_json(jbuf_t *j, const event_t *e)
{
    char ts[40];
    format_wall(e->ts_ms, ts, sizeof ts);
    jb_obj_begin(j);
    jb_kint(j, "seq", (long long)e->seq);
    jb_kstr(j, "ts", ts);
    jb_kint(j, "ts_ms", e->ts_ms);
    jb_kstr(j, "severity", severity_name(e->sev));
    jb_kstr(j, "type", e->type);
    jb_kint(j, "worker_id", e->worker_id);
    jb_kstr(j, "worker", e->worker);
    jb_kint(j, "pid", e->pid);
    jb_kstr(j, "action", e->action);
    jb_kstr(j, "message", e->msg);
    jb_obj_end(j);
}

static void echo_event(const event_t *e)
{
    static const char *colors[] = { "\033[37m", "\033[32m", "\033[33m", "\033[31m" };
    char ts[40];
    format_wall(e->ts_ms, ts, sizeof ts);
    printf("%s%s %-5s %-16s %-12s pid=%-7d %-8s %s%s\n",
           g_tty ? colors[e->sev] : "", ts + 11, severity_name(e->sev), e->type,
           e->worker[0] ? e->worker : "controller", e->pid, e->action, e->msg,
           g_tty ? "\033[0m" : "");
    fflush(stdout);
}

void log_event(severity_t sev, const char *type, int worker_id,
               const char *worker, int pid, const char *action,
               const char *fmt, ...)
{
    event_t *e;
    va_list ap;

    g_seq++;
    e = &g_ring[(g_seq - 1) % EVENT_RING];   /* seq N lives at (N-1) % size */
    memset(e, 0, sizeof *e);
    e->seq = g_seq;
    e->ts_ms = wall_ms();
    e->sev = sev;
    copy_str(e->type, type, sizeof e->type);
    e->worker_id = worker_id;
    copy_str(e->worker, worker, sizeof e->worker);
    e->pid = pid;
    copy_str(e->action, action ? action : "", sizeof e->action);
    va_start(ap, fmt);
    vsnprintf(e->msg, sizeof e->msg, fmt, ap);
    va_end(ap);

    if (g_file) {
        jbuf_t j;
        jb_init(&j);
        event_to_json(&j, e);
        if (!j.oom && fprintf(g_file, "%s\n", j.buf) < 0) {
            snprintf(g_err, sizeof g_err, "write to log failed: %s", strerror(errno));
            fclose(g_file);
            g_file = NULL;
        }
        jb_free(&j);
    }
    if (g_echo)
        echo_event(e);
}

void logger_events_json(jbuf_t *j, uint64_t since, int limit, int worker_id)
{
    uint64_t first = g_seq > EVENT_RING ? g_seq - EVENT_RING + 1 : 1;
    uint64_t s;
    int matched = 0, skip;

    if (since + 1 > first)
        first = since + 1;

    /* Count matches so that, when a limit applies, the newest ones win. */
    for (s = first; s <= g_seq; s++) {
        const event_t *e = &g_ring[(s - 1) % EVENT_RING];
        if (worker_id == 0 || e->worker_id == worker_id)
            matched++;
    }
    skip = (limit > 0 && matched > limit) ? matched - limit : 0;

    jb_arr_begin(j);
    for (s = first; s <= g_seq; s++) {
        const event_t *e = &g_ring[(s - 1) % EVENT_RING];
        if (worker_id != 0 && e->worker_id != worker_id)
            continue;
        if (skip > 0) {
            skip--;
            continue;
        }
        event_to_json(j, e);
    }
    jb_arr_end(j);
}
