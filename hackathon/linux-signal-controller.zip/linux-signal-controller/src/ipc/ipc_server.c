/*
 * ipc_server.c - Unix domain socket server.
 */
#include "ipc.h"
#include "common.h"

#include <errno.h>
#include <poll.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <unistd.h>

#define REQUEST_TIMEOUT_MS 1000

int ipc_listen(const char *path, char *err, size_t errlen)
{
    struct sockaddr_un addr;
    mode_t old_umask;
    int fd;

    if (strlen(path) >= sizeof addr.sun_path) {
        snprintf(err, errlen, "socket path too long: %s", path);
        return -1;
    }
    fd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC | SOCK_NONBLOCK, 0);
    if (fd < 0) {
        snprintf(err, errlen, "socket: %s", strerror(errno));
        return -1;
    }
    memset(&addr, 0, sizeof addr);
    addr.sun_family = AF_UNIX;
    copy_str(addr.sun_path, path, sizeof addr.sun_path);

    /* The caller holds the single-instance lock, so any existing socket
     * file is stale (left by a crashed controller) and safe to remove. */
    unlink(path);

    old_umask = umask(0077);            /* socket file created as 0600       */
    if (bind(fd, (struct sockaddr *)&addr, sizeof addr) != 0) {
        snprintf(err, errlen, "bind %s: %s", path, strerror(errno));
        umask(old_umask);
        close(fd);
        return -1;
    }
    umask(old_umask);
    if (listen(fd, 16) != 0) {
        snprintf(err, errlen, "listen: %s", strerror(errno));
        close(fd);
        unlink(path);
        return -1;
    }
    return fd;
}

int ipc_accept(int lfd, char *line, size_t n, char *err, size_t errlen)
{
    struct ucred cred;
    socklen_t clen = sizeof cred;
    size_t got = 0;
    int64_t deadline;
    int cfd;

    cfd = accept4(lfd, NULL, NULL, SOCK_CLOEXEC | SOCK_NONBLOCK);
    if (cfd < 0) {
        if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
            snprintf(err, errlen, "accept: %s", strerror(errno));
        else
            err[0] = '\0';
        return -1;
    }

    /* Only processes running as the same user may control our workers. */
    if (getsockopt(cfd, SOL_SOCKET, SO_PEERCRED, &cred, &clen) != 0 ||
        cred.uid != getuid()) {
        snprintf(err, errlen, "rejected client: peer uid is not %d", (int)getuid());
        ipc_reply(cfd, "{\"ok\":false,\"error\":\"permission denied\"}");
        return -1;
    }

    /* Read one line with a short deadline so a silent client cannot hang
     * the single-threaded controller. */
    deadline = now_ms() + REQUEST_TIMEOUT_MS;
    while (got + 1 < n) {
        struct pollfd pfd = { .fd = cfd, .events = POLLIN };
        int64_t left = deadline - now_ms();
        ssize_t r;

        if (left <= 0) {
            snprintf(err, errlen, "client sent no complete request within %d ms",
                     REQUEST_TIMEOUT_MS);
            close(cfd);
            return -1;
        }
        if (poll(&pfd, 1, (int)left) < 0) {
            if (errno == EINTR)
                continue;
            snprintf(err, errlen, "poll client: %s", strerror(errno));
            close(cfd);
            return -1;
        }
        r = read(cfd, line + got, n - 1 - got);
        if (r < 0) {
            if (errno == EAGAIN || errno == EINTR)
                continue;
            snprintf(err, errlen, "read client: %s", strerror(errno));
            close(cfd);
            return -1;
        }
        if (r == 0) {
            snprintf(err, errlen, "client disconnected before sending a request");
            close(cfd);
            return -1;
        }
        got += (size_t)r;
        line[got] = '\0';
        if (memchr(line, '\n', got) != NULL)
            break;
    }
    line[got] = '\0';
    if (strchr(line, '\n') == NULL) {
        snprintf(err, errlen, "request line too long");
        ipc_reply(cfd, "{\"ok\":false,\"error\":\"request too long\"}");
        return -1;
    }
    line[strcspn(line, "\r\n")] = '\0';
    return cfd;
}

int ipc_reply(int cfd, const char *json)
{
    size_t len = strlen(json), off = 0;
    int rc = 0;
    int64_t deadline = now_ms() + 2000;

    while (off < len + 1) {
        const char *src = off < len ? json + off : "\n";
        size_t want = off < len ? len - off : 1;
        /* MSG_NOSIGNAL: never raise SIGPIPE if the client went away. */
        ssize_t w = send(cfd, src, want, MSG_NOSIGNAL);
        if (w < 0) {
            if (errno == EINTR)
                continue;
            if ((errno == EAGAIN || errno == EWOULDBLOCK) && now_ms() < deadline) {
                struct pollfd pfd = { .fd = cfd, .events = POLLOUT };
                poll(&pfd, 1, 50);
                continue;
            }
            rc = -1;
            break;
        }
        off += (size_t)w;
    }
    close(cfd);
    return rc;
}
