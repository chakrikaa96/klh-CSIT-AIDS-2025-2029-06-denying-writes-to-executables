/*
 * json.c - Implementation of the JSON writer/reader declared in json.h.
 */
#include "json.h"

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void jb_init(jbuf_t *j)
{
    memset(j, 0, sizeof *j);
    j->cap = 1024;
    j->buf = malloc(j->cap);
    if (j->buf == NULL) {
        j->oom = 1;
        j->cap = 0;
        return;
    }
    j->buf[0] = '\0';
}

void jb_free(jbuf_t *j)
{
    free(j->buf);
    memset(j, 0, sizeof *j);
}

const char *jb_cstr(const jbuf_t *j)
{
    if (j->oom || j->buf == NULL)
        return "{\"ok\":false,\"error\":\"out of memory\"}";
    return j->buf;
}

static void jb_reserve(jbuf_t *j, size_t extra)
{
    size_t need;
    char *nb;

    if (j->oom)
        return;
    need = j->len + extra + 1;
    if (need <= j->cap)
        return;
    while (j->cap < need)
        j->cap *= 2;
    nb = realloc(j->buf, j->cap);
    if (nb == NULL) {
        j->oom = 1;
        return;
    }
    j->buf = nb;
}

static void jb_raw(jbuf_t *j, const char *s, size_t n)
{
    jb_reserve(j, n);
    if (j->oom)
        return;
    memcpy(j->buf + j->len, s, n);
    j->len += n;
    j->buf[j->len] = '\0';
}

static void jb_rawf(jbuf_t *j, const char *fmt, ...)
{
    char tmp[64];
    va_list ap;
    int n;

    va_start(ap, fmt);
    n = vsnprintf(tmp, sizeof tmp, fmt, ap);
    va_end(ap);
    if (n > 0)
        jb_raw(j, tmp, (size_t)n < sizeof tmp ? (size_t)n : sizeof tmp - 1);
}

/* Insert a separating comma when needed before a value or key. */
static void jb_sep(jbuf_t *j)
{
    if (j->after_key) {
        j->after_key = 0;
        return;
    }
    if (j->depth > 0 && j->count[j->depth - 1]++ > 0)
        jb_raw(j, ",", 1);
}

static void jb_open(jbuf_t *j, char c)
{
    jb_sep(j);
    jb_raw(j, &c, 1);
    if (j->depth < JB_MAX_DEPTH) {
        j->count[j->depth] = 0;
        j->depth++;
    } else {
        j->oom = 1;  /* nesting too deep: treat as fatal for this buffer */
    }
}

static void jb_close(jbuf_t *j, char c)
{
    if (j->depth > 0)
        j->depth--;
    jb_raw(j, &c, 1);
}

void jb_obj_begin(jbuf_t *j) { jb_open(j, '{'); }
void jb_obj_end(jbuf_t *j)   { jb_close(j, '}'); }
void jb_arr_begin(jbuf_t *j) { jb_open(j, '['); }
void jb_arr_end(jbuf_t *j)   { jb_close(j, ']'); }

static void jb_quoted(jbuf_t *j, const char *s)
{
    static const char hex[] = "0123456789abcdef";
    const unsigned char *p = (const unsigned char *)s;

    jb_raw(j, "\"", 1);
    for (; *p; p++) {
        switch (*p) {
        case '"':  jb_raw(j, "\\\"", 2); break;
        case '\\': jb_raw(j, "\\\\", 2); break;
        case '\n': jb_raw(j, "\\n", 2);  break;
        case '\r': jb_raw(j, "\\r", 2);  break;
        case '\t': jb_raw(j, "\\t", 2);  break;
        default:
            if (*p < 0x20) {
                char esc[6] = { '\\', 'u', '0', '0', hex[*p >> 4], hex[*p & 15] };
                jb_raw(j, esc, 6);
            } else {
                jb_raw(j, (const char *)p, 1);
            }
        }
    }
    jb_raw(j, "\"", 1);
}

void jb_key(jbuf_t *j, const char *key)
{
    jb_sep(j);
    jb_quoted(j, key);
    jb_raw(j, ":", 1);
    j->after_key = 1;
}

void jb_str(jbuf_t *j, const char *s)
{
    jb_sep(j);
    if (s == NULL)
        jb_raw(j, "null", 4);
    else
        jb_quoted(j, s);
}

void jb_int(jbuf_t *j, long long v)  { jb_sep(j); jb_rawf(j, "%lld", v); }
void jb_double(jbuf_t *j, double v)  { jb_sep(j); jb_rawf(j, "%.2f", v); }
void jb_bool(jbuf_t *j, int v)       { jb_sep(j); jb_raw(j, v ? "true" : "false", v ? 4 : 5); }
void jb_null(jbuf_t *j)              { jb_sep(j); jb_raw(j, "null", 4); }

void jb_kstr(jbuf_t *j, const char *k, const char *v)  { jb_key(j, k); jb_str(j, v); }
void jb_kint(jbuf_t *j, const char *k, long long v)    { jb_key(j, k); jb_int(j, v); }
void jb_kdouble(jbuf_t *j, const char *k, double v)    { jb_key(j, k); jb_double(j, v); }
void jb_kbool(jbuf_t *j, const char *k, int v)         { jb_key(j, k); jb_bool(j, v); }

int json_escape(const char *s, char *out, size_t n)
{
    jbuf_t j;
    int rc = -1;

    jb_init(&j);
    jb_quoted(&j, s);
    if (!j.oom && j.len < n) {
        memcpy(out, j.buf, j.len + 1);
        rc = 0;
    }
    jb_free(&j);
    return rc;
}

/* Locate the start of the value for "key": in a flat object. */
static const char *find_value(const char *line, const char *key)
{
    char pat[72];
    const char *p;
    int n = snprintf(pat, sizeof pat, "\"%s\":", key);

    if (n <= 0 || (size_t)n >= sizeof pat)
        return NULL;
    p = strstr(line, pat);
    return p ? p + n : NULL;
}

int json_get_str(const char *line, const char *key, char *out, size_t n)
{
    const char *p = find_value(line, key);
    size_t o = 0;

    if (p == NULL || *p != '"' || n == 0)
        return -1;
    p++;
    while (*p && *p != '"' && o + 1 < n) {
        if (*p == '\\' && p[1]) {
            p++;
            switch (*p) {
            case 'n': out[o++] = ' '; break;
            case 't': out[o++] = ' '; break;
            default:  out[o++] = *p;  break;
            }
            p++;
            continue;
        }
        out[o++] = *p++;
    }
    out[o] = '\0';
    return 0;
}

int json_get_ll(const char *line, const char *key, long long *out)
{
    const char *p = find_value(line, key);
    char *end = NULL;
    long long v;

    if (p == NULL)
        return -1;
    v = strtoll(p, &end, 10);
    if (end == p)
        return -1;
    *out = v;
    return 0;
}
