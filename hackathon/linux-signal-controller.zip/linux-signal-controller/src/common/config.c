/*
 * config.c - Parse, validate, update and save the controller configuration.
 */
#include "config.h"

#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void config_defaults(config_t *c)
{
    memset(c, 0, sizeof *c);
    c->watchdog_enabled      = 1;
    c->max_restarts          = 3;
    c->backoff_base_ms       = 1000;
    c->backoff_max_ms        = 16000;
    c->stable_reset_s        = 30;
    c->monitor_interval_ms   = 500;
    c->heartbeat_interval_ms = 1000;
    c->status_timeout_ms     = 2000;
    c->stop_grace_ms         = 3000;
    copy_str(c->log_file,    "logs/events.jsonl",  sizeof c->log_file);
    copy_str(c->socket_path, "run/sigctl.sock",    sizeof c->socket_path);
    copy_str(c->pid_file,    "run/sigctld.pid",    sizeof c->pid_file);
    copy_str(c->worker_path, "build/sigworker",    sizeof c->worker_path);
    copy_str(c->worker_log,  "logs/workers.log",   sizeof c->worker_log);
}

typedef struct {
    const char *key;
    int        *(*field)(config_t *);
    long        min, max;
} int_key_t;

static int *f_max_restarts(config_t *c)   { return &c->max_restarts; }
static int *f_backoff_base(config_t *c)   { return &c->backoff_base_ms; }
static int *f_backoff_max(config_t *c)    { return &c->backoff_max_ms; }
static int *f_stable_reset(config_t *c)   { return &c->stable_reset_s; }
static int *f_monitor(config_t *c)        { return &c->monitor_interval_ms; }
static int *f_heartbeat(config_t *c)      { return &c->heartbeat_interval_ms; }
static int *f_status_timeout(config_t *c) { return &c->status_timeout_ms; }
static int *f_stop_grace(config_t *c)     { return &c->stop_grace_ms; }

static const int_key_t INT_KEYS[] = {
    { "max_restarts",          f_max_restarts,   0,   100     },
    { "backoff_base_ms",       f_backoff_base,   100, 60000   },
    { "backoff_max_ms",        f_backoff_max,    100, 600000  },
    { "stable_reset_s",        f_stable_reset,   1,   86400   },
    { "monitor_interval_ms",   f_monitor,        100, 10000   },
    { "heartbeat_interval_ms", f_heartbeat,      200, 10000   },
    { "status_timeout_ms",     f_status_timeout, 200, 30000   },
    { "stop_grace_ms",         f_stop_grace,     200, 60000   },
};

static int set_path(char *dst, size_t n, const char *value, char *err, size_t errlen)
{
    if (value[0] == '\0' || strlen(value) >= n) {
        snprintf(err, errlen, "path is empty or longer than %zu bytes", n - 1);
        return -1;
    }
    copy_str(dst, value, n);
    return 0;
}

int config_set(config_t *c, const char *key, const char *value, int runtime,
               char *err, size_t errlen)
{
    size_t i;
    long v;

    for (i = 0; i < sizeof INT_KEYS / sizeof INT_KEYS[0]; i++) {
        if (strcmp(key, INT_KEYS[i].key) == 0) {
            if (parse_long(value, INT_KEYS[i].min, INT_KEYS[i].max, &v) != 0) {
                snprintf(err, errlen, "%s must be an integer in [%ld, %ld]",
                         key, INT_KEYS[i].min, INT_KEYS[i].max);
                return -1;
            }
            *INT_KEYS[i].field(c) = (int)v;
            if (c->backoff_max_ms < c->backoff_base_ms)
                c->backoff_max_ms = c->backoff_base_ms;
            return 0;
        }
    }

    if (strcmp(key, "watchdog") == 0) {
        if (strcmp(value, "on") == 0 || strcmp(value, "1") == 0)
            c->watchdog_enabled = 1;
        else if (strcmp(value, "off") == 0 || strcmp(value, "0") == 0)
            c->watchdog_enabled = 0;
        else {
            snprintf(err, errlen, "watchdog must be on or off");
            return -1;
        }
        return 0;
    }

    if (strcmp(key, "log_file") == 0)
        return set_path(c->log_file, sizeof c->log_file, value, err, errlen);

    if (runtime) {
        snprintf(err, errlen, "'%s' cannot be changed while running", key);
        return -1;
    }
    if (strcmp(key, "socket_path") == 0)
        return set_path(c->socket_path, sizeof c->socket_path, value, err, errlen);
    if (strcmp(key, "pid_file") == 0)
        return set_path(c->pid_file, sizeof c->pid_file, value, err, errlen);
    if (strcmp(key, "worker_path") == 0)
        return set_path(c->worker_path, sizeof c->worker_path, value, err, errlen);
    if (strcmp(key, "worker_log") == 0)
        return set_path(c->worker_log, sizeof c->worker_log, value, err, errlen);

    snprintf(err, errlen, "unknown setting '%s'", key);
    return -1;
}

static char *trim(char *s)
{
    char *e;
    while (isspace((unsigned char)*s))
        s++;
    e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1]))
        *--e = '\0';
    return s;
}

int config_load(config_t *c, const char *path, char *err, size_t errlen)
{
    FILE *f = fopen(path, "r");
    char line[512];
    int lineno = 0;

    if (f == NULL) {
        snprintf(err, errlen, "cannot open %s: %s", path, strerror(errno));
        return -1;
    }
    while (fgets(line, sizeof line, f) != NULL) {
        char *p, *eq, *key, *val, msg[160];
        lineno++;
        p = trim(line);
        if (*p == '\0' || *p == '#')
            continue;
        eq = strchr(p, '=');
        if (eq == NULL) {
            snprintf(err, errlen, "%s:%d: expected key = value", path, lineno);
            fclose(f);
            return -1;
        }
        *eq = '\0';
        key = trim(p);
        val = eq + 1;
        val[strcspn(val, "#")] = '\0';          /* allow trailing comments */
        val = trim(val);
        if (config_set(c, key, val, 0, msg, sizeof msg) != 0) {
            snprintf(err, errlen, "%s:%d: %s", path, lineno, msg);
            fclose(f);
            return -1;
        }
    }
    fclose(f);
    return 0;
}

int config_save(const config_t *c, const char *path, char *err, size_t errlen)
{
    char tmp[PATH_LEN + 8];
    FILE *f;

    snprintf(tmp, sizeof tmp, "%s.tmp", path);
    f = fopen(tmp, "w");
    if (f == NULL) {
        snprintf(err, errlen, "cannot write %s: %s", tmp, strerror(errno));
        return -1;
    }
    fprintf(f,
            "# Linux Signal-Based Process Controller configuration\n"
            "# Saved by the controller. Format: key = value\n\n"
            "# Watchdog and recovery\n"
            "watchdog              = %s\n"
            "max_restarts          = %d\n"
            "backoff_base_ms       = %d\n"
            "backoff_max_ms        = %d\n"
            "stable_reset_s        = %d\n\n"
            "# Monitoring\n"
            "monitor_interval_ms   = %d\n"
            "heartbeat_interval_ms = %d\n"
            "status_timeout_ms     = %d\n"
            "stop_grace_ms         = %d\n\n"
            "# Paths (relative paths are resolved from the project root)\n"
            "log_file              = %s\n"
            "socket_path           = %s\n"
            "pid_file              = %s\n"
            "worker_path           = %s\n"
            "worker_log            = %s\n",
            c->watchdog_enabled ? "on" : "off", c->max_restarts,
            c->backoff_base_ms, c->backoff_max_ms, c->stable_reset_s,
            c->monitor_interval_ms, c->heartbeat_interval_ms,
            c->status_timeout_ms, c->stop_grace_ms, c->log_file,
            c->socket_path, c->pid_file, c->worker_path, c->worker_log);
    if (fclose(f) != 0 || rename(tmp, path) != 0) {
        snprintf(err, errlen, "cannot save %s: %s", path, strerror(errno));
        unlink(tmp);
        return -1;
    }
    return 0;
}

static int absolutize(char *p, size_t n, const char *cwd, char *err, size_t errlen)
{
    char out[PATH_MAX];
    if (p[0] == '/')
        return 0;
    if ((size_t)snprintf(out, sizeof out, "%s/%s", cwd, p) >= n) {
        snprintf(err, errlen, "absolute path for '%s' is longer than %zu bytes", p, n - 1);
        return -1;
    }
    copy_str(p, out, n);
    return 0;
}

int config_absolutize(config_t *c, char *err, size_t errlen)
{
    char cwd[PATH_MAX];

    if (getcwd(cwd, sizeof cwd) == NULL) {
        snprintf(err, errlen, "getcwd: %s", strerror(errno));
        return -1;
    }
    if (absolutize(c->log_file, sizeof c->log_file, cwd, err, errlen) ||
        absolutize(c->socket_path, sizeof c->socket_path, cwd, err, errlen) ||
        absolutize(c->pid_file, sizeof c->pid_file, cwd, err, errlen) ||
        absolutize(c->worker_path, sizeof c->worker_path, cwd, err, errlen) ||
        absolutize(c->worker_log, sizeof c->worker_log, cwd, err, errlen))
        return -1;
    return 0;
}
