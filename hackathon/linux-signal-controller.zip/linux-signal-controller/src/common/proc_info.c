/*
 * proc_info.c - /proc parsing.
 *
 * /proc/<pid>/stat format: "pid (comm) state ppid pgrp ...". The command
 * name may contain spaces or ')' so parsing starts after the LAST ')'.
 */
#include "proc_info.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

long proc_clk_tck(void)
{
    static long tck;
    if (tck <= 0)
        tck = sysconf(_SC_CLK_TCK);
    return tck > 0 ? tck : 100;
}

static void read_status_fields(pid_t pid, proc_info_t *out)
{
    char path[64], line[256];
    FILE *f;

    snprintf(path, sizeof path, "/proc/%d/status", (int)pid);
    f = fopen(path, "r");
    if (f == NULL)
        return;
    while (fgets(line, sizeof line, f) != NULL) {
        if (strncmp(line, "VmRSS:", 6) == 0)
            out->rss_kb = strtol(line + 6, NULL, 10);
        else if (strncmp(line, "Threads:", 8) == 0)
            out->threads = (int)strtol(line + 8, NULL, 10);
        else if (strncmp(line, "voluntary_ctxt_switches:", 24) == 0)
            out->vol_ctxt = strtoll(line + 24, NULL, 10);
        else if (strncmp(line, "nonvoluntary_ctxt_switches:", 27) == 0)
            out->invol_ctxt = strtoll(line + 27, NULL, 10);
    }
    fclose(f);
}

int proc_read(pid_t pid, proc_info_t *out)
{
    char path[64], buf[1024];
    char *p;
    FILE *f;
    size_t n;
    int ppid = 0, pgid = 0, field;
    unsigned long long utime = 0, stime = 0;

    memset(out, 0, sizeof *out);
    if (pid <= 0)
        return -1;
    snprintf(path, sizeof path, "/proc/%d/stat", (int)pid);
    f = fopen(path, "r");
    if (f == NULL)
        return -1;
    n = fread(buf, 1, sizeof buf - 1, f);
    fclose(f);
    buf[n] = '\0';

    p = strrchr(buf, ')');
    if (p == NULL || p[1] != ' ')
        return -1;
    p += 2;                         /* now at field 3: state                  */
    out->state = *p;

    /* Walk the space separated fields 3..15. */
    field = 3;
    while (*p && field <= 15) {
        char *end;
        unsigned long long v = strtoull(p, &end, 10);
        if (field == 4) ppid = (int)v;
        if (field == 5) pgid = (int)v;
        if (field == 14) utime = v;
        if (field == 15) stime = v;
        p = strchr(p, ' ');
        if (p == NULL)
            break;
        p++;
        field++;
    }
    out->ppid = ppid;
    out->pgid = pgid;
    out->cpu_ticks = utime + stime;
    read_status_fields(pid, out);
    return 0;
}

int proc_is_child_of(pid_t pid, pid_t parent)
{
    proc_info_t pi;
    if (proc_read(pid, &pi) != 0)
        return 0;
    return pi.ppid == parent;
}

const char *proc_state_name(char state)
{
    switch (state) {
    case 'R': return "running";
    case 'S': return "sleeping";
    case 'D': return "disk wait";
    case 'T': return "stopped";
    case 't': return "traced";
    case 'Z': return "zombie";
    case 'X': return "dead";
    case 'I': return "idle";
    default:  return "unknown";
    }
}
