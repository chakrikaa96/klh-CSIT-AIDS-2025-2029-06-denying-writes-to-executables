/*
 * util.c - Small helpers shared by the controller, worker and client.
 */
#include "common.h"

#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int64_t now_ms(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (int64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

int64_t wall_ms(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    return (int64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

void format_wall(int64_t ms, char *buf, size_t n)
{
    time_t secs = (time_t)(ms / 1000);
    struct tm tmv;
    char base[32];

    localtime_r(&secs, &tmv);
    strftime(base, sizeof base, "%Y-%m-%dT%H:%M:%S", &tmv);
    snprintf(buf, n, "%s.%03d", base, (int)(ms % 1000));
}

const char *signal_name(int sig)
{
    switch (sig) {
    case SIGHUP:  return "SIGHUP";
    case SIGINT:  return "SIGINT";
    case SIGQUIT: return "SIGQUIT";
    case SIGILL:  return "SIGILL";
    case SIGTRAP: return "SIGTRAP";
    case SIGABRT: return "SIGABRT";
    case SIGBUS:  return "SIGBUS";
    case SIGFPE:  return "SIGFPE";
    case SIGKILL: return "SIGKILL";
    case SIGUSR1: return "SIGUSR1";
    case SIGSEGV: return "SIGSEGV";
    case SIGUSR2: return "SIGUSR2";
    case SIGPIPE: return "SIGPIPE";
    case SIGALRM: return "SIGALRM";
    case SIGTERM: return "SIGTERM";
    case SIGCHLD: return "SIGCHLD";
    case SIGCONT: return "SIGCONT";
    case SIGSTOP: return "SIGSTOP";
    case SIGTSTP: return "SIGTSTP";
    case SIGTTIN: return "SIGTTIN";
    case SIGTTOU: return "SIGTTOU";
    case SIGXCPU: return "SIGXCPU";
    case SIGSYS:  return "SIGSYS";
    default:      return "SIG?";
    }
}

int parse_long(const char *s, long min, long max, long *out)
{
    char *end = NULL;
    long v;

    if (s == NULL || *s == '\0')
        return -1;
    errno = 0;
    v = strtol(s, &end, 10);
    if (errno != 0 || end == s || *end != '\0')
        return -1;
    if (v < min || v > max)
        return -1;
    *out = v;
    return 0;
}

int set_nonblock(int fd)
{
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0)
        return -1;
    return fcntl(fd, F_SETFL, flags | O_NONBLOCK);
}

void copy_str(char *dst, const char *src, size_t n)
{
    if (n == 0)
        return;
    if (src == NULL)
        src = "";
    strncpy(dst, src, n - 1);
    dst[n - 1] = '\0';
}

void format_duration(int64_t ms, char *buf, size_t n)
{
    int64_t s = ms / 1000;
    if (s < 0)
        s = 0;
    if (s >= 3600)
        snprintf(buf, n, "%lldh %02lldm %02llds", (long long)(s / 3600),
                 (long long)(s % 3600 / 60), (long long)(s % 60));
    else if (s >= 60)
        snprintf(buf, n, "%lldm %02llds", (long long)(s / 60), (long long)(s % 60));
    else
        snprintf(buf, n, "%llds", (long long)s);
}
