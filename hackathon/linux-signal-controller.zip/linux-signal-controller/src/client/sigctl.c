/*
 * sigctl.c - Command-line client for the controller.
 *
 * Usage: sigctl [-s socket] COMMAND [ARGS...]
 * Sends one request line over the Unix socket and prints the JSON reply.
 * Exit status: 0 if the reply has "ok":true, 1 otherwise, 2 on usage or
 * connection errors.
 */
#include "common.h"

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/un.h>
#include <unistd.h>

static void usage(void)
{
    fprintf(stderr,
            "usage: sigctl [-s socket] COMMAND [ARGS]\n\n"
            "Queries:   PING | LIST | INFO <id> | EVENTS [since] [limit] | PROFILES | CONFIG\n"
            "Workers:   SPAWN <profile> [name] | PAUSE <id> | RESUME <id> | STATUS <id>\n"
            "           SNAPSHOT <id> | STOP <id> | RESTART <id> | REMOVE <id>\n"
            "           FAULT <id> crash|segv|hang|exit [code]\n"
            "Global:    STOPALL | WATCHDOG on|off | CONFIG SET <key> <value> | CONFIG SAVE\n"
            "           SHUTDOWN\n\n"
            "Default socket: $SIGCTL_SOCKET or run/sigctl.sock\n");
}

int main(int argc, char **argv)
{
    const char *sock = getenv("SIGCTL_SOCKET");
    struct sockaddr_un addr;
    struct timeval tv = { 20, 0 };
    char req[MAX_LINE], resp[65536];
    size_t len = 0, got = 0;
    int fd, i = 1;

    if (sock == NULL || sock[0] == '\0')
        sock = "run/sigctl.sock";
    if (argc >= 3 && strcmp(argv[1], "-s") == 0) {
        sock = argv[2];
        i = 3;
    }
    if (i >= argc || strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) {
        usage();
        return 2;
    }
    for (; i < argc; i++) {
        int n = snprintf(req + len, sizeof req - len, "%s%s", len ? " " : "", argv[i]);
        if (n < 0 || (size_t)n >= sizeof req - len - 1) {
            fprintf(stderr, "sigctl: request too long\n");
            return 2;
        }
        len += (size_t)n;
    }
    req[len++] = '\n';

    if (strlen(sock) >= sizeof addr.sun_path) {
        fprintf(stderr, "sigctl: socket path too long\n");
        return 2;
    }
    fd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
    if (fd < 0) {
        perror("sigctl: socket");
        return 2;
    }
    memset(&addr, 0, sizeof addr);
    addr.sun_family = AF_UNIX;
    copy_str(addr.sun_path, sock, sizeof addr.sun_path);
    if (connect(fd, (struct sockaddr *)&addr, sizeof addr) != 0) {
        fprintf(stderr, "sigctl: cannot connect to %s: %s (is sigctld running?)\n",
                sock, strerror(errno));
        close(fd);
        return 2;
    }
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
    if (send(fd, req, len, MSG_NOSIGNAL) != (ssize_t)len) {
        perror("sigctl: send");
        close(fd);
        return 2;
    }
    shutdown(fd, SHUT_WR);
    for (;;) {
        ssize_t r = read(fd, resp + got, sizeof resp - 1 - got);
        if (r < 0 && errno == EINTR)
            continue;
        if (r <= 0)
            break;
        got += (size_t)r;
        if (got >= sizeof resp - 1)
            break;
    }
    close(fd);
    resp[got] = '\0';
    if (got == 0) {
        fprintf(stderr, "sigctl: no reply from controller\n");
        return 2;
    }
    fputs(resp, stdout);
    if (resp[got - 1] != '\n')
        putchar('\n');
    return strncmp(resp, "{\"ok\":true", 10) == 0 ? 0 : 1;
}
