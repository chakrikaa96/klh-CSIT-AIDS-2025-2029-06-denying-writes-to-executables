/*
 * registry.c - Worker slots, worker profiles, fork/exec, validated signals,
 * and the worker -> controller pipe reader.
 */
#include "controller.h"
#include "logger.h"
#include "proc_info.h"
#include "signals.h"
#include "watchdog.h"

#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <sys/prctl.h>
#include <unistd.h>

/* Built-in worker profiles. The last three are test workers that fail in
 * well-defined ways so recovery can be demonstrated reproducibly. */
static const profile_t PROFILES[] = {
    { "primes", "primes", "Counts prime numbers (steady CPU work)",              0, 0, 0, 0    },
    { "hasher", "hash",   "Hashes synthetic data blocks with FNV-1a",            0, 0, 0, 0    },
    { "sorter", "sort",   "Fills and sorts random arrays repeatedly",            0, 0, 0, 0    },
    { "crashy", "primes", "Test worker: aborts itself (SIGABRT) after 5 s",      5, 0, 0, 0    },
    { "flaky",  "hash",   "Test worker: exits with code 3 after 6 s",            0, 6, 3, 0    },
    { "sleepy", "sort",   "Test worker: answers status requests after 4 s",      0, 0, 0, 4000 },
};
#define NPROFILES (sizeof PROFILES / sizeof PROFILES[0])

const profile_t *profile_find(const char *name)
{
    size_t i;
    for (i = 0; i < NPROFILES; i++)
        if (strcmp(PROFILES[i].name, name) == 0)
            return &PROFILES[i];
    return NULL;
}

void profiles_json(jbuf_t *j)
{
    size_t i;
    jb_arr_begin(j);
    for (i = 0; i < NPROFILES; i++) {
        jb_obj_begin(j);
        jb_kstr(j, "name", PROFILES[i].name);
        jb_kstr(j, "task", PROFILES[i].task);
        jb_kstr(j, "description", PROFILES[i].description);
        jb_kbool(j, "test_worker", PROFILES[i].crash_after_s || PROFILES[i].exit_after_s ||
                                   PROFILES[i].reply_delay_ms);
        jb_obj_end(j);
    }
    jb_arr_end(j);
}

const char *state_name(wstate_t s)
{
    switch (s) {
    case ST_STARTING:  return "starting";
    case ST_RUNNING:   return "running";
    case ST_PAUSED:    return "paused";
    case ST_STOPPING:  return "stopping";
    case ST_STOPPED:   return "stopped";
    case ST_COMPLETED: return "completed";
    case ST_BACKOFF:   return "backoff";
    case ST_FAILED:    return "failed";
    default:           return "empty";
    }
}

const char *health_name(health_t h)
{
    switch (h) {
    case H_OK:           return "ok";
    case H_LATE:         return "late";
    case H_UNRESPONSIVE: return "unresponsive";
    case H_PAUSED:       return "paused";
    default:             return "none";
    }
}

worker_t *reg_get(int id)
{
    if (id < 1 || id > MAX_WORKERS || !g_ctl.w[id].in_use)
        return NULL;
    return &g_ctl.w[id];
}

worker_t *reg_by_pid(pid_t pid)
{
    int i;
    if (pid <= 0)
        return NULL;
    for (i = 1; i <= MAX_WORKERS; i++)
        if (g_ctl.w[i].in_use && g_ctl.w[i].pid == pid)
            return &g_ctl.w[i];
    return NULL;
}

int reg_live_count(void)
{
    int i, n = 0;
    for (i = 1; i <= MAX_WORKERS; i++)
        if (g_ctl.w[i].in_use && g_ctl.w[i].pid > 0)
            n++;
    return n;
}

static int valid_name(const char *s)
{
    size_t i, len = strlen(s);
    if (len == 0 || len >= NAME_LEN)
        return 0;
    for (i = 0; i < len; i++) {
        char c = s[i];
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
              (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.'))
            return 0;
    }
    return 1;
}

worker_t *reg_alloc(const profile_t *p, const char *name, char *err, size_t n)
{
    char auto_name[NAME_LEN];
    int i;

    if (name == NULL || name[0] == '\0') {
        snprintf(auto_name, sizeof auto_name, "%s-%d", p->name, ++g_ctl.name_seq);
        name = auto_name;
    } else if (!valid_name(name)) {
        snprintf(err, n, "invalid worker name (use 1-31 of A-Z a-z 0-9 - _ .)");
        return NULL;
    }
    for (i = 1; i <= MAX_WORKERS; i++)
        if (g_ctl.w[i].in_use && strcmp(g_ctl.w[i].name, name) == 0) {
            snprintf(err, n, "a worker named '%s' already exists", name);
            return NULL;
        }
    for (i = 1; i <= MAX_WORKERS; i++) {
        worker_t *w = &g_ctl.w[i];
        if (w->in_use)
            continue;
        memset(w, 0, sizeof *w);
        w->id = i;
        w->in_use = 1;
        w->status_fd = -1;
        w->cmd_fd = -1;
        w->pend.client_fd = -1;
        w->created_wall_ms = wall_ms();
        copy_str(w->name, name, sizeof w->name);
        copy_str(w->profile, p->name, sizeof w->profile);
        copy_str(w->task, "not started", sizeof w->task);
        return w;
    }
    snprintf(err, n, "worker table is full (%d workers)", MAX_WORKERS);
    return NULL;
}

void reg_free(worker_t *w)
{
    reg_close_pipes(w);
    memset(w, 0, sizeof *w);
    w->status_fd = -1;
    w->cmd_fd = -1;
    w->pend.client_fd = -1;
}

void reg_close_pipes(worker_t *w)
{
    if (w->status_fd >= 0)
        close(w->status_fd);
    if (w->cmd_fd >= 0)
        close(w->cmd_fd);
    w->status_fd = -1;
    w->cmd_fd = -1;
    w->rlen = 0;
}

void reg_hist_add(hist_t *h, int *count, const char *fmt, ...)
{
    va_list ap;
    int i;

    if (*count == HIST_LEN) {           /* drop the oldest entry            */
        for (i = 1; i < HIST_LEN; i++)
            h[i - 1] = h[i];
        (*count)--;
    }
    h[*count].ts_ms = wall_ms();
    va_start(ap, fmt);
    vsnprintf(h[*count].text, sizeof h[*count].text, fmt, ap);
    va_end(ap);
    (*count)++;
}

int reg_spawn(worker_t *w, char *err, size_t n)
{
    const profile_t *p = profile_find(w->profile);
    const config_t *c = &g_ctl.cfg;
    char hb[16], crash[16], exit_after[16], exit_code[16], delay[16];
    char *argv[20];
    int sp[2] = { -1, -1 }, cp[2] = { -1, -1 };
    int a = 0;
    pid_t parent = getpid(), pid;
    sigset_t old;

    if (p == NULL) {
        snprintf(err, n, "unknown profile '%s'", w->profile);
        return -1;
    }
    if (access(c->worker_path, X_OK) != 0) {
        snprintf(err, n, "worker program %s is not executable: %s (run 'make')",
                 c->worker_path, strerror(errno));
        return -1;
    }
    /* sp: worker writes status lines; cp: controller writes commands.
     * O_CLOEXEC keeps these from leaking into other workers. */
    if (pipe2(sp, O_CLOEXEC) != 0 || pipe2(cp, O_CLOEXEC) != 0) {
        snprintf(err, n, "pipe2: %s", strerror(errno));
        if (sp[0] >= 0) { close(sp[0]); close(sp[1]); }
        return -1;
    }

    snprintf(hb, sizeof hb, "%d", c->heartbeat_interval_ms);
    argv[a++] = (char *)c->worker_path;
    argv[a++] = "--name";         argv[a++] = w->name;
    argv[a++] = "--task";         argv[a++] = (char *)p->task;
    argv[a++] = "--heartbeat-ms"; argv[a++] = hb;
    if (p->crash_after_s > 0) {
        snprintf(crash, sizeof crash, "%d", p->crash_after_s);
        argv[a++] = "--crash-after"; argv[a++] = crash;
    }
    if (p->exit_after_s > 0) {
        snprintf(exit_after, sizeof exit_after, "%d", p->exit_after_s);
        snprintf(exit_code, sizeof exit_code, "%d", p->exit_code);
        argv[a++] = "--exit-after"; argv[a++] = exit_after;
        argv[a++] = "--exit-code";  argv[a++] = exit_code;
    }
    if (p->reply_delay_ms > 0) {
        snprintf(delay, sizeof delay, "%d", p->reply_delay_ms);
        argv[a++] = "--reply-delay-ms"; argv[a++] = delay;
    }
    argv[a] = NULL;

    /* Block signals across fork() so no controller handler can run in the
     * child before it has reset its dispositions. */
    signals_block_all(&old);
    pid = fork();
    if (pid < 0) {
        int e = errno;
        signals_restore(&old);
        close(sp[0]); close(sp[1]); close(cp[0]); close(cp[1]);
        snprintf(err, n, "fork: %s", strerror(e));
        return -1;
    }

    if (pid == 0) {
        /* ---- child: only async-signal-safe calls until execv() ---- */
        int lf;
        signals_reset_in_child(&old);
        setpgid(0, 0);       /* own process group: terminal Ctrl-C does not
                                reach workers; the controller manages them */
        /* If the controller dies abruptly (even SIGKILL), the kernel sends
         * SIGTERM to the worker so no orphan keeps running. */
        prctl(PR_SET_PDEATHSIG, SIGTERM);
        if (getppid() != parent)          /* parent died before prctl()     */
            _exit(EXIT_START_FAILURE);
        dup2(cp[0], STDIN_FILENO);        /* commands arrive on stdin       */
        dup2(sp[1], 3);                   /* status lines go out on fd 3    */
        lf = open(c->worker_log, O_WRONLY | O_APPEND | O_CREAT | O_CLOEXEC, 0644);
        if (lf < 0)
            lf = open("/dev/null", O_WRONLY | O_CLOEXEC);
        if (lf >= 0) {
            dup2(lf, STDOUT_FILENO);
            dup2(lf, STDERR_FILENO);
        }
        execv(c->worker_path, argv);
        {
            /* exec failed: report through the status pipe, then exit 127 */
            static const char msg[] = "{\"type\":\"exec_error\"}\n";
            ssize_t r = write(3, msg, sizeof msg - 1);
            (void)r;
        }
        _exit(EXIT_START_FAILURE);
    }

    /* ---- parent ---- */
    setpgid(pid, pid);       /* also set from the parent: avoids a race; an
                                EACCES after the child's exec is harmless   */
    signals_restore(&old);
    close(cp[0]);
    close(sp[1]);
    w->status_fd = sp[0];
    w->cmd_fd = cp[1];
    set_nonblock(w->status_fd);
    set_nonblock(w->cmd_fd);

    w->pid = pid;
    w->state = ST_STARTING;
    w->health = H_NONE;
    w->started_ms = now_ms();
    w->started_wall_ms = wall_ms();
    w->last_heartbeat_ms = w->started_ms;
    w->stop_requested = 0;
    w->restart_after_stop = 0;
    w->progress = 0;
    w->rlen = 0;
    w->proc_state = '?';
    w->cpu_pct = 0;
    w->rss_kb = 0;
    w->prev_ticks = 0;
    w->prev_ticks_ms = 0;
    w->fail_reason[0] = '\0';
    copy_str(w->task, "starting", sizeof w->task);

    log_event(SEV_INFO, "worker_spawn", w->id, w->name, pid, "fork/exec",
              "started profile '%s' (task %s) in process group %d",
              p->name, p->task, (int)pid);
    return 0;
}

int reg_signal(worker_t *w, int sig, const char *why, char *err, size_t n)
{
    if (w->pid <= 0) {
        snprintf(err, n, "worker '%s' has no running process", w->name);
        return -1;
    }
    /* Defence in depth: the registry PID must still be our child. */
    if (!proc_is_child_of(w->pid, getpid())) {
        snprintf(err, n, "PID %d is not a child of this controller; refusing to signal it",
                 (int)w->pid);
        log_event(SEV_ERROR, "signal_refused", w->id, w->name, w->pid, signal_name(sig),
                  "ownership check failed");
        return -1;
    }
    if (kill(w->pid, sig) != 0) {
        snprintf(err, n, "kill(%d, %s) failed: %s", (int)w->pid, signal_name(sig),
                 strerror(errno));
        log_event(SEV_ERROR, "signal_failed", w->id, w->name, w->pid, signal_name(sig),
                  "%s", strerror(errno));
        return -1;
    }
    log_event(SEV_INFO, "signal_sent", w->id, w->name, w->pid, signal_name(sig), "%s", why);
    return 0;
}

int reg_send_cmd(worker_t *w, const char *cmd, char *err, size_t n)
{
    char line[64];
    int len = snprintf(line, sizeof line, "%s\n", cmd);
    ssize_t r;

    if (w->cmd_fd < 0 || w->pid <= 0) {
        snprintf(err, n, "worker '%s' is not running", w->name);
        return -1;
    }
    r = write(w->cmd_fd, line, (size_t)len);
    if (r != len) {
        snprintf(err, n, "write to worker command pipe failed: %s",
                 r < 0 ? strerror(errno) : "short write");
        return -1;
    }
    return 0;
}

void reg_read_pipe(worker_t *w)
{
    for (;;) {
        ssize_t r;
        char *nl;

        if (w->status_fd < 0)
            return;
        r = read(w->status_fd, w->rbuf + w->rlen, sizeof w->rbuf - 1 - w->rlen);
        if (r < 0) {
            if (errno == EINTR)
                continue;
            return;                            /* EAGAIN: nothing more now */
        }
        if (r == 0) {                          /* EOF: worker closed fd 3  */
            close(w->status_fd);
            w->status_fd = -1;
            return;
        }
        w->rlen += (size_t)r;
        w->rbuf[w->rlen] = '\0';
        while ((nl = memchr(w->rbuf, '\n', w->rlen)) != NULL) {
            size_t linelen = (size_t)(nl - w->rbuf);
            char line[MAX_LINE];
            memcpy(line, w->rbuf, linelen);
            line[linelen] = '\0';
            memmove(w->rbuf, nl + 1, w->rlen - linelen - 1);
            w->rlen -= linelen + 1;
            w->rbuf[w->rlen] = '\0';
            cmd_worker_message(w, line);
        }
        if (w->rlen >= sizeof w->rbuf - 1) {
            log_event(SEV_WARN, "protocol", w->id, w->name, w->pid, "",
                      "discarded over-long line from worker");
            w->rlen = 0;
        }
    }
}

void reg_refresh_metrics(int64_t now)
{
    long tck = proc_clk_tck();
    int i;

    for (i = 1; i <= MAX_WORKERS; i++) {
        worker_t *w = &g_ctl.w[i];
        proc_info_t pi;

        if (!w->in_use || w->pid <= 0)
            continue;
        if (proc_read(w->pid, &pi) != 0) {
            w->proc_state = '?';
            continue;
        }
        w->proc_state = pi.state;
        w->rss_kb = pi.rss_kb;
        w->threads = pi.threads;
        if (w->prev_ticks_ms > 0 && now > w->prev_ticks_ms && pi.cpu_ticks >= w->prev_ticks)
            w->cpu_pct = (double)(pi.cpu_ticks - w->prev_ticks) * 1000.0 * 100.0 /
                         ((double)tck * (double)(now - w->prev_ticks_ms));
        w->prev_ticks = pi.cpu_ticks;
        w->prev_ticks_ms = now;
    }
}

static void hist_json(jbuf_t *j, const char *key, const hist_t *h, int count)
{
    char ts[40];
    int i;
    jb_key(j, key);
    jb_arr_begin(j);
    for (i = count - 1; i >= 0; i--) {          /* newest first             */
        format_wall(h[i].ts_ms, ts, sizeof ts);
        jb_obj_begin(j);
        jb_kstr(j, "ts", ts);
        jb_kstr(j, "text", h[i].text);
        jb_obj_end(j);
    }
    jb_arr_end(j);
}

void worker_json(jbuf_t *j, const worker_t *w, int detailed)
{
    int64_t now = now_ms();
    char ts[40];

    jb_obj_begin(j);
    jb_kint(j, "id", w->id);
    jb_kstr(j, "name", w->name);
    jb_kstr(j, "profile", w->profile);
    jb_kint(j, "pid", w->pid);
    jb_kstr(j, "state", state_name(w->state));
    jb_kstr(j, "health", health_name(w->health));
    jb_kint(j, "uptime_ms", w->pid > 0 ? now - w->started_ms : 0);
    jb_kint(j, "restarts", w->restarts_total);
    jb_kint(j, "consecutive_failures", w->consecutive_failures);
    jb_kstr(j, "task", w->task);
    jb_kint(j, "progress", w->progress);
    jb_kstr(j, "last_exit", w->exit_valid ? w->exit_desc : "");
    jb_kstr(j, "fail_reason", w->fail_reason);
    jb_kint(j, "restart_in_ms",
            w->state == ST_BACKOFF && w->restart_at_ms > now ? w->restart_at_ms - now : 0);
    jb_kdouble(j, "cpu_pct", w->pid > 0 ? w->cpu_pct : 0.0);
    jb_kint(j, "rss_kb", w->pid > 0 ? w->rss_kb : 0);
    {
        char st[2] = { w->pid > 0 ? w->proc_state : '-', '\0' };
        jb_kstr(j, "proc_state", st);
    }
    jb_kstr(j, "pending", w->pend.op == OP_NONE ? "" :
            w->pend.op == OP_PAUSE ? "pause" : w->pend.op == OP_RESUME ? "resume" :
            w->pend.op == OP_STATUS ? "status" : w->pend.op == OP_SNAPSHOT ? "snapshot" :
            w->pend.op == OP_STOP ? "stop" : "restart");

    if (detailed) {
        format_wall(w->created_wall_ms, ts, sizeof ts);
        jb_kstr(j, "created", ts);
        if (w->pid > 0) {
            format_wall(w->started_wall_ms, ts, sizeof ts);
            jb_kstr(j, "started", ts);
        } else {
            jb_kstr(j, "started", "");
        }
        jb_kint(j, "threads", w->pid > 0 ? w->threads : 0);
        jb_kint(j, "exit_code", w->exit_valid ? w->exit_code : -1);
        jb_kstr(j, "exit_signal", w->exit_valid && w->exit_signal ? signal_name(w->exit_signal) : "");
        jb_kbool(j, "core_dumped", w->exit_valid && w->exit_core);
        if (w->exit_valid) {
            format_wall(w->exit_wall_ms, ts, sizeof ts);
            jb_kstr(j, "exit_time", ts);
        } else {
            jb_kstr(j, "exit_time", "");
        }
        jb_kint(j, "heartbeat_age_ms", w->pid > 0 ? now - w->last_heartbeat_ms : 0);
        jb_kstr(j, "last_status", w->last_status);
        jb_kstr(j, "last_snapshot", w->last_snapshot);
        hist_json(j, "health_history", w->health_hist, w->health_hist_n);
        hist_json(j, "restart_history", w->restart_hist, w->restart_hist_n);
    }
    jb_obj_end(j);
}
