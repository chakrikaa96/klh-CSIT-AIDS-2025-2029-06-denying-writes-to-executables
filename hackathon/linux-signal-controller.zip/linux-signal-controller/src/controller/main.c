/*
 * main.c - sigctld: the controller process.
 *
 * Start-up: load config -> refuse root -> take the single-instance lock ->
 * open the log -> install signal handlers -> listen on the Unix socket.
 *
 * Main loop (single-threaded, event driven):
 *   poll() on { self-pipe, listening socket, every worker status pipe }
 *   then: handle signal flags, reap children, read worker messages,
 *         answer clients, run watchdog timers, progress shutdown.
 */
#include "controller.h"
#include "ipc.h"
#include "logger.h"
#include "signals.h"
#include "watchdog.h"

#include <errno.h>
#include <fcntl.h>
#include <libgen.h>
#include <limits.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <unistd.h>

controller_t g_ctl;

static void usage(const char *prog)
{
    fprintf(stderr,
            "usage: %s [-c config_file] [-q] [--allow-root]\n"
            "  -c FILE        configuration file (default: config/sigctl.conf)\n"
            "  -q             quiet: do not echo events to stdout\n"
            "  --allow-root   permit running as root (not recommended)\n", prog);
}

/* Create the parent directory of a path if it does not exist (one level). */
static void ensure_parent_dir(const char *path)
{
    char tmp[PATH_LEN];
    copy_str(tmp, path, sizeof tmp);
    mkdir(dirname(tmp), 0755);
}

/*
 * Single-instance guard: an exclusive, non-blocking flock() on the PID
 * file. The kernel releases the lock automatically if we die, so a PID
 * file left behind by a crash is detected as stale and reused.
 */
static int acquire_lock(const char *path)
{
    char buf[32];
    int fd = open(path, O_RDWR | O_CREAT | O_CLOEXEC, 0644);

    if (fd < 0) {
        fprintf(stderr, "sigctld: cannot open %s: %s\n", path, strerror(errno));
        return -1;
    }
    if (flock(fd, LOCK_EX | LOCK_NB) != 0) {
        ssize_t n = read(fd, buf, sizeof buf - 1);
        buf[n > 0 ? n : 0] = '\0';
        buf[strcspn(buf, "\n")] = '\0';
        fprintf(stderr, "sigctld: another controller is already running (pid %s, lock %s)\n",
                buf[0] ? buf : "?", path);
        close(fd);
        return -1;
    }
    if (ftruncate(fd, 0) == 0) {
        int n = snprintf(buf, sizeof buf, "%d\n", (int)getpid());
        if (pwrite(fd, buf, (size_t)n, 0) != n)
            fprintf(stderr, "sigctld: warning: could not write pid file\n");
    }
    return fd;
}

void controller_begin_shutdown(const char *why, const char *action)
{
    if (g_ctl.shutting_down)
        return;
    g_ctl.shutting_down = 1;
    g_ctl.shutdown_deadline_ms = now_ms() + g_ctl.cfg.stop_grace_ms + 500;
    log_event(SEV_WARN, "controller_shutdown", 0, "", getpid(), action,
              "%s: stopping %d worker(s) gracefully", why, reg_live_count());
    controller_stop_all_for_shutdown();
}

static void reload_config(void)
{
    config_t tmp;
    char err[256];

    config_defaults(&tmp);
    if (g_ctl.config_path[0] == '\0') {
        log_event(SEV_WARN, "config_reload", 0, "", 0, "SIGHUP", "no config file to reload");
        return;
    }
    if (config_load(&tmp, g_ctl.config_path, err, sizeof err) != 0) {
        log_event(SEV_ERROR, "config_reload", 0, "", 0, "SIGHUP", "%s (kept old settings)", err);
        return;
    }
    /* Only runtime-safe values are applied; paths need a restart. */
    g_ctl.cfg.watchdog_enabled      = tmp.watchdog_enabled;
    g_ctl.cfg.max_restarts          = tmp.max_restarts;
    g_ctl.cfg.backoff_base_ms       = tmp.backoff_base_ms;
    g_ctl.cfg.backoff_max_ms        = tmp.backoff_max_ms;
    g_ctl.cfg.stable_reset_s        = tmp.stable_reset_s;
    g_ctl.cfg.monitor_interval_ms   = tmp.monitor_interval_ms;
    g_ctl.cfg.heartbeat_interval_ms = tmp.heartbeat_interval_ms;
    g_ctl.cfg.status_timeout_ms     = tmp.status_timeout_ms;
    g_ctl.cfg.stop_grace_ms         = tmp.stop_grace_ms;
    log_event(SEV_OK, "config_reload", 0, "", 0, "SIGHUP", "configuration reloaded from %s",
              g_ctl.config_path);
}

static void controller_report(void)
{
    int i, running = 0, paused = 0, failed = 0, total = 0;
    for (i = 1; i <= MAX_WORKERS; i++) {
        if (!g_ctl.w[i].in_use)
            continue;
        total++;
        running += g_ctl.w[i].state == ST_RUNNING;
        paused  += g_ctl.w[i].state == ST_PAUSED;
        failed  += g_ctl.w[i].state == ST_FAILED;
    }
    log_event(SEV_INFO, "controller_report", 0, "", getpid(), "SIGUSR1",
              "%d workers: %d running, %d paused, %d failed; watchdog %s",
              total, running, paused, failed, g_ctl.cfg.watchdog_enabled ? "on" : "off");
}

static void handle_clients(void)
{
    int i;
    /* Accept a bounded batch so a flood of clients cannot starve workers. */
    for (i = 0; i < 16; i++) {
        char line[MAX_LINE], err[200];
        int cfd = ipc_accept(g_ctl.listen_fd, line, sizeof line, err, sizeof err);
        if (cfd < 0) {
            if (err[0] == '\0')
                return;                     /* no more pending connections */
            log_event(SEV_WARN, "ipc", 0, "", 0, "accept", "%s", err);
            continue;
        }
        cmd_handle(cfd, line);
    }
}

static void progress_shutdown(int64_t now)
{
    int i, live = reg_live_count();

    if (live == 0) {
        g_ctl.exit_now = 1;
        return;
    }
    if (now < g_ctl.shutdown_deadline_ms)
        return;
    if (!g_ctl.shutdown_escalated) {
        char err[160];
        g_ctl.shutdown_escalated = 1;
        g_ctl.shutdown_deadline_ms = now + 3000;
        log_event(SEV_WARN, "shutdown_escalation", 0, "", getpid(), "SIGKILL",
                  "%d worker(s) ignored SIGTERM; forcing them to stop", live);
        for (i = 1; i <= MAX_WORKERS; i++)
            if (g_ctl.w[i].in_use && g_ctl.w[i].pid > 0) {
                g_ctl.w[i].pend.escalated = 1;
                reg_signal(&g_ctl.w[i], SIGKILL, "shutdown grace period expired", err, sizeof err);
            }
        return;
    }
    log_event(SEV_ERROR, "shutdown", 0, "", getpid(), "", "%d worker(s) could not be reaped", live);
    g_ctl.exit_now = 1;
}

static void main_loop(void)
{
    struct pollfd pfd[2 + MAX_WORKERS];
    int owner[2 + MAX_WORKERS];

    while (!g_ctl.exit_now) {
        int n = 0, i, timeout;
        int64_t now = now_ms(), next;
        sig_flags_t f;

        pfd[n].fd = signals_fd();     pfd[n].events = POLLIN; owner[n++] = 0;
        pfd[n].fd = g_ctl.listen_fd;  pfd[n].events = POLLIN; owner[n++] = 0;
        for (i = 1; i <= MAX_WORKERS; i++)
            if (g_ctl.w[i].in_use && g_ctl.w[i].status_fd >= 0) {
                pfd[n].fd = g_ctl.w[i].status_fd;
                pfd[n].events = POLLIN;
                owner[n++] = i;
            }

        next = watchdog_next_deadline(now);
        if (g_ctl.shutting_down && next > now + 100)
            next = now + 100;
        timeout = (int)(next - now);
        if (timeout < 0) timeout = 0;
        if (timeout > 1000) timeout = 1000;

        if (poll(pfd, (nfds_t)n, timeout) < 0 && errno != EINTR) {
            log_event(SEV_ERROR, "poll", 0, "", 0, "", "%s", strerror(errno));
            continue;
        }

        signals_take(&f);
        if (f.term)
            controller_begin_shutdown("termination signal received", "SIGTERM");
        if (f.hup)
            reload_config();
        if (f.usr1)
            controller_report();

        /* Reap on every iteration, not only when the SIGCHLD flag is set:
         * several children exiting together may produce a single SIGCHLD
         * (standard signals do not queue), and waitpid() in a loop collects
         * all of them. The flag is only a wake-up hint. */
        reap_children();

        for (i = 2; i < n; i++)
            if (pfd[i].revents & (POLLIN | POLLHUP | POLLERR)) {
                worker_t *w = reg_get(owner[i]);
                if (w != NULL)
                    reg_read_pipe(w);
            }

        if (pfd[1].revents & POLLIN)
            handle_clients();

        watchdog_tick(now_ms());

        if (g_ctl.shutting_down)
            progress_shutdown(now_ms());
    }
}

int main(int argc, char **argv)
{
    const char *config_path = NULL;
    char err[256];
    int quiet = 0, allow_root = 0, i, log_rc;

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-c") == 0 && i + 1 < argc)
            config_path = argv[++i];
        else if (strcmp(argv[i], "-q") == 0)
            quiet = 1;
        else if (strcmp(argv[i], "--allow-root") == 0)
            allow_root = 1;
        else if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) {
            usage(argv[0]);
            return 0;
        } else {
            usage(argv[0]);
            return 2;
        }
    }

    memset(&g_ctl, 0, sizeof g_ctl);
    g_ctl.listen_fd = -1;
    g_ctl.lock_fd = -1;
    for (i = 0; i <= MAX_WORKERS; i++) {
        g_ctl.w[i].status_fd = -1;
        g_ctl.w[i].cmd_fd = -1;
        g_ctl.w[i].pend.client_fd = -1;
    }

    if (geteuid() == 0 && !allow_root) {
        fprintf(stderr, "sigctld: refusing to run as root; use a normal user account "
                        "(or --allow-root if you really must)\n");
        return 1;
    }

    config_defaults(&g_ctl.cfg);
    if (config_path == NULL && access("config/sigctl.conf", R_OK) == 0)
        config_path = "config/sigctl.conf";
    if (config_path != NULL) {
        if (config_load(&g_ctl.cfg, config_path, err, sizeof err) != 0) {
            fprintf(stderr, "sigctld: %s\n", err);
            return 1;
        }
        {
            char resolved[PATH_MAX];     /* realpath() requires PATH_MAX */
            copy_str(g_ctl.config_path,
                     realpath(config_path, resolved) ? resolved : config_path,
                     sizeof g_ctl.config_path);
        }
    }
    if (config_absolutize(&g_ctl.cfg, err, sizeof err) != 0) {
        fprintf(stderr, "sigctld: %s\n", err);
        return 1;
    }

    ensure_parent_dir(g_ctl.cfg.pid_file);
    ensure_parent_dir(g_ctl.cfg.socket_path);
    ensure_parent_dir(g_ctl.cfg.log_file);
    ensure_parent_dir(g_ctl.cfg.worker_log);

    g_ctl.lock_fd = acquire_lock(g_ctl.cfg.pid_file);
    if (g_ctl.lock_fd < 0)
        return 1;

    log_rc = logger_init(g_ctl.cfg.log_file, !quiet);
    if (log_rc != 0)
        fprintf(stderr, "sigctld: warning: %s; continuing with in-memory events only\n",
                logger_error());

    if (signals_install() != 0) {
        fprintf(stderr, "sigctld: cannot install signal handlers: %s\n", strerror(errno));
        return 1;
    }

    g_ctl.listen_fd = ipc_listen(g_ctl.cfg.socket_path, err, sizeof err);
    if (g_ctl.listen_fd < 0) {
        fprintf(stderr, "sigctld: %s\n", err);
        return 1;
    }

    g_ctl.start_ms = now_ms();
    g_ctl.start_wall_ms = wall_ms();
    snprintf(g_ctl.boot_id, sizeof g_ctl.boot_id, "%llx-%d",
             (unsigned long long)g_ctl.start_wall_ms, (int)getpid());

    log_event(SEV_OK, "controller_start", 0, "", getpid(), "start",
              "sigctld %s listening on %s (watchdog %s, max %d restarts)", SIGCTL_VERSION,
              g_ctl.cfg.socket_path, g_ctl.cfg.watchdog_enabled ? "on" : "off",
              g_ctl.cfg.max_restarts);
    if (log_rc != 0)
        log_event(SEV_ERROR, "log_file", 0, "", 0, "open", "%s", logger_error());

    main_loop();

    log_event(SEV_OK, "controller_stop", 0, "", getpid(), "exit",
              "all workers reaped; controller exiting cleanly");
    close(g_ctl.listen_fd);
    unlink(g_ctl.cfg.socket_path);
    /* Truncate rather than unlink the PID file: unlinking a lock file can
     * let two later instances lock two different inodes. The flock() is
     * what decides ownership, so an empty file left behind is harmless. */
    if (ftruncate(g_ctl.lock_fd, 0) != 0)
        fprintf(stderr, "sigctld: warning: could not clear pid file\n");
    close(g_ctl.lock_fd);
    logger_close();
    return 0;
}
