/*
 * commands.c - IPC command dispatcher and worker message handling.
 *
 * Every command that names a worker is validated first: the ID must be an
 * integer in range and refer to an in-use registry slot. Clients can never
 * pass a raw PID, so they cannot make the controller signal an arbitrary
 * process.
 */
#include "controller.h"
#include "ipc.h"
#include "logger.h"
#include "proc_info.h"

#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>

#define MAX_TOKENS 5

/* ---------------------------------------------------------------- replies */

static void reply_error(int cfd, const char *fmt, ...) __attribute__((format(printf, 2, 3)));

static void reply_error(int cfd, const char *fmt, ...)
{
    char msg[256];
    va_list ap;
    jbuf_t j;

    va_start(ap, fmt);
    vsnprintf(msg, sizeof msg, fmt, ap);
    va_end(ap);
    jb_init(&j);
    jb_obj_begin(&j);
    jb_kbool(&j, "ok", 0);
    jb_kstr(&j, "error", msg);
    jb_obj_end(&j);
    ipc_reply(cfd, jb_cstr(&j));
    jb_free(&j);
}

static void reply_worker(int cfd, const worker_t *w, const char *message)
{
    jbuf_t j;
    jb_init(&j);
    jb_obj_begin(&j);
    jb_kbool(&j, "ok", 1);
    jb_kstr(&j, "message", message);
    jb_key(&j, "worker");
    worker_json(&j, w, 0);
    jb_obj_end(&j);
    ipc_reply(cfd, jb_cstr(&j));
    jb_free(&j);
}

static void reply_ok(int cfd, const char *message)
{
    jbuf_t j;
    jb_init(&j);
    jb_obj_begin(&j);
    jb_kbool(&j, "ok", 1);
    jb_kstr(&j, "message", message);
    jb_obj_end(&j);
    ipc_reply(cfd, jb_cstr(&j));
    jb_free(&j);
}

static const char *op_name(op_t op)
{
    switch (op) {
    case OP_PAUSE:    return "pause";
    case OP_RESUME:   return "resume";
    case OP_STATUS:   return "status";
    case OP_SNAPSHOT: return "snapshot";
    case OP_STOP:     return "stop";
    case OP_RESTART:  return "restart";
    default:          return "none";
    }
}

void op_finish(worker_t *w, int ok, const char *message, const char *report)
{
    int cfd = w->pend.client_fd;

    if (cfd >= 0) {
        jbuf_t j;
        jb_init(&j);
        jb_obj_begin(&j);
        jb_kbool(&j, "ok", ok);
        jb_kstr(&j, ok ? "message" : "error", message ? message : "");
        if (report)
            jb_kstr(&j, "report", report);  /* raw worker JSON as a string */
        jb_key(&j, "worker");
        worker_json(&j, w, 0);
        jb_obj_end(&j);
        if (ipc_reply(cfd, jb_cstr(&j)) != 0)
            log_event(SEV_INFO, "ipc", w->id, w->name, w->pid, op_name(w->pend.op),
                      "client disconnected before the reply; result kept in the log");
        jb_free(&j);
    }
    memset(&w->pend, 0, sizeof w->pend);
    w->pend.client_fd = -1;
}

static void op_begin(worker_t *w, op_t op, int cfd, int timeout_ms)
{
    w->pend.op = op;
    w->pend.client_fd = cfd;
    w->pend.started_ms = now_ms();
    w->pend.deadline_ms = w->pend.started_ms + timeout_ms;
    w->pend.escalated = 0;
}

/* ------------------------------------------------------------ validation */

static worker_t *lookup(int cfd, int ntok, char **tok, const char *usage)
{
    long id;
    worker_t *w;

    if (ntok < 2) {
        reply_error(cfd, "usage: %s", usage);
        return NULL;
    }
    if (parse_long(tok[1], 1, MAX_WORKERS, &id) != 0) {
        reply_error(cfd, "invalid worker id '%s' (expected 1-%d)", tok[1], MAX_WORKERS);
        log_event(SEV_WARN, "invalid_request", 0, "", 0, tok[0], "invalid worker id '%.40s'", tok[1]);
        return NULL;
    }
    w = reg_get((int)id);
    if (w == NULL) {
        reply_error(cfd, "no worker with id %ld", id);
        log_event(SEV_WARN, "invalid_request", 0, "", 0, tok[0], "unknown worker id %ld", id);
        return NULL;
    }
    if (w->pend.op != OP_NONE) {
        reply_error(cfd, "operation '%s' is already in progress for worker %d",
                    op_name(w->pend.op), w->id);
        return NULL;
    }
    return w;
}

/* --------------------------------------------------------------- queries */

static void cmd_list(int cfd)
{
    int counts[ST_FAILED + 1] = { 0 };
    int restarts = 0, total = 0, i;
    char ts[40];
    const config_t *c = &g_ctl.cfg;
    jbuf_t j;

    for (i = 1; i <= MAX_WORKERS; i++) {
        if (!g_ctl.w[i].in_use)
            continue;
        total++;
        counts[g_ctl.w[i].state]++;
        restarts += g_ctl.w[i].restarts_total;
    }

    jb_init(&j);
    jb_obj_begin(&j);
    jb_kbool(&j, "ok", 1);
    jb_key(&j, "controller");
    jb_obj_begin(&j);
    jb_kint(&j, "pid", getpid());
    jb_kstr(&j, "version", SIGCTL_VERSION);
    jb_kstr(&j, "boot_id", g_ctl.boot_id);
    jb_kint(&j, "uptime_ms", now_ms() - g_ctl.start_ms);
    format_wall(g_ctl.start_wall_ms, ts, sizeof ts);
    jb_kstr(&j, "started", ts);
    jb_kbool(&j, "watchdog", c->watchdog_enabled);
    jb_kbool(&j, "shutting_down", g_ctl.shutting_down);
    jb_kint(&j, "total", total);
    jb_kint(&j, "starting", counts[ST_STARTING]);
    jb_kint(&j, "running", counts[ST_RUNNING]);
    jb_kint(&j, "paused", counts[ST_PAUSED]);
    jb_kint(&j, "stopping", counts[ST_STOPPING]);
    jb_kint(&j, "stopped", counts[ST_STOPPED] + counts[ST_COMPLETED]);
    jb_kint(&j, "backoff", counts[ST_BACKOFF]);
    jb_kint(&j, "failed", counts[ST_FAILED]);
    jb_kint(&j, "restarts", restarts);
    jb_kint(&j, "last_seq", (long long)logger_last_seq());
    jb_kstr(&j, "log_file", logger_path());
    jb_kbool(&j, "log_ok", logger_file_ok());
    jb_kstr(&j, "log_error", logger_error());
    jb_kstr(&j, "socket", c->socket_path);
    jb_kint(&j, "max_workers", MAX_WORKERS);
    jb_obj_end(&j);
    jb_key(&j, "workers");
    jb_arr_begin(&j);
    for (i = 1; i <= MAX_WORKERS; i++)
        if (g_ctl.w[i].in_use)
            worker_json(&j, &g_ctl.w[i], 0);
    jb_arr_end(&j);
    jb_obj_end(&j);
    ipc_reply(cfd, jb_cstr(&j));
    jb_free(&j);
}

static void cmd_info(int cfd, int ntok, char **tok)
{
    long id;
    worker_t *w;
    proc_info_t pi;
    jbuf_t j;

    if (ntok < 2 || parse_long(tok[1], 1, MAX_WORKERS, &id) != 0) {
        reply_error(cfd, "usage: INFO <id> (1-%d)", MAX_WORKERS);
        return;
    }
    w = reg_get((int)id);
    if (w == NULL) {
        reply_error(cfd, "no worker with id %ld", id);
        return;
    }
    jb_init(&j);
    jb_obj_begin(&j);
    jb_kbool(&j, "ok", 1);
    jb_key(&j, "worker");
    worker_json(&j, w, 1);
    jb_key(&j, "proc");
    if (w->pid > 0 && proc_read(w->pid, &pi) == 0) {
        char st[2] = { pi.state, '\0' };
        jb_obj_begin(&j);
        jb_kstr(&j, "state", st);
        jb_kstr(&j, "state_name", proc_state_name(pi.state));
        jb_kint(&j, "ppid", pi.ppid);
        jb_kint(&j, "pgid", pi.pgid);
        jb_kbool(&j, "owned", pi.ppid == getpid());
        jb_kint(&j, "threads", pi.threads);
        jb_kint(&j, "rss_kb", pi.rss_kb);
        jb_kdouble(&j, "cpu_seconds", (double)pi.cpu_ticks / (double)proc_clk_tck());
        jb_kint(&j, "voluntary_ctxt_switches", pi.vol_ctxt);
        jb_kint(&j, "nonvoluntary_ctxt_switches", pi.invol_ctxt);
        jb_obj_end(&j);
    } else {
        jb_null(&j);
    }
    jb_key(&j, "events");
    logger_events_json(&j, 0, 40, w->id);
    jb_obj_end(&j);
    ipc_reply(cfd, jb_cstr(&j));
    jb_free(&j);
}

static void cmd_events(int cfd, int ntok, char **tok)
{
    long since = 0, limit = 300;
    jbuf_t j;

    if (ntok >= 2 && parse_long(tok[1], 0, 0x7fffffffL, &since) != 0) {
        reply_error(cfd, "usage: EVENTS [since_seq] [limit]");
        return;
    }
    if (ntok >= 3 && parse_long(tok[2], 1, 2000, &limit) != 0) {
        reply_error(cfd, "limit must be 1-2000");
        return;
    }
    jb_init(&j);
    jb_obj_begin(&j);
    jb_kbool(&j, "ok", 1);
    jb_kstr(&j, "boot_id", g_ctl.boot_id);
    jb_kint(&j, "last_seq", (long long)logger_last_seq());
    jb_key(&j, "events");
    logger_events_json(&j, (uint64_t)since, (int)limit, 0);
    jb_obj_end(&j);
    ipc_reply(cfd, jb_cstr(&j));
    jb_free(&j);
}

static void config_json(jbuf_t *j, const config_t *c)
{
    jb_obj_begin(j);
    jb_kbool(j, "watchdog", c->watchdog_enabled);
    jb_kint(j, "max_restarts", c->max_restarts);
    jb_kint(j, "backoff_base_ms", c->backoff_base_ms);
    jb_kint(j, "backoff_max_ms", c->backoff_max_ms);
    jb_kint(j, "stable_reset_s", c->stable_reset_s);
    jb_kint(j, "monitor_interval_ms", c->monitor_interval_ms);
    jb_kint(j, "heartbeat_interval_ms", c->heartbeat_interval_ms);
    jb_kint(j, "status_timeout_ms", c->status_timeout_ms);
    jb_kint(j, "stop_grace_ms", c->stop_grace_ms);
    jb_kstr(j, "log_file", c->log_file);
    jb_kstr(j, "socket_path", c->socket_path);
    jb_kstr(j, "worker_path", c->worker_path);
    jb_kstr(j, "config_file", g_ctl.config_path);
    jb_obj_end(j);
}

static void cmd_config(int cfd, int ntok, char **tok)
{
    char err[200];
    jbuf_t j;

    if (ntok >= 2 && strcasecmp(tok[1], "SET") == 0) {
        if (ntok < 4) {
            reply_error(cfd, "usage: CONFIG SET <key> <value>");
            return;
        }
        if (strcmp(tok[2], "log_file") == 0) {
            config_t tmp = g_ctl.cfg;
            if (config_set(&tmp, tok[2], tok[3], 1, err, sizeof err) != 0 ||
                config_absolutize(&tmp, err, sizeof err) != 0 ||
                logger_reopen(tmp.log_file, err, sizeof err) != 0) {
                reply_error(cfd, "%s", err);
                return;
            }
            g_ctl.cfg = tmp;
        } else if (config_set(&g_ctl.cfg, tok[2], tok[3], 1, err, sizeof err) != 0) {
            reply_error(cfd, "%s", err);
            return;
        }
        log_event(SEV_INFO, "config_changed", 0, "", 0, "CONFIG", "%s = %s", tok[2], tok[3]);
    } else if (ntok >= 2 && strcasecmp(tok[1], "SAVE") == 0) {
        if (g_ctl.config_path[0] == '\0') {
            reply_error(cfd, "controller was started without a config file");
            return;
        }
        if (config_save(&g_ctl.cfg, g_ctl.config_path, err, sizeof err) != 0) {
            reply_error(cfd, "%s", err);
            return;
        }
        log_event(SEV_OK, "config_saved", 0, "", 0, "CONFIG", "saved to %s", g_ctl.config_path);
    } else if (ntok >= 2 && strcasecmp(tok[1], "GET") != 0) {
        reply_error(cfd, "usage: CONFIG [GET | SET <key> <value> | SAVE]");
        return;
    }
    jb_init(&j);
    jb_obj_begin(&j);
    jb_kbool(&j, "ok", 1);
    jb_key(&j, "config");
    config_json(&j, &g_ctl.cfg);
    jb_obj_end(&j);
    ipc_reply(cfd, jb_cstr(&j));
    jb_free(&j);
}

/* ------------------------------------------------------------ mutations */

static void cmd_spawn(int cfd, int ntok, char **tok)
{
    const profile_t *p;
    worker_t *w;
    char err[200];

    if (ntok < 2) {
        reply_error(cfd, "usage: SPAWN <profile> [name]");
        return;
    }
    p = profile_find(tok[1]);
    if (p == NULL) {
        reply_error(cfd, "unknown profile '%s' (see PROFILES)", tok[1]);
        return;
    }
    w = reg_alloc(p, ntok >= 3 ? tok[2] : NULL, err, sizeof err);
    if (w == NULL) {
        reply_error(cfd, "%s", err);
        return;
    }
    if (reg_spawn(w, err, sizeof err) != 0) {
        log_event(SEV_ERROR, "start_failure", w->id, w->name, 0, "fork/exec", "%s", err);
        reg_free(w);
        reply_error(cfd, "cannot start worker: %s", err);
        return;
    }
    reply_worker(cfd, w, "worker started");
}

static void cmd_pause(int cfd, worker_t *w)
{
    char err[200];
    if (w->state != ST_RUNNING) {
        reply_error(cfd, "worker %d is %s; only a running worker can be paused",
                    w->id, state_name(w->state));
        return;
    }
    /* SIGSTOP cannot be caught, blocked or ignored: the kernel stops the
     * process directly. We still wait for waitpid() to confirm it. */
    if (reg_signal(w, SIGSTOP, "pause requested", err, sizeof err) != 0) {
        reply_error(cfd, "%s", err);
        return;
    }
    op_begin(w, OP_PAUSE, cfd, 1500);
}

static void cmd_resume(int cfd, worker_t *w)
{
    char err[200];
    if (w->state != ST_PAUSED) {
        reply_error(cfd, "worker %d is %s; only a paused worker can be resumed",
                    w->id, state_name(w->state));
        return;
    }
    if (reg_signal(w, SIGCONT, "resume requested", err, sizeof err) != 0) {
        reply_error(cfd, "%s", err);
        return;
    }
    op_begin(w, OP_RESUME, cfd, 1500);
}

static void cmd_probe(int cfd, worker_t *w, int snapshot)
{
    int sig = snapshot ? SIGUSR2 : SIGUSR1;
    char err[200];

    if (w->state == ST_PAUSED) {
        reply_error(cfd, "worker %d is paused: a %s sent now would stay pending until "
                    "SIGCONT, so resume it first", w->id, snapshot ? "SIGUSR2" : "SIGUSR1");
        return;
    }
    if (w->state != ST_RUNNING) {
        reply_error(cfd, "worker %d is %s; it must be running", w->id, state_name(w->state));
        return;
    }
    if (reg_signal(w, sig, snapshot ? "diagnostic snapshot requested"
                                    : "status report requested", err, sizeof err) != 0) {
        reply_error(cfd, "%s", err);
        return;
    }
    op_begin(w, snapshot ? OP_SNAPSHOT : OP_STATUS, cfd, g_ctl.cfg.status_timeout_ms);
}

/* Shared by STOP, RESTART, STOPALL and shutdown. cfd may be -1. */
static int begin_stop(worker_t *w, op_t op, int cfd, char *err, size_t n)
{
    int was_paused = (w->state == ST_PAUSED);

    w->stop_requested = 1;
    if (reg_signal(w, SIGTERM, op == OP_RESTART ? "restart requested (graceful stop first)"
                                                : "graceful stop requested", err, n) != 0) {
        w->stop_requested = 0;
        return -1;
    }
    /* A stopped process cannot run its SIGTERM handling until continued. */
    if (was_paused) {
        char e2[160];
        reg_signal(w, SIGCONT, "resume so the pending SIGTERM can be handled", e2, sizeof e2);
    }
    w->state = ST_STOPPING;
    w->restart_after_stop = (op == OP_RESTART);
    op_begin(w, op, cfd, g_ctl.cfg.stop_grace_ms);
    return 0;
}

static void cmd_stop(int cfd, worker_t *w)
{
    char err[200];

    switch (w->state) {
    case ST_STARTING:
    case ST_RUNNING:
    case ST_PAUSED:
        if (begin_stop(w, OP_STOP, cfd, err, sizeof err) != 0)
            reply_error(cfd, "%s", err);
        return;
    case ST_BACKOFF:
        w->state = ST_STOPPED;
        w->fail_reason[0] = '\0';
        log_event(SEV_INFO, "recovery_cancelled", w->id, w->name, 0, "stop",
                  "pending restart cancelled by stop request");
        reply_worker(cfd, w, "pending restart cancelled");
        return;
    default:
        reply_error(cfd, "worker %d is %s, not running", w->id, state_name(w->state));
        return;
    }
}

static void cmd_restart(int cfd, worker_t *w)
{
    char err[200];

    if (g_ctl.shutting_down) {
        reply_error(cfd, "controller is shutting down");
        return;
    }
    switch (w->state) {
    case ST_STARTING:
    case ST_RUNNING:
    case ST_PAUSED:
        if (begin_stop(w, OP_RESTART, cfd, err, sizeof err) != 0)
            reply_error(cfd, "%s", err);
        return;
    case ST_STOPPING:
        reply_error(cfd, "worker %d is already stopping", w->id);
        return;
    default:
        /* Not running (stopped, completed, failed or in backoff). A manual
         * restart is an operator decision, so the failure count resets. */
        w->consecutive_failures = 0;
        if (reg_spawn(w, err, sizeof err) != 0) {
            w->state = ST_FAILED;
            snprintf(w->fail_reason, sizeof w->fail_reason, "restart failed");
            reply_error(cfd, "cannot start worker: %s", err);
            return;
        }
        w->restarts_total++;
        reg_hist_add(w->restart_hist, &w->restart_hist_n, "manual restart -> new pid %d",
                     (int)w->pid);
        log_event(SEV_OK, "worker_restart", w->id, w->name, w->pid, "restart",
                  "manual restart (failure counter reset)");
        reply_worker(cfd, w, "worker restarted");
    }
}

static void cmd_fault(int cfd, worker_t *w, int ntok, char **tok)
{
    char err[200], cmd[32];

    if (ntok < 3 || (strcmp(tok[2], "crash") && strcmp(tok[2], "hang") &&
                     strcmp(tok[2], "segv") && strcmp(tok[2], "exit"))) {
        reply_error(cfd, "usage: FAULT <id> crash|segv|hang|exit [code]");
        return;
    }
    if (w->state != ST_RUNNING) {
        reply_error(cfd, "worker %d is %s; faults can only be injected into a running worker",
                    w->id, state_name(w->state));
        return;
    }
    if (strcmp(tok[2], "exit") == 0) {
        long code = 3;
        if (ntok >= 4 && parse_long(tok[3], 0, 255, &code) != 0) {
            reply_error(cfd, "exit code must be 0-255");
            return;
        }
        snprintf(cmd, sizeof cmd, "exit %ld", code);
    } else {
        copy_str(cmd, tok[2], sizeof cmd);
    }
    if (reg_send_cmd(w, cmd, err, sizeof err) != 0) {
        reply_error(cfd, "%s", err);
        return;
    }
    log_event(SEV_WARN, "fault_requested", w->id, w->name, w->pid, "inject", "test fault '%s'", cmd);
    reply_worker(cfd, w, "fault injected; watch the event feed");
}

static void cmd_remove(int cfd, worker_t *w)
{
    char name[NAME_LEN];
    int id = w->id;

    if (w->pid > 0) {
        reply_error(cfd, "worker %d is still running; stop it first", w->id);
        return;
    }
    copy_str(name, w->name, sizeof name);
    reg_free(w);
    log_event(SEV_INFO, "worker_removed", id, name, 0, "remove", "removed from the registry");
    reply_ok(cfd, "worker removed");
}

static int stop_all(const char *why)
{
    char err[200];
    int i, n = 0;

    for (i = 1; i <= MAX_WORKERS; i++) {
        worker_t *w = &g_ctl.w[i];
        if (!w->in_use)
            continue;
        if (w->state == ST_BACKOFF) {
            w->state = ST_STOPPED;
            log_event(SEV_INFO, "recovery_cancelled", w->id, w->name, 0, "stop",
                      "pending restart cancelled (%s)", why);
            continue;
        }
        if (w->pid <= 0 || w->state == ST_STOPPING)
            continue;
        if (w->pend.op != OP_NONE)
            op_finish(w, 0, "superseded by stop-all", NULL);
        if (begin_stop(w, OP_STOP, -1, err, sizeof err) == 0)
            n++;
    }
    return n;
}

void controller_stop_all_for_shutdown(void)
{
    stop_all("controller shutdown");
}

static void cmd_stopall(int cfd)
{
    char msg[96];
    int n = stop_all("stop all");
    log_event(SEV_INFO, "stop_all", 0, "", 0, "SIGTERM", "graceful stop sent to %d workers", n);
    snprintf(msg, sizeof msg, "graceful stop requested for %d worker(s)", n);
    reply_ok(cfd, msg);
}

static void cmd_watchdog(int cfd, int ntok, char **tok)
{
    if (ntok < 2 || (strcasecmp(tok[1], "on") && strcasecmp(tok[1], "off"))) {
        reply_error(cfd, "usage: WATCHDOG on|off");
        return;
    }
    g_ctl.cfg.watchdog_enabled = strcasecmp(tok[1], "on") == 0;
    log_event(SEV_INFO, "watchdog", 0, "", 0, "WATCHDOG", "automatic recovery %s",
              g_ctl.cfg.watchdog_enabled ? "enabled" : "disabled");
    reply_ok(cfd, g_ctl.cfg.watchdog_enabled ? "watchdog enabled" : "watchdog disabled");
}

/* ------------------------------------------------------- worker messages */

void cmd_worker_message(worker_t *w, const char *line)
{
    char type[24] = "", text[96];
    long long v;
    int64_t now = now_ms();

    if (json_get_str(line, "type", type, sizeof type) != 0) {
        log_event(SEV_WARN, "protocol", w->id, w->name, w->pid, "", "malformed worker message");
        return;
    }
    if (json_get_ll(line, "progress", &v) == 0)
        w->progress = v;
    if (json_get_str(line, "detail", text, sizeof text) == 0)
        copy_str(w->task, text, sizeof w->task);

    if (strcmp(type, "hb") == 0) {
        w->last_heartbeat_ms = now;
    } else if (strcmp(type, "hello") == 0) {
        w->last_heartbeat_ms = now;
        if (w->state == ST_STARTING) {
            w->state = ST_RUNNING;
            w->health = H_OK;
            reg_hist_add(w->health_hist, &w->health_hist_n, "started (hello received)");
            log_event(SEV_OK, "worker_ready", w->id, w->name, w->pid, "hello",
                      "worker confirmed it is running (%lld ms after fork)",
                      (long long)(now - w->started_ms));
        }
    } else if (strcmp(type, "status") == 0 || strcmp(type, "snapshot") == 0) {
        int snap = type[1] == 'n';
        op_t want = snap ? OP_SNAPSHOT : OP_STATUS;
        w->last_heartbeat_ms = now;
        if (snap) {
            copy_str(w->last_snapshot, line, sizeof w->last_snapshot);
            w->last_snapshot_wall_ms = wall_ms();
        } else {
            copy_str(w->last_status, line, sizeof w->last_status);
            w->last_status_wall_ms = wall_ms();
        }
        if (w->pend.op == want) {
            long long ms = (long long)(now - w->pend.started_ms);
            char msg[96];
            reg_hist_add(w->health_hist, &w->health_hist_n, "%s answered in %lld ms",
                         snap ? "SIGUSR2" : "SIGUSR1", ms);
            log_event(SEV_OK, snap ? "snapshot" : "status_report", w->id, w->name, w->pid,
                      snap ? "SIGUSR2" : "SIGUSR1", "reply received in %lld ms over the pipe", ms);
            snprintf(msg, sizeof msg, "%s received in %lld ms", snap ? "snapshot" : "status report", ms);
            if (w->health == H_UNRESPONSIVE || w->health == H_LATE)
                w->health = H_OK;
            op_finish(w, 1, msg, line);
        } else {
            reg_hist_add(w->health_hist, &w->health_hist_n, "late %s reply arrived",
                         snap ? "SIGUSR2" : "SIGUSR1");
            log_event(SEV_INFO, snap ? "snapshot" : "status_report", w->id, w->name, w->pid,
                      snap ? "SIGUSR2" : "SIGUSR1",
                      "late reply arrived after the timeout: worker was slow, not dead");
        }
    } else if (strcmp(type, "bye") == 0) {
        char reason[48] = "";
        json_get_str(line, "reason", reason, sizeof reason);
        log_event(SEV_INFO, "worker_bye", w->id, w->name, w->pid, reason,
                  "worker handled the request and is exiting cleanly");
    } else if (strcmp(type, "fault") == 0) {
        char kind[32] = "";
        json_get_str(line, "kind", kind, sizeof kind);
        log_event(SEV_WARN, "fault", w->id, w->name, w->pid, kind,
                  "worker is about to simulate a failure (%s)", kind);
    } else if (strcmp(type, "exec_error") == 0) {
        log_event(SEV_ERROR, "exec_failed", w->id, w->name, w->pid, "execv",
                  "child could not execute the worker program");
    } else {
        log_event(SEV_WARN, "protocol", w->id, w->name, w->pid, "",
                  "unknown worker message type '%s'", type);
    }
}

/* -------------------------------------------------------------- dispatch */

static int tokenize(char *line, char **tok, int max)
{
    int n = 0;
    char *save = NULL, *t = strtok_r(line, " \t", &save);
    while (t != NULL && n < max) {
        tok[n++] = t;
        t = strtok_r(NULL, " \t", &save);
    }
    return n;
}

void cmd_handle(int cfd, char *line)
{
    char *tok[MAX_TOKENS];
    int ntok = tokenize(line, tok, MAX_TOKENS);
    const char *c;
    worker_t *w;

    if (ntok == 0) {
        reply_error(cfd, "empty request");
        return;
    }
    c = tok[0];

    /* Read-only queries are always allowed. */
    if (!strcasecmp(c, "PING")) {
        char msg[64];
        snprintf(msg, sizeof msg, "pong from sigctld %s (pid %d)", SIGCTL_VERSION, (int)getpid());
        reply_ok(cfd, msg);
        return;
    }
    if (!strcasecmp(c, "LIST"))     { cmd_list(cfd);               return; }
    if (!strcasecmp(c, "INFO"))     { cmd_info(cfd, ntok, tok);    return; }
    if (!strcasecmp(c, "EVENTS"))   { cmd_events(cfd, ntok, tok);  return; }
    if (!strcasecmp(c, "PROFILES")) {
        jbuf_t j;
        jb_init(&j);
        jb_obj_begin(&j);
        jb_kbool(&j, "ok", 1);
        jb_key(&j, "profiles");
        profiles_json(&j);
        jb_obj_end(&j);
        ipc_reply(cfd, jb_cstr(&j));
        jb_free(&j);
        return;
    }
    if (!strcasecmp(c, "CONFIG") && (ntok == 1 || !strcasecmp(tok[1], "GET"))) {
        cmd_config(cfd, ntok, tok);
        return;
    }

    if (g_ctl.shutting_down) {
        reply_error(cfd, "controller is shutting down");
        return;
    }

    if (!strcasecmp(c, "SPAWN"))    { cmd_spawn(cfd, ntok, tok);    return; }
    if (!strcasecmp(c, "STOPALL"))  { cmd_stopall(cfd);             return; }
    if (!strcasecmp(c, "WATCHDOG")) { cmd_watchdog(cfd, ntok, tok); return; }
    if (!strcasecmp(c, "CONFIG"))   { cmd_config(cfd, ntok, tok);   return; }
    if (!strcasecmp(c, "SHUTDOWN")) {
        reply_ok(cfd, "controller is shutting down; workers will be stopped gracefully");
        controller_begin_shutdown("SHUTDOWN command received over IPC", "SHUTDOWN");
        return;
    }

    if (!strcasecmp(c, "PAUSE")) {
        if ((w = lookup(cfd, ntok, tok, "PAUSE <id>")) != NULL) cmd_pause(cfd, w);
    } else if (!strcasecmp(c, "RESUME")) {
        if ((w = lookup(cfd, ntok, tok, "RESUME <id>")) != NULL) cmd_resume(cfd, w);
    } else if (!strcasecmp(c, "STATUS")) {
        if ((w = lookup(cfd, ntok, tok, "STATUS <id>")) != NULL) cmd_probe(cfd, w, 0);
    } else if (!strcasecmp(c, "SNAPSHOT")) {
        if ((w = lookup(cfd, ntok, tok, "SNAPSHOT <id>")) != NULL) cmd_probe(cfd, w, 1);
    } else if (!strcasecmp(c, "STOP")) {
        if ((w = lookup(cfd, ntok, tok, "STOP <id>")) != NULL) cmd_stop(cfd, w);
    } else if (!strcasecmp(c, "RESTART")) {
        if ((w = lookup(cfd, ntok, tok, "RESTART <id>")) != NULL) cmd_restart(cfd, w);
    } else if (!strcasecmp(c, "FAULT")) {
        if ((w = lookup(cfd, ntok, tok, "FAULT <id> crash|segv|hang|exit [code]")) != NULL)
            cmd_fault(cfd, w, ntok, tok);
    } else if (!strcasecmp(c, "REMOVE")) {
        if ((w = lookup(cfd, ntok, tok, "REMOVE <id>")) != NULL) cmd_remove(cfd, w);
    } else {
        reply_error(cfd, "unknown command '%.32s'", c);
    }
}
