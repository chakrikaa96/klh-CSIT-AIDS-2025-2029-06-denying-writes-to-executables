/*
 * signals.c - Async-signal-safe handlers plus the self-pipe wake-up.
 *
 * Inside a handler we only touch volatile sig_atomic_t variables and call
 * write(2), both of which POSIX lists as async-signal-safe. errno is saved
 * and restored so the interrupted code never sees a changed errno.
 */
#include "signals.h"

#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>

static volatile sig_atomic_t g_chld, g_term, g_hup, g_usr1;
static int g_pipe[2] = { -1, -1 };

static void on_signal(int sig)
{
    int saved = errno;

    switch (sig) {
    case SIGCHLD: g_chld = 1; break;
    case SIGHUP:  g_hup  = 1; break;
    case SIGUSR1: g_usr1 = 1; break;
    default:      g_term = 1; break;   /* SIGTERM, SIGINT */
    }
    /* Wake the poll() loop. If the pipe is full a wake-up is already
     * pending, so EAGAIN is harmless and deliberately ignored. */
    if (g_pipe[1] >= 0) {
        ssize_t r = write(g_pipe[1], "x", 1);
        (void)r;
    }
    errno = saved;
}

int signals_install(void)
{
    static const int sigs[] = { SIGCHLD, SIGTERM, SIGINT, SIGHUP, SIGUSR1 };
    struct sigaction sa;
    size_t i;

    if (pipe2(g_pipe, O_NONBLOCK | O_CLOEXEC) != 0)
        return -1;

    memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_signal;
    sigfillset(&sa.sa_mask);         /* no nested handlers                   */
    /* SA_RESTART: most interrupted syscalls resume automatically. We do
     * NOT set SA_NOCLDSTOP because we want SIGCHLD for stop/continue too. */
    sa.sa_flags = SA_RESTART;
    for (i = 0; i < sizeof sigs / sizeof sigs[0]; i++)
        if (sigaction(sigs[i], &sa, NULL) != 0)
            return -1;

    /* A write to a disconnected GUI socket must return EPIPE, not kill us. */
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = SIG_IGN;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGPIPE, &sa, NULL) != 0)
        return -1;
    return 0;
}

int signals_fd(void) { return g_pipe[0]; }

void signals_take(sig_flags_t *out)
{
    char buf[64];
    sigset_t all, old;

    while (read(g_pipe[0], buf, sizeof buf) > 0)
        ;

    /* Block signals while copying and clearing so no flag is lost between
     * the read and the reset. */
    sigfillset(&all);
    sigprocmask(SIG_BLOCK, &all, &old);
    out->chld = g_chld; g_chld = 0;
    out->term = g_term; g_term = 0;
    out->hup  = g_hup;  g_hup  = 0;
    out->usr1 = g_usr1; g_usr1 = 0;
    sigprocmask(SIG_SETMASK, &old, NULL);
}

void signals_block_all(sigset_t *old)
{
    sigset_t all;
    sigfillset(&all);
    sigprocmask(SIG_BLOCK, &all, old);
}

void signals_restore(const sigset_t *old)
{
    sigprocmask(SIG_SETMASK, old, NULL);
}

void signals_reset_in_child(const sigset_t *old)
{
    static const int sigs[] = { SIGCHLD, SIGTERM, SIGINT, SIGHUP, SIGUSR1, SIGPIPE };
    struct sigaction sa;
    size_t i;

    memset(&sa, 0, sizeof sa);
    sa.sa_handler = SIG_DFL;
    sigemptyset(&sa.sa_mask);
    for (i = 0; i < sizeof sigs / sizeof sigs[0]; i++)
        sigaction(sigs[i], &sa, NULL);
    sigprocmask(SIG_SETMASK, old, NULL);
}
