#!/usr/bin/env python3
"""
Integration tests for the Linux Signal-Based Process Controller.

Each test starts a REAL sigctld controller (in an isolated temporary
directory), drives it through its Unix domain socket exactly as the GUI
does, and verifies the results independently through /proc and the
persistent event log. No signal or process is simulated.

Run from the project root (as a normal user, not root):
    make integration         or         python3 tests/integration_test.py [-k name]
"""
import json
import os
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import traceback

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUILD = os.path.join(ROOT, "build")
SIGCTLD = os.path.join(BUILD, "sigctld")
WORKER = os.path.join(BUILD, "sigworker")


class TestFailure(Exception):
    pass


def check(cond, msg):
    if not cond:
        raise TestFailure(msg)


def proc_stat(pid):
    """Return (state, ppid, pgid) from /proc/<pid>/stat or None."""
    try:
        with open(f"/proc/{pid}/stat") as f:
            data = f.read()
    except OSError:
        return None
    rest = data[data.rindex(")") + 2:].split()
    return rest[0], int(rest[1]), int(rest[2])


def children_of(ppid):
    """All processes whose parent is ppid, as {pid: state}."""
    out = {}
    for name in os.listdir("/proc"):
        if name.isdigit():
            st = proc_stat(int(name))
            if st and st[1] == ppid:
                out[int(name)] = st[0]
    return out


def pid_alive(pid):
    st = proc_stat(pid)
    return st is not None and st[0] != "Z"


class Controller:
    """A sigctld instance in its own temporary directory."""

    def __init__(self, **overrides):
        self.dir = tempfile.mkdtemp(prefix="sigctl-test-")
        self.sock = os.path.join(self.dir, "sigctl.sock")
        self.log = os.path.join(self.dir, "events.jsonl")
        self.out = os.path.join(self.dir, "controller.out")
        settings = {
            "watchdog": "on",
            "max_restarts": 3,
            "backoff_base_ms": 200,
            "backoff_max_ms": 1000,
            "stable_reset_s": 30,
            "monitor_interval_ms": 200,
            "heartbeat_interval_ms": 300,
            "status_timeout_ms": 1000,
            "stop_grace_ms": 1500,
            "log_file": self.log,
            "socket_path": self.sock,
            "pid_file": os.path.join(self.dir, "sigctld.pid"),
            "worker_path": WORKER,
            "worker_log": os.path.join(self.dir, "workers.log"),
        }
        settings.update(overrides)
        self.config = os.path.join(self.dir, "test.conf")
        with open(self.config, "w") as f:
            for k, v in settings.items():
                f.write(f"{k} = {v}\n")
        self.proc = None

    def start(self, expect_ok=True):
        self.proc = subprocess.Popen([SIGCTLD, "-c", self.config], cwd=ROOT,
                                     stdout=open(self.out, "a"), stderr=subprocess.STDOUT)
        if expect_ok:
            deadline = time.time() + 5
            while time.time() < deadline:
                if os.path.exists(self.sock):
                    try:
                        if self.req("PING")["ok"]:
                            return self
                    except OSError:
                        pass
                if self.proc.poll() is not None:
                    raise TestFailure("controller exited during start-up:\n" + self.output())
                time.sleep(0.05)
            raise TestFailure("controller did not start")
        return self

    @property
    def pid(self):
        return self.proc.pid

    def output(self):
        try:
            with open(self.out) as f:
                return f.read()
        except OSError:
            return ""

    def req(self, line, timeout=10.0):
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect(self.sock)
        s.sendall((line + "\n").encode())
        data = b""
        while True:
            chunk = s.recv(65536)
            if not chunk:
                break
            data += chunk
        s.close()
        return json.loads(data.decode())

    def workers(self):
        return {w["id"]: w for w in self.req("LIST")["workers"]}

    def worker(self, wid):
        return self.workers()[wid]

    def spawn(self, profile, name=None):
        r = self.req(f"SPAWN {profile}" + (f" {name}" if name else ""))
        check(r["ok"], f"SPAWN {profile} failed: {r}")
        return r["worker"]["id"]

    def wait_for(self, pred, timeout=8.0, what="condition"):
        deadline = time.time() + timeout
        last = None
        while time.time() < deadline:
            last = pred()
            if last:
                return last
            time.sleep(0.05)
        raise TestFailure(f"timed out waiting for {what}")

    def wait_state(self, wid, state, timeout=8.0):
        return self.wait_for(lambda: self.worker(wid)["state"] == state, timeout,
                             f"worker {wid} to become {state}")

    def events(self):
        return self.req("EVENTS 0 2000")["events"]

    def has_event(self, etype, wid=None):
        return any(e["type"] == etype and (wid is None or e["worker_id"] == wid)
                   for e in self.events())

    def log_lines(self):
        with open(self.log) as f:
            return [json.loads(l) for l in f if l.strip()]

    def stop(self):
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.send_signal(signal.SIGTERM)
                self.proc.wait(timeout=10)
            except Exception:
                self.proc.kill()
                self.proc.wait()

    def cleanup(self):
        self.stop()
        shutil.rmtree(self.dir, ignore_errors=True)


# ----------------------------------------------------------------- tests

def test_01_create_multiple_workers(c):
    """fork()+exec() three workers; verify each is a real child process."""
    ids = [c.spawn("primes"), c.spawn("hasher"), c.spawn("sorter")]
    for wid in ids:
        c.wait_state(wid, "running")
    ws = c.workers()
    pids = [ws[i]["pid"] for i in ids]
    check(len(set(pids)) == 3, "PIDs must be distinct")
    for pid in pids:
        st = proc_stat(pid)
        check(st is not None, f"/proc/{pid} must exist")
        check(st[1] == c.pid, f"worker {pid} parent must be the controller ({st[1]} != {c.pid})")
        check(st[2] == pid, f"worker {pid} must lead its own process group (pgid {st[2]})")
    return f"3 workers, pids {pids}, ppid {c.pid}, each its own process group"


def test_02_sigusr1_status(c):
    """SIGUSR1 produces a status report delivered over the pipe."""
    wid = c.spawn("primes")
    c.wait_state(wid, "running")
    r1 = c.req(f"STATUS {wid}")
    check(r1["ok"], f"STATUS failed: {r1}")
    rep = json.loads(r1["report"])
    check(rep["type"] == "status", "report type")
    check(rep["sender_pid"] == c.pid, "siginfo si_pid must identify the controller")
    check(rep["pid"] == c.worker(wid)["pid"], "report pid")
    r2 = json.loads(c.req(f"STATUS {wid}")["report"])
    check(r2["usr1_received"] == rep["usr1_received"] + 1, "SIGUSR1 counter must advance")
    check(r2["progress"] >= rep["progress"], "progress must not go backwards")
    return f"report received, sender_pid={rep['sender_pid']}, usr1 count {r2['usr1_received']}"


def test_03_sigusr2_snapshot(c):
    """SIGUSR2 produces a diagnostic snapshot; the signal mask proves blocking."""
    wid = c.spawn("hasher")
    c.wait_state(wid, "running")
    r = c.req(f"SNAPSHOT {wid}")
    check(r["ok"], f"SNAPSHOT failed: {r}")
    snap = json.loads(r["report"])
    check(snap["type"] == "snapshot", "snapshot type")
    mask = int(snap["sig_blocked_mask"], 16)
    for sig in (signal.SIGUSR1, signal.SIGUSR2, signal.SIGTERM):
        check(mask & (1 << (sig - 1)), f"{sig.name} must be blocked in the worker (SigBlk)")
    check(snap["vm_rss_kb"] > 0, "rss reported")
    return f"SigBlk={snap['sig_blocked_mask']} (USR1, USR2, TERM blocked), rss {snap['vm_rss_kb']} kB"


def test_04_pause_resume(c):
    """SIGSTOP/SIGCONT, confirmed independently through /proc."""
    wid = c.spawn("primes")
    c.wait_state(wid, "running")
    pid = c.worker(wid)["pid"]
    r = c.req(f"PAUSE {wid}")
    check(r["ok"] and r["worker"]["state"] == "paused", f"PAUSE: {r}")
    check(proc_stat(pid)[0] == "T", "kernel must report the process as stopped (T)")
    p1 = c.worker(wid)["progress"]
    time.sleep(0.8)
    check(c.worker(wid)["progress"] == p1, "no progress while paused")
    r = c.req(f"STATUS {wid}")
    check(not r["ok"] and "paused" in r["error"], "status on a paused worker is refused")
    r = c.req(f"RESUME {wid}")
    check(r["ok"] and r["worker"]["state"] == "running", f"RESUME: {r}")
    check(proc_stat(pid)[0] in "RS", "process must be runnable again")
    c.wait_for(lambda: c.worker(wid)["progress"] > p1, 3, "progress after resume")
    check(c.worker(wid)["health"] == "ok", "no false 'unresponsive' after a pause")
    return "T state while paused, progress frozen, R/S after resume"


def test_05_graceful_termination(c):
    """STOP sends SIGTERM; the worker exits with code 0; no restart."""
    wid = c.spawn("sorter")
    c.wait_state(wid, "running")
    pid = c.worker(wid)["pid"]
    r = c.req(f"STOP {wid}")
    check(r["ok"], f"STOP failed: {r}")
    w = c.worker(wid)
    check(w["state"] == "stopped", f"state {w['state']}")
    check(w["last_exit"] == "exited with code 0", f"exit: {w['last_exit']}")
    check(w["restarts"] == 0, "an intentional stop must not trigger a restart")
    check(not pid_alive(pid), "process must be gone")
    check(c.has_event("worker_bye", wid), "worker acknowledged SIGTERM")
    time.sleep(0.6)
    check(c.worker(wid)["state"] == "stopped", "still stopped (no watchdog restart)")
    return "exit code 0, bye message logged, no restart"


def test_06_unexpected_exit(c):
    """A crash is detected through SIGCHLD + waitpid with the exact reason."""
    wid = c.spawn("primes")
    c.wait_state(wid, "running")
    pid = c.worker(wid)["pid"]
    check(c.req(f"FAULT {wid} crash")["ok"], "fault injection")
    c.wait_for(lambda: c.has_event("worker_crash", wid), 5, "crash event")
    crash = [e for e in c.events() if e["type"] == "worker_crash" and e["worker_id"] == wid][0]
    check(crash["pid"] == pid, "crash event names the old pid")
    check("SIGABRT" in crash["message"], f"exit reason: {crash['message']}")
    return f"detected: {crash['message']}"


def test_07_watchdog_restart(c):
    """The watchdog restarts a crashed worker after the backoff delay."""
    wid = c.spawn("hasher")
    c.wait_state(wid, "running")
    old = c.worker(wid)["pid"]
    c.req(f"FAULT {wid} exit 3")
    c.wait_for(lambda: c.worker(wid)["restarts"] == 1 and c.worker(wid)["state"] == "running",
               6, "automatic restart")
    w = c.worker(wid)
    check(w["pid"] != old and pid_alive(w["pid"]), "a new process must be running")
    check(proc_stat(w["pid"])[1] == c.pid, "new process is our child")
    check(w["last_exit"] == "exited with code 3", f"last exit {w['last_exit']}")
    check(c.has_event("recovery_scheduled", wid) and c.has_event("recovery", wid), "recovery logged")
    return f"pid {old} -> {w['pid']}, restarts=1, last exit '{w['last_exit']}'"


def test_08_restart_limit(c):
    """After max_restarts consecutive failures recovery stops."""
    wid = c.spawn("primes")
    for attempt in range(3):             # max_restarts=2 -> third crash = limit
        c.wait_state(wid, "running", 6)
        c.req(f"FAULT {wid} crash")
        if attempt < 2:
            c.wait_for(lambda a=attempt: c.worker(wid)["restarts"] == a + 1, 6, f"restart {attempt+1}")
    c.wait_state(wid, "failed", 6)
    w = c.worker(wid)
    check("restart limit" in w["fail_reason"], f"reason: {w['fail_reason']}")
    check(w["restarts"] == 2, f"exactly 2 restarts expected, got {w['restarts']}")
    check(c.has_event("recovery_stopped", wid), "limit logged")
    time.sleep(1.2)
    check(c.worker(wid)["state"] == "failed", "no further restarts")
    r = c.req(f"RESTART {wid}")
    check(r["ok"] and r["worker"]["consecutive_failures"] == 0, "manual restart resets the counter")
    c.wait_state(wid, "running")
    return "2 restarts, then 'restart limit reached'; manual restart recovers"


test_08_restart_limit.config = {"max_restarts": 2}


def test_09_simultaneous_exits(c):
    """Five workers exit almost together; every one is reaped (signals coalesce)."""
    ids = [c.spawn("sorter") for _ in range(5)]
    for wid in ids:
        c.wait_state(wid, "running")
    pids = [c.worker(w)["pid"] for w in ids]
    for wid in ids:
        c.req(f"FAULT {wid} exit 7")
    c.wait_for(lambda: all(c.worker(w)["state"] == "failed" for w in ids), 6, "all exits handled")
    for wid in ids:
        check(c.worker(wid)["last_exit"] == "exited with code 7", "exit status recorded")
    zombies = [p for p, s in children_of(c.pid).items() if s == "Z"]
    check(not zombies, f"zombies left: {zombies}")
    check(not any(pid_alive(p) for p in pids), "all processes gone")
    return f"5 exits handled, 0 zombies (pids {pids})"


test_09_simultaneous_exits.config = {"watchdog": "off"}


def test_10_invalid_worker_ids(c):
    """Malformed and unknown IDs are rejected; raw PIDs cannot be addressed."""
    wid = c.spawn("primes")
    c.wait_state(wid, "running")
    for bad in ("0", "33", "99", "-1", "abc", "1;ls", "1.5", "4294967297"):
        r = c.req(f"STOP {bad}")
        check(not r["ok"], f"'{bad}' must be rejected")
    r = c.req("STOP 5")
    check(not r["ok"] and "no worker" in r["error"], "unused slot rejected")
    r = c.req(f"STOP {c.worker(wid)['pid']}")
    check(not r["ok"], "a PID is not accepted as a worker id")
    check(not c.req("SPAWN nosuchprofile")["ok"], "unknown profile rejected")
    check(not c.req("SPAWN primes bad/name")["ok"], "unsafe name rejected")
    check(not c.req("FROBNICATE 1")["ok"], "unknown command rejected")
    check(c.worker(wid)["state"] == "running", "valid worker unaffected")
    return "8 malformed ids, unused id, raw PID, bad profile/name all rejected"


def test_11_ipc_disconnection(c):
    """Clients that vanish mid-request do not disturb the controller."""
    wid = c.spawn("sleepy")
    c.wait_state(wid, "running")
    # (a) connect and close without sending anything
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect(c.sock)
    s.close()
    # (b) send half a line and disappear
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect(c.sock)
    s.sendall(b"LIS")
    s.close()
    # (c) ask for a slow status reply, then disconnect before it arrives
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect(c.sock)
    s.sendall(f"STATUS {wid}\n".encode())
    time.sleep(0.1)
    s.close()
    time.sleep(1.3)                      # past the 1 s status timeout
    check(c.req("PING")["ok"], "controller still answers")
    check(c.proc.poll() is None, "controller still running")
    check(c.worker(wid)["state"] == "running", "worker unaffected")
    return "silent, partial and vanished clients handled; controller alive"


def test_12_log_persistence(c):
    """The JSON-lines log survives a controller restart."""
    wid = c.spawn("primes", "persist-me")
    c.wait_state(wid, "running")
    c.req(f"STATUS {wid}")
    boot1 = c.req("LIST")["controller"]["boot_id"]
    c.stop()
    first = c.log_lines()
    check(any(e["worker"] == "persist-me" for e in first), "events written to disk")
    check(first[-1]["type"] == "controller_stop", "clean stop recorded last")
    c.start()
    boot2 = c.req("LIST")["controller"]["boot_id"]
    c.stop()
    second = c.log_lines()
    check(second[:len(first)] == first, "old history preserved unchanged")
    check(sum(1 for e in second if e["type"] == "controller_start") == 2, "two runs recorded")
    check(boot1 != boot2, "each run has its own boot id")
    return f"{len(first)} events kept after restart, {len(second)} total"


def test_13_clean_shutdown(c):
    """SIGTERM to the controller stops every worker gracefully, then exits 0."""
    ids = [c.spawn("primes"), c.spawn("hasher"), c.spawn("sorter")]
    for wid in ids:
        c.wait_state(wid, "running")
    c.req(f"PAUSE {ids[0]}")             # a paused worker must still stop
    pids = [c.worker(w)["pid"] for w in ids]
    c.proc.send_signal(signal.SIGTERM)
    code = c.proc.wait(timeout=10)
    check(code == 0, f"controller exit code {code}")
    check(not any(pid_alive(p) for p in pids), "all workers gone")
    check(not os.path.exists(c.sock), "socket removed")
    log = c.log_lines()
    exits = [e for e in log if e["type"] == "worker_exit"]
    check(len(exits) == 3 and all("code 0" in e["message"] for e in exits), "all exited with 0")
    check(not any(e["type"] == "stop_escalation" for e in log), "no SIGKILL needed")
    return "3 workers (1 paused) exited 0, socket removed, controller exit 0"


def test_14_zombie_prevention(c):
    """Crashes, stops and restarts leave no zombie children behind."""
    ids = [c.spawn("primes"), c.spawn("hasher"), c.spawn("sorter")]
    for wid in ids:
        c.wait_state(wid, "running")
    c.req(f"FAULT {ids[0]} segv")
    c.req(f"STOP {ids[1]}")
    c.req(f"RESTART {ids[2]}")
    c.wait_for(lambda: c.worker(ids[0])["restarts"] == 1 and c.worker(ids[0])["state"] == "running",
               6, "segv restart")
    time.sleep(0.3)
    kids = children_of(c.pid)
    zombies = [p for p, s in kids.items() if s == "Z"]
    check(not zombies, f"zombies: {zombies}")
    live = {w["pid"] for w in c.workers().values() if w["pid"]}
    check(set(kids) == live, f"children {sorted(kids)} must equal registry {sorted(live)}")
    return f"0 zombies; kernel children {sorted(kids)} == registry"


# -------------------------------------------------- additional edge cases

def test_15_unresponsive_is_not_crashed(c):
    """A slow worker is marked unresponsive, never restarted as crashed."""
    wid = c.spawn("sleepy")
    c.wait_state(wid, "running")
    pid = c.worker(wid)["pid"]
    r = c.req(f"STATUS {wid}")
    check(not r["ok"] and "unresponsive, not crashed" in r["error"], f"reply: {r}")
    check(r["worker"]["health"] == "unresponsive", "health flag")
    check(c.worker(wid)["state"] == "running" and c.worker(wid)["pid"] == pid, "same process, no restart")
    c.wait_for(lambda: c.worker(wid)["health"] == "ok", 8, "health restored")
    check(c.has_event("status_report", wid), "late reply logged")
    return "timeout -> unresponsive; late reply -> ok; restarts 0"


def test_16_hang_escalates_to_sigkill(c):
    """A hung worker ignores SIGTERM; after the grace period SIGKILL is used."""
    wid = c.spawn("primes")
    c.wait_state(wid, "running")
    c.req(f"FAULT {wid} hang")
    time.sleep(0.3)
    t0 = time.time()
    r = c.req(f"STOP {wid}")
    elapsed = time.time() - t0
    check(r["ok"], f"STOP: {r}")
    check(elapsed >= 1.4, f"grace period must be respected ({elapsed:.2f}s)")
    check("SIGKILL" in c.worker(wid)["last_exit"], c.worker(wid)["last_exit"])
    check(c.has_event("stop_escalation", wid), "escalation logged")
    check(c.worker(wid)["restarts"] == 0, "intentional stop is not restarted")
    return f"SIGTERM ignored, SIGKILL after {elapsed:.2f}s grace"


def test_17_single_instance_and_stale_socket(c):
    """A second controller is refused; a stale socket file is replaced."""
    second = subprocess.run([SIGCTLD, "-c", c.config], cwd=ROOT, capture_output=True,
                            text=True, timeout=5)
    check(second.returncode == 1 and "already running" in second.stderr, second.stderr)
    check(c.req("PING")["ok"], "first controller unaffected")
    c.proc.kill()                        # simulate a crash: socket left behind
    c.proc.wait()
    check(os.path.exists(c.sock), "stale socket exists after the crash")
    c.start()
    check(c.req("PING")["ok"], "new controller replaced the stale socket")
    return "second instance refused (exit 1); stale socket recovered"


def test_18_orphan_protection(c):
    """If the controller is SIGKILLed, workers receive SIGTERM (PDEATHSIG)."""
    ids = [c.spawn("primes"), c.spawn("hasher")]
    for wid in ids:
        c.wait_state(wid, "running")
    pids = [c.worker(w)["pid"] for w in ids]
    c.proc.kill()
    c.proc.wait()
    deadline = time.time() + 5
    while time.time() < deadline and any(pid_alive(p) for p in pids):
        time.sleep(0.05)
    check(not any(pid_alive(p) for p in pids), "workers must not outlive the controller")
    return f"workers {pids} exited after the controller was killed"


def test_19_log_file_unavailable(c):
    """If the log cannot be opened the controller keeps working."""
    info = c.req("LIST")["controller"]
    check(not info["log_ok"] and "cannot open" in info["log_error"], f"log state: {info}")
    wid = c.spawn("primes")
    c.wait_state(wid, "running")
    check(len(c.events()) > 0, "in-memory events still available")
    return "log_ok=false reported; workers and events still work"


test_19_log_file_unavailable.config = {"log_file": "/nonexistent-dir/events.jsonl"}


def test_20_watchdog_toggle_and_config(c):
    """Watchdog off -> crash is not restarted; runtime config is validated."""
    check(c.req("WATCHDOG off")["ok"], "toggle")
    wid = c.spawn("primes")
    c.wait_state(wid, "running")
    c.req(f"FAULT {wid} crash")
    c.wait_state(wid, "failed", 5)
    check("watchdog disabled" in c.worker(wid)["fail_reason"], c.worker(wid)["fail_reason"])
    check(c.req("CONFIG SET max_restarts 5")["config"]["max_restarts"] == 5, "valid set")
    check(not c.req("CONFIG SET max_restarts -3")["ok"], "invalid value rejected")
    check(not c.req("CONFIG SET socket_path /tmp/x")["ok"], "path change at runtime rejected")
    check(c.req("CONFIG SAVE")["ok"], "save")
    with open(c.config) as f:
        check("max_restarts          = 5" in f.read(), "saved to file")
    return "no restart with watchdog off; config validated and saved"


def test_21_sighup_reload(c):
    """SIGHUP makes the controller re-read its configuration file."""
    with open(c.config) as f:
        text = f.read().replace("max_restarts = 3", "max_restarts = 9")
    with open(c.config, "w") as f:
        f.write(text)
    c.proc.send_signal(signal.SIGHUP)
    c.wait_for(lambda: c.req("CONFIG")["config"]["max_restarts"] == 9, 3, "reload")
    check(c.has_event("config_reload"), "reload logged")
    return "max_restarts 3 -> 9 after SIGHUP"


TESTS = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]


def main():
    if os.geteuid() == 0:
        print("Run the tests as a normal user (the controller refuses to run as root).")
        return 2
    for exe in (SIGCTLD, WORKER):
        if not os.access(exe, os.X_OK):
            print(f"{exe} not found: run 'make' first")
            return 2
    selected = TESTS
    if len(sys.argv) > 2 and sys.argv[1] == "-k":
        selected = [t for t in TESTS if sys.argv[2] in t.__name__]

    passed = failed = 0
    print(f"Integration tests on {os.uname().sysname} {os.uname().release}\n")
    for test in selected:
        c = Controller(**getattr(test, "config", {}))
        t0 = time.time()
        try:
            c.start()
            detail = test(c)
            passed += 1
            print(f"PASS  {test.__name__:42s} {time.time()-t0:5.2f}s  {detail}")
        except Exception as e:  # noqa: BLE001 - report every failure
            failed += 1
            print(f"FAIL  {test.__name__:42s} {time.time()-t0:5.2f}s  {e}")
            if not isinstance(e, TestFailure):
                traceback.print_exc()
            print("      controller output (tail):")
            for line in c.output().splitlines()[-15:]:
                print("      " + line)
        finally:
            c.cleanup()
    print(f"\n{passed} passed, {failed} failed, {len(selected)} total")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
