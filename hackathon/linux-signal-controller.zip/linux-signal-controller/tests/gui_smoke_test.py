#!/usr/bin/env python3
"""
gui_smoke_test.py - Automated check that the Tkinter dashboard talks to a
REAL controller: it connects, renders the workers the controller reports,
and its actions (start, pause, resume, stop) change real process state.

Needs a display. On a desktop just run it; on a headless machine:
    xvfb-run -a python3 tests/gui_smoke_test.py
"""
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(ROOT, "gui"))

from integration_test import Controller, check, proc_stat  # noqa: E402


def pump(app, seconds):
    end = time.time() + seconds
    while time.time() < end:
        app.update()
        time.sleep(0.02)


def wait(app, pred, timeout, what):
    end = time.time() + timeout
    while time.time() < end:
        app.update()
        if pred():
            return
        time.sleep(0.02)
    raise AssertionError(f"timed out waiting for {what}")


def main():
    if not os.environ.get("DISPLAY"):
        print("No DISPLAY: run with  xvfb-run -a python3 tests/gui_smoke_test.py")
        return 2
    import dashboard  # noqa: E402  (imports tkinter)

    c = Controller(monitor_interval_ms=300)
    c.start()
    app = None
    results = []
    try:
        c.spawn("primes", "gui-a")
        c.spawn("hasher", "gui-b")
        app = dashboard.Dashboard(c.config)
        wait(app, lambda: app.connected and len(app.tree.get_children()) == 2, 8, "connection")
        results.append("connected and rendered 2 workers from LIST")
        check(app.cards["total"].value.cget("text") == "2", "metric card shows 2 workers")
        check(app.conn_pill.cget("text").strip().startswith("CONNECTED"), "connection pill")

        app.run_action("start", "SPAWN sorter gui-c")
        wait(app, lambda: len(app.tree.get_children()) == 3, 8, "third worker in table")
        results.append("GUI action SPAWN created a real worker")

        wid = next(w["id"] for w in app.workers.values() if w["name"] == "gui-a")
        app.tree.selection_set(str(wid))
        pump(app, 0.3)
        check(app.selected_id == wid, "selection")
        app.worker_action("PAUSE", "Pause")
        wait(app, lambda: app.workers[wid]["state"] == "paused", 6, "paused in table")
        pid = app.workers[wid]["pid"]
        check(proc_stat(pid)[0] == "T", "kernel reports T (stopped)")
        check("disabled" not in app.tool_buttons["resume"].state(), "Resume enabled when paused")
        check("disabled" in app.tool_buttons["pause"].state(), "Pause disabled when paused")
        results.append(f"Pause button -> SIGSTOP, /proc/{pid} state T, buttons updated")

        app.worker_action("RESUME", "Resume")
        wait(app, lambda: app.workers[wid]["state"] == "running", 6, "resumed")
        results.append("Resume button -> SIGCONT, running again")

        wait(app, lambda: app.kv["pid"].cget("text") == str(pid), 6, "details panel")
        results.append("details panel populated from INFO")

        app.run_action("stop", f"STOP {wid}", wid)
        wait(app, lambda: app.workers[wid]["state"] == "stopped", 8, "stopped")
        check(app.workers[wid]["last_exit"] == "exited with code 0", app.workers[wid]["last_exit"])
        results.append("Stop -> SIGTERM, worker stopped with exit code 0")

        wait(app, lambda: any(e["type"] == "worker_exit" for e in app.events), 5, "event feed")
        results.append(f"live event feed holds {len(app.events)} events")

        c.req("SHUTDOWN")
        wait(app, lambda: not app.connected, 10, "offline state")
        check(app.empty_title.cget("text") == "Controller is not running", "offline empty state")
        results.append("controller shutdown detected; offline state shown")
    finally:
        if app is not None:
            app.stop_event.set()
            app.destroy()
        c.cleanup()
    for r in results:
        print("PASS  " + r)
    print(f"\nGUI smoke test: {len(results)} checks passed")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except AssertionError as e:
        print(f"FAIL  {e}")
        sys.exit(1)
    except Exception as e:  # noqa: BLE001
        print(f"FAIL  {type(e).__name__}: {e}")
        sys.exit(1)
