/*
 * unit_tests.c - Automated tests for components that do not need processes:
 * watchdog policy, backoff, configuration parsing, JSON writer/reader,
 * input validation, /proc parsing and the event log ring/file.
 *
 * Run: make unit
 */
#include "common.h"
#include "config.h"
#include "json.h"
#include "logger.h"
#include "proc_info.h"
#include "watchdog.h"

#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static int g_run, g_fail;

#define CHECK(cond) do {                                                    \
        g_run++;                                                            \
        if (!(cond)) {                                                      \
            g_fail++;                                                       \
            fprintf(stderr, "  FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond);\
        }                                                                   \
    } while (0)

static wd_input_t failure(int failures, int64_t uptime)
{
    wd_input_t in;
    memset(&in, 0, sizeof in);
    in.signaled = 1;
    in.exit_code = -1;
    in.uptime_ms = uptime;
    in.watchdog_enabled = 1;
    in.max_restarts = 3;
    in.stable_reset_s = 30;
    in.consecutive_failures = failures;
    return in;
}

static void test_backoff(void)
{
    puts("[unit] exponential backoff");
    CHECK(watchdog_backoff_ms(1, 1000, 16000) == 1000);
    CHECK(watchdog_backoff_ms(2, 1000, 16000) == 2000);
    CHECK(watchdog_backoff_ms(3, 1000, 16000) == 4000);
    CHECK(watchdog_backoff_ms(5, 1000, 16000) == 16000);
    CHECK(watchdog_backoff_ms(50, 1000, 16000) == 16000);   /* capped, no overflow */
    CHECK(watchdog_backoff_ms(0, 500, 4000) == 500);
}

static void test_policy(void)
{
    wd_input_t in;
    wd_result_t r;

    puts("[unit] watchdog decisions");

    in = failure(0, 5000);
    in.stop_requested = 1;
    r = watchdog_decide(&in, 1000, 16000);
    CHECK(r.decision == WD_INTENTIONAL);

    in = failure(0, 5000);
    in.signaled = 0; in.exited = 1; in.exit_code = 0;
    r = watchdog_decide(&in, 1000, 16000);
    CHECK(r.decision == WD_COMPLETED);

    in = failure(0, 100);
    in.signaled = 0; in.exited = 1; in.exit_code = EXIT_START_FAILURE;
    r = watchdog_decide(&in, 1000, 16000);
    CHECK(r.decision == WD_START_FAILURE);

    in = failure(0, 5000);          /* 127 after a long run = normal failure */
    in.signaled = 0; in.exited = 1; in.exit_code = EXIT_START_FAILURE;
    r = watchdog_decide(&in, 1000, 16000);
    CHECK(r.decision == WD_RESTART);

    in = failure(0, 5000);
    r = watchdog_decide(&in, 1000, 16000);
    CHECK(r.decision == WD_RESTART && r.failures == 1 && r.delay_ms == 1000);

    in = failure(2, 5000);
    r = watchdog_decide(&in, 1000, 16000);
    CHECK(r.decision == WD_RESTART && r.failures == 3 && r.delay_ms == 4000);

    in = failure(3, 5000);          /* fourth failure with max_restarts 3 */
    r = watchdog_decide(&in, 1000, 16000);
    CHECK(r.decision == WD_LIMIT && r.failures == 4);

    in = failure(3, 60000);         /* stable for 60 s: counter resets */
    r = watchdog_decide(&in, 1000, 16000);
    CHECK(r.decision == WD_RESTART && r.failures == 1);

    in = failure(0, 5000);
    in.watchdog_enabled = 0;
    r = watchdog_decide(&in, 1000, 16000);
    CHECK(r.decision == WD_DISABLED);

    in = failure(0, 5000);
    in.max_restarts = 0;
    r = watchdog_decide(&in, 1000, 16000);
    CHECK(r.decision == WD_LIMIT);

    in = failure(0, 5000);          /* non-zero exit code is a failure too */
    in.signaled = 0; in.exited = 1; in.exit_code = 3;
    r = watchdog_decide(&in, 1000, 16000);
    CHECK(r.decision == WD_RESTART);
}

static void test_parse_long(void)
{
    long v = 0;
    puts("[unit] strict integer parsing (IPC input validation)");
    CHECK(parse_long("7", 1, 32, &v) == 0 && v == 7);
    CHECK(parse_long("0", 1, 32, &v) != 0);
    CHECK(parse_long("33", 1, 32, &v) != 0);
    CHECK(parse_long("-1", 1, 32, &v) != 0);
    CHECK(parse_long("3abc", 1, 32, &v) != 0);
    CHECK(parse_long("", 1, 32, &v) != 0);
    CHECK(parse_long(NULL, 1, 32, &v) != 0);
    CHECK(parse_long("99999999999999999999", 0, 100, &v) != 0);
}

static void test_json(void)
{
    jbuf_t j;
    char out[64], s[32];
    long long v;

    puts("[unit] JSON writer and reader");
    jb_init(&j);
    jb_obj_begin(&j);
    jb_kstr(&j, "a", "x\"y\\z\n");
    jb_kint(&j, "n", -5);
    jb_key(&j, "arr");
    jb_arr_begin(&j);
    jb_int(&j, 1);
    jb_int(&j, 2);
    jb_obj_begin(&j);
    jb_kbool(&j, "t", 1);
    jb_obj_end(&j);
    jb_arr_end(&j);
    jb_obj_end(&j);
    CHECK(strcmp(jb_cstr(&j), "{\"a\":\"x\\\"y\\\\z\\n\",\"n\":-5,\"arr\":[1,2,{\"t\":true}]}") == 0);
    jb_free(&j);

    CHECK(json_escape("tab\there", out, sizeof out) == 0 && strcmp(out, "\"tab\\there\"") == 0);
    CHECK(json_escape("\x01", out, sizeof out) == 0 && strcmp(out, "\"\\u0001\"") == 0);
    CHECK(json_escape("long string", out, 5) == -1);

    CHECK(json_get_str("{\"type\":\"hb\",\"progress\":42}", "type", s, sizeof s) == 0 &&
          strcmp(s, "hb") == 0);
    CHECK(json_get_ll("{\"type\":\"hb\",\"progress\":42}", "progress", &v) == 0 && v == 42);
    CHECK(json_get_ll("{\"type\":\"hb\"}", "progress", &v) == -1);
    CHECK(json_get_str("{\"type\":5}", "type", s, sizeof s) == -1);
}

static void test_config(void)
{
    config_t c;
    char err[200], path[] = "/tmp/sigctl-unit-XXXXXX";
    FILE *f;
    int fd;

    puts("[unit] configuration parsing and validation");
    config_defaults(&c);
    CHECK(c.max_restarts == 3 && c.watchdog_enabled == 1);

    CHECK(config_set(&c, "max_restarts", "5", 1, err, sizeof err) == 0 && c.max_restarts == 5);
    CHECK(config_set(&c, "max_restarts", "-2", 1, err, sizeof err) != 0);
    CHECK(config_set(&c, "max_restarts", "abc", 1, err, sizeof err) != 0);
    CHECK(config_set(&c, "watchdog", "off", 1, err, sizeof err) == 0 && c.watchdog_enabled == 0);
    CHECK(config_set(&c, "watchdog", "maybe", 1, err, sizeof err) != 0);
    CHECK(config_set(&c, "socket_path", "/tmp/x.sock", 1, err, sizeof err) != 0); /* not at runtime */
    CHECK(config_set(&c, "socket_path", "/tmp/x.sock", 0, err, sizeof err) == 0);
    CHECK(config_set(&c, "no_such_key", "1", 0, err, sizeof err) != 0);
    CHECK(config_set(&c, "backoff_base_ms", "8000", 1, err, sizeof err) == 0 &&
          c.backoff_max_ms >= c.backoff_base_ms);

    fd = mkstemp(path);
    CHECK(fd >= 0);
    f = fdopen(fd, "w");
    fputs("# comment\n\nmax_restarts = 7   # trailing comment\nwatchdog=off\n", f);
    fclose(f);
    config_defaults(&c);
    CHECK(config_load(&c, path, err, sizeof err) == 0);
    CHECK(c.max_restarts == 7 && c.watchdog_enabled == 0);

    f = fopen(path, "w");
    fputs("max_restarts = lots\n", f);
    fclose(f);
    CHECK(config_load(&c, path, err, sizeof err) != 0 && strstr(err, ":1:") != NULL);

    config_defaults(&c);
    c.max_restarts = 9;
    CHECK(config_save(&c, path, err, sizeof err) == 0);
    config_defaults(&c);
    CHECK(config_load(&c, path, err, sizeof err) == 0 && c.max_restarts == 9);
    unlink(path);
}

static void test_proc(void)
{
    proc_info_t pi;
    puts("[unit] /proc parsing");
    CHECK(proc_read(getpid(), &pi) == 0);
    CHECK(pi.ppid == getppid());
    CHECK(pi.state == 'R' || pi.state == 'S');
    CHECK(pi.rss_kb > 0);
    CHECK(proc_is_child_of(getpid(), getppid()) == 1);
    CHECK(proc_is_child_of(getpid(), 1) == (getppid() == 1));
    CHECK(proc_read(0, &pi) == -1);
    CHECK(strcmp(proc_state_name('Z'), "zombie") == 0);
}

static void test_signal_names(void)
{
    puts("[unit] signal names");
    CHECK(strcmp(signal_name(SIGUSR1), "SIGUSR1") == 0);
    CHECK(strcmp(signal_name(SIGCHLD), "SIGCHLD") == 0);
    CHECK(strcmp(signal_name(SIGSTOP), "SIGSTOP") == 0);
    CHECK(strcmp(signal_name(9999), "SIG?") == 0);
}

static void test_logger(void)
{
    char path[] = "/tmp/sigctl-log-XXXXXX", line[512];
    jbuf_t j;
    FILE *f;
    int fd, lines = 0, i;

    puts("[unit] event log: ring buffer, filters and persistence");
    fd = mkstemp(path);
    CHECK(fd >= 0);
    close(fd);
    CHECK(logger_init(path, 0) == 0);
    for (i = 0; i < EVENT_RING + 5; i++)
        log_event(i % 2 ? SEV_WARN : SEV_INFO, "test", i % 2 ? 7 : 0, "w", 100 + i, "x", "event %d", i);
    CHECK(logger_last_seq() == (uint64_t)EVENT_RING + 5);

    jb_init(&j);
    logger_events_json(&j, 0, 3, 0);
    CHECK(strstr(jb_cstr(&j), "\"message\":\"event 2004\"") != NULL);
    CHECK(strstr(jb_cstr(&j), "\"message\":\"event 2001\"") == NULL);
    jb_free(&j);

    jb_init(&j);
    logger_events_json(&j, logger_last_seq() - 1, 100, 0);   /* only newest */
    CHECK(strstr(jb_cstr(&j), "event 2004") != NULL && strstr(jb_cstr(&j), "event 2003") == NULL);
    jb_free(&j);

    jb_init(&j);
    logger_events_json(&j, 0, 2, 7);                          /* worker filter */
    CHECK(strstr(jb_cstr(&j), "event 2003") != NULL && strstr(jb_cstr(&j), "event 2002") == NULL);
    jb_free(&j);
    logger_close();

    f = fopen(path, "r");
    CHECK(f != NULL);
    while (f && fgets(line, sizeof line, f) != NULL)
        lines++;
    if (f)
        fclose(f);
    CHECK(lines == EVENT_RING + 5);     /* every event persisted to disk */

    CHECK(logger_init("/nonexistent-dir/x.log", 0) == -1);   /* survives failure */
    log_event(SEV_INFO, "test", 0, "", 0, "", "still works");
    CHECK(logger_file_ok() == 0);
    unlink(path);
}

int main(void)
{
    test_backoff();
    test_policy();
    test_parse_long();
    test_json();
    test_config();
    test_proc();
    test_signal_names();
    test_logger();
    printf("\nunit tests: %d checks, %d failed\n", g_run, g_fail);
    return g_fail ? 1 : 0;
}
